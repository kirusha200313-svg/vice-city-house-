import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { test } from 'node:test';
import { BUILDINGS, CATALOG, LEVELS, MAX_LOTS, START_COINS, UPGRADE_CHAIN, checkBuild, computeStats, countsFromList, lotsUsed, priceOf, validateCityName } from '../../shared/game';
import { MemoryStore } from '../src/memoryStore';
import { GameError, GameService } from '../src/service';
import { AuthError, signInitData, verifyInitData } from '../src/telegram';

function mulberry32(a: number) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function setup(seed = 1) {
  const clock = { t: 1_700_000_000_000 };
  const store = new MemoryStore();
  const game = new GameService(store, { now: () => clock.t, rng: mulberry32(seed), genIntervalMs: 90_000 });
  const user = (id: string) => ({ id, firstName: `Мэр${id}` });
  return { clock, store, game, user };
}

const rejects = async (p: Promise<unknown>, code: string) => {
  await assert.rejects(p, (e: any) => e instanceof GameError && e.code === code, `ожидалась ошибка ${code}`);
};

// ---------------------------------------------------------------- Telegram initData

const TOKEN = '123456:TEST-TOKEN';
const mkInit = (over: Record<string, string> = {}, now = Date.now()) =>
  signInitData({
    auth_date: String(Math.floor(now / 1000)), query_id: 'AAH', user: JSON.stringify({ id: 777, first_name: 'Аня', username: 'anya' }), ...over,
  }, TOKEN);

test('initData: корректная подпись проходит', () => {
  const u = verifyInitData(mkInit(), TOKEN, 3600);
  assert.equal(u.id, '777');
  assert.equal(u.firstName, 'Аня');
});

test('initData: подделка, чужой токен, устаревшие данные отклоняются', () => {
  const good = mkInit();
  const tampered = good.replace(encodeURIComponent('"id":777'), encodeURIComponent('"id":778')).replace('777', '778');
  assert.throws(() => verifyInitData(tampered, TOKEN, 3600), AuthError);
  assert.throws(() => verifyInitData(good, 'other:token', 3600), AuthError);
  assert.throws(() => verifyInitData(mkInit({}, Date.now() - 2 * 3600_000), TOKEN, 3600), AuthError);
  assert.throws(() => verifyInitData('user=%7B%7D', TOKEN, 3600), AuthError);
  assert.throws(() => verifyInitData('', TOKEN, 3600), AuthError);
});

test('initData: хеш из документации-образца вычисляется по алгоритму WebAppData', () => {
  // независимая проверка: те же шаги через openssl-совместимый HMAC
  const fields = { auth_date: '1700000000', user: '{"id":1,"first_name":"A"}' };
  const secret = createHmac('sha256', 'WebAppData').update(TOKEN).digest();
  const dcs = 'auth_date=1700000000\nuser={"id":1,"first_name":"A"}';
  const hash = createHmac('sha256', secret).update(dcs).digest('hex');
  const init = new URLSearchParams({ ...fields, hash }).toString();
  assert.equal(verifyInitData(init, TOKEN, 10 ** 9, 1_700_000_100_000).id, '1');
});

// ---------------------------------------------------------------- формулы и каталог

test('каталог: цены растут, уровни в пределах, есть все 4 категории', () => {
  assert.equal(new Set(CATALOG.map((b) => b.category)).size, 4);
  for (const b of CATALOG) {
    assert.ok(b.minLevel >= 1 && b.minLevel <= LEVELS.length, b.id);
    assert.ok(b.price > 0 && b.xp > 0, b.id);
  }
  assert.ok(priceOf(BUILDINGS.small_house, 10) > priceOf(BUILDINGS.small_house, 0));
});

test('валидация названия города', () => {
  assert.equal(validateCityName('Пушкинск'), null);
  assert.equal(validateCityName('Нью-Васюки 2'), null);
  assert.ok(validateCityName('ab'));
  assert.ok(validateCityName('   '));
  assert.ok(validateCityName('<script>'));
  assert.ok(validateCityName('а'.repeat(21)));
});

test('экономика: дороги и парки повышают население и счастье', () => {
  const base = computeStats(countsFromList(['old_house', 'old_house', 'old_house']), 0, 5);
  const better = computeStats(countsFromList(['old_house', 'old_house', 'old_house', 'road', 'road', 'lighting', 'park']), 0, 5);
  assert.ok(better.population > base.population);
  assert.ok(better.happiness > base.happiness);
  assert.ok(base.net > 0, 'на старте бюджет не должен быть отрицательным');
});

test('checkBuild: причины отказа', () => {
  const ctx = { level: 1, coins: 100, counts: countsFromList(['old_house']), roadRepairs: 0, happinessBonus: 0 };
  assert.equal((checkBuild(ctx, BUILDINGS.park) as any).code, 'level');
  assert.equal((checkBuild(ctx, BUILDINGS.small_house) as any).code, 'funds');
  assert.equal((checkBuild({ ...ctx, coins: 9999 }, BUILDINGS.small_house) as any).ok, true);
  assert.equal((checkBuild(ctx, BUILDINGS.old_house) as any).code, 'unknown');
});

// ---------------------------------------------------------------- создание города

test('создание города: старт, повторный вход, уникальность названия', async () => {
  const { game, user } = setup();
  assert.equal(await game.getState(user('1')), null);
  const s = await game.createCity(user('1'), '  Пушкинск ');
  assert.equal(s.city.name, 'Пушкинск');
  assert.equal(s.city.coins, START_COINS);
  assert.deepEqual(s.buildings, ['old_house', 'old_house', 'old_house']);
  assert.ok(s.city.population > 0);
  assert.ok(s.quests.length >= 3);
  assert.ok(s.quests.some((q) => q.status === 'open'));

  // повторная отправка формы не создаёт второй город
  const again = await game.createCity(user('1'), 'Другое имя');
  assert.equal(again.city.name, 'Пушкинск');
  assert.equal(again.city.id, s.city.id);

  await rejects(game.createCity(user('2'), 'пушкинск'), 'name_taken');
  await game.createCity(user('5'), 'Ёлки');
  await rejects(game.createCity(user('6'), 'елки'), 'name_taken'); // ё = е
  await rejects(game.createCity(user('2'), 'x'), 'bad_name');
  await rejects(game.createCity(user('2'), 123 as any), 'bad_name');
  const s2 = await game.createCity(user('2'), 'Речной');
  assert.notEqual(s2.city.id, s.city.id);
});

test('у разных игроков раздельный прогресс', async () => {
  const { game, user } = setup();
  await game.createCity(user('1'), 'Альфа');
  await game.createCity(user('2'), 'Бета');
  await game.build(user('1'), 'small_house', 'req-aaaaaaa1');
  assert.equal((await game.getState(user('1')))!.buildings.length, 4);
  assert.equal((await game.getState(user('2')))!.buildings.length, 3);
  await rejects(game.build(user('99'), 'small_house'), 'no_city');
});

// ---------------------------------------------------------------- постройки

test('постройка: списывает деньги, даёт опыт и население; ошибки не меняют состояние', async () => {
  const { game, user } = setup();
  const u = user('1');
  const s0 = await game.createCity(u, 'Альфа');
  const r = await game.build(u, 'small_house', 'build-0000001');
  assert.equal(r.event?.type, 'built');
  assert.equal(r.state.city.coins, s0.city.coins - 300);
  assert.equal(r.state.city.xp, s0.city.xp + BUILDINGS.small_house.xp);
  assert.ok(r.state.city.population > s0.city.population);
  assert.equal(r.state.buildings.length, 4);

  await rejects(game.build(u, 'park'), 'level'); // park — со 2 уровня
  await rejects(game.build(u, 'skyscraper'), 'level');
  await rejects(game.build(u, 'old_house'), 'unknown');
  await rejects(game.build(u, 'nonexistent'), 'unknown');
  await rejects(game.build(u, { $ne: 1 }), 'unknown');
  const after = await game.getState(u);
  assert.equal(after!.city.coins, r.state.city.coins);
  assert.equal(after!.buildings.length, 4);
});

test('нельзя уйти в минус по деньгам: параллельные покупки на последние монеты', async () => {
  const { game, user } = setup();
  const u = user('1');
  await game.createCity(u, 'Альфа'); // 1500 монет: хватает ровно на 5 маленьких домов с учётом роста цены? проверим
  const results = await Promise.allSettled(
    Array.from({ length: 12 }, (_, i) => game.build(u, 'small_house', `parallel-${String(i).padStart(4, '0')}`)),
  );
  const ok = results.filter((r) => r.status === 'fulfilled').length;
  const st = (await game.getState(u))!;
  assert.ok(st.city.coins >= 0, `монеты ушли в минус: ${st.city.coins}`);
  assert.equal(st.buildings.length, 3 + ok);
  assert.ok(ok >= 3 && ok < 12);
  const failed = results.filter((r) => r.status === 'rejected') as PromiseRejectedResult[];
  assert.ok(failed.every((f) => f.reason instanceof GameError && f.reason.code === 'funds'));
});

test('повтор запроса с тем же requestId не списывает деньги второй раз', async () => {
  const { game, user } = setup();
  const u = user('1');
  await game.createCity(u, 'Альфа');
  const a = await game.build(u, 'small_house', 'same-request-1');
  const b = await game.build(u, 'small_house', 'same-request-1');
  const c = await game.build(u, 'small_house', 'same-request-1');
  assert.equal(b.replayed, true);
  assert.equal(c.state.buildings.length, 4);
  assert.equal(b.state.city.coins, a.state.city.coins);
  await rejects(game.build(u, 'small_house', 'bad id!'), 'bad_request');
});

test('лимиты: дорог не больше 8, бюджет не уходит в минус из-за содержания', async () => {
  const { game, user, store } = setup();
  const u = user('1');
  await game.createCity(u, 'Альфа');
  await store.withCity('1', (tx) => { tx.city.coins = 10_000_000; tx.city.level = 8; });
  for (let i = 0; i < 8; i++) await game.build(u, 'road', `road-req-${i}000`);
  await rejects(game.build(u, 'road', 'road-req-9000'), 'max');
  // больница (содержание 45/ч, дохода нет) при крошечном бюджете отклоняется
  await rejects(game.build(u, 'hospital', 'hospital-req-1'), 'budget');
  // стадион приносит больше, чем стоит его содержание, — разрешён
  assert.equal((await game.build(u, 'stadium', 'stadium-req-1')).event?.type, 'built');
});

// ---------------------------------------------------------------- доход со временем

test('доход начисляется по времени на сервере, оффлайн-лимит 12 часов', async () => {
  const { game, user, clock } = setup();
  const u = user('1');
  const s0 = await game.createCity(u, 'Альфа');
  const net = s0.city.net;
  assert.ok(net > 0);
  clock.t += 3_600_000; // +1 час
  const s1 = (await game.getState(u))!;
  assert.ok(Math.abs(s1.city.coins - (s0.city.coins + Math.floor(net))) <= 1, `ожидалось ~+${net}, стало ${s1.city.coins - s0.city.coins}`);
  clock.t += 100 * 3_600_000; // долго не заходили
  const s2 = (await game.getState(u))!;
  const gained = s2.city.coins - s1.city.coins;
  assert.ok(gained <= Math.ceil(net * 12) + 1 && gained >= Math.floor(net * 12) - 1, `получено ${gained}, ожидалось ~${net * 12}`);
  // частые запросы не дают лишнего: дробная часть не теряется и не удваивается
  const before = (await game.getState(u))!.city.coins;
  for (let i = 0; i < 20; i++) await game.getState(u);
  assert.equal((await game.getState(u))!.city.coins, before);
});

// ---------------------------------------------------------------- задания жителей

test('платное задание: награда выдаётся один раз, параллельные клики не дублируют её', async () => {
  const { game, user } = setup();
  const u = user('1');
  const s0 = await game.createCity(u, 'Альфа');
  const q = s0.quests.find((x) => x.kind === 'pay' && x.status === 'open')!;
  assert.ok(q, 'в стартовой ленте есть платное задание');
  const results = await Promise.allSettled([
    game.completeQuest(u, q.id, 'quest-req-0001'),
    game.completeQuest(u, q.id, 'quest-req-0002'),
    game.completeQuest(u, q.id, 'quest-req-0003'),
  ]);
  assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
  const rej = results.filter((r) => r.status === 'rejected') as PromiseRejectedResult[];
  assert.ok(rej.every((r) => r.reason.code === 'already_done'));
  const s1 = (await game.getState(u))!;
  assert.equal(s1.city.coins, s0.city.coins - (q.cost ?? 0) + q.reward.coins);
  assert.equal(s1.city.xp, q.reward.xp);
  assert.equal(s1.city.solved, 1);
  assert.equal(s1.quests.find((x) => x.id === q.id)!.status, 'done');
  await rejects(game.completeQuest(u, q.id), 'already_done');
  await rejects(game.completeQuest(u, 'no-such-quest'), 'not_found');
});

test('задание «починить дорогу» чинит дорогу (растёт покрытие дорог)', async () => {
  const { game, user } = setup();
  const u = user('1');
  const s0 = await game.createCity(u, 'Альфа');
  const q = s0.quests.find((x) => x.status === 'open' && x.kind === 'pay')!;
  const r = await game.completeQuest(u, q.id);
  assert.equal(r.state.city.roadRepairs, 1);
  assert.ok(r.state.city.coverage.roads > s0.city.coverage.roads);
});

test('задание «построить»: сначала not_ready, после постройки — награда', async () => {
  const { game, user } = setup();
  const u = user('1');
  const s0 = await game.createCity(u, 'Альфа');
  const q = s0.quests.find((x) => x.kind === 'build' && x.status === 'open')!;
  assert.ok(q, 'в стартовой ленте есть задание «построить»');
  assert.equal(q.ready, false);
  await rejects(game.completeQuest(u, q.id), 'not_ready');
  const b = await game.build(u, q.building!, 'quest-build-01');
  assert.equal(b.state.quests.find((x) => x.id === q.id)!.ready, true);
  const r = await game.completeQuest(u, q.id, 'quest-done-001');
  assert.equal(r.state.quests.find((x) => x.id === q.id)!.status, 'done');
  assert.ok(r.state.city.happiness >= b.state.city.happiness);
  assert.ok(r.state.quests.some((x) => x.category === 'thanks'), 'жители благодарят за построенное');
});

test('платное задание без денег отклоняется и не меняет состояние', async () => {
  const { game, user, store } = setup();
  const u = user('1');
  const s0 = await game.createCity(u, 'Альфа');
  const q = s0.quests.find((x) => x.kind === 'pay')!;
  await store.withCity('1', (tx) => { tx.city.coins = 5; });
  await rejects(game.completeQuest(u, q.id), 'funds');
  const s = (await game.getState(u))!;
  assert.equal(s.quests.find((x) => x.id === q.id)!.status, 'open');
  assert.equal(s.city.solved, 0);
});

// ---------------------------------------------------------------- лента живёт и реагирует

test('лента: появляются новые посты, тексты и жители разнообразны, задания зависят от города', async () => {
  const { game, user, clock } = setup(7);
  const u = user('1');
  await game.createCity(u, 'Альфа');
  let st = (await game.getState(u))!;
  const start = st.quests.length;
  for (let i = 0; i < 40; i++) {
    clock.t += 95_000;
    st = (await game.getState(u))!;
  }
  assert.ok(st.quests.length > start + 10, `постов было ${start}, стало ${st.quests.length}`);
  assert.ok(st.quests.length <= 40);
  const texts = new Set(st.quests.map((q) => q.text));
  const npcs = new Set(st.quests.map((q) => q.npc.name));
  // одинаковый текст не должен появляться в соседних постах (в окне из 10)
  const feed = [...st.quests].reverse();
  for (let i = 0; i < feed.length; i++) {
    for (let j = i + 1; j < Math.min(feed.length, i + 10); j++) assert.notEqual(feed[i].text, feed[j].text, `один и тот же текст через ${j - i} постов`);
  }
  console.log(`\nв ленте ${st.quests.length} постов, уникальных текстов ${texts.size}, разных жителей ${new Set(st.quests.map((q) => q.npc.name)).size}`);
  assert.ok(npcs.size >= 5);
  assert.ok(st.quests.filter((q) => q.status === 'open').length <= 5, 'открытых заданий не должно копиться бесконечно');
  assert.ok(new Set(st.quests.map((q) => q.category)).size >= 3);
});

test('задания реагируют на состояние города: просят то, чего не хватает', async () => {
  const rate = async (extra: string[]) => {
    let parks = 0, lights = 0;
    for (let seed = 1; seed <= 20; seed++) {
      const { game, user, clock, store } = setup(seed);
      const u = user('1');
      await game.createCity(u, 'Альфа');
      await store.withCity('1', (tx) => { tx.city.level = 3; tx.buildings.push(...extra); });
      for (let i = 0; i < 10; i++) { clock.t += 95_000; await game.getState(u); }
      const st = (await game.getState(u))!;
      if (st.quests.some((q) => q.building === 'park')) parks++;
      if (st.quests.some((q) => q.building === 'lighting')) lights++;
    }
    return { parks, lights };
  };
  const bare = await rate([]);
  const covered = await rate(['park', 'park', 'lighting']);
  console.log(`\nпросьбы за 20 запусков: пустой город ${JSON.stringify(bare)}, с парками и фонарями ${JSON.stringify(covered)}`);
  assert.ok(bare.parks > 0 && bare.lights > 0, 'в городе без парков и освещения жители должны об этом просить');
  assert.equal(covered.parks, 0, 'если парков хватает, о них не просят');
  assert.equal(covered.lights, 0, 'если освещения хватает, о нём не просят');
});

// ---------------------------------------------------------------- улучшение домов

test('улучшение дома: цена, опыт, население; ошибки не меняют состояние', async () => {
  const { game, user, store } = setup();
  const u = user('1');
  const s0 = await game.createCity(u, 'Альфа');
  const r = await game.upgrade(u, 0, 'upgrade-00001');
  assert.equal(r.event?.type, 'upgraded');
  assert.equal(r.state.buildings[0], 'small_house');
  assert.equal(r.state.buildings.length, 3);
  assert.equal(r.state.city.coins, s0.city.coins - priceOf(BUILDINGS.small_house, 0));
  assert.equal(r.state.city.xp, BUILDINGS.small_house.xp - BUILDINGS.old_house.xp);
  assert.ok(r.state.city.population > s0.city.population);

  await rejects(game.upgrade(u, 0), 'level'); // small_house → house со 2 уровня
  const again = await game.upgrade(u, 0, 'upgrade-00001'); // тот же requestId
  assert.equal(again.replayed, true);
  assert.equal(again.state.city.coins, r.state.city.coins);
  for (const bad of [-1, 3, 99, 1.5, '1', null, undefined, {}]) await rejects(game.upgrade(u, bad as any), 'bad_request');

  await store.withCity('1', (tx) => { tx.city.coins = 10; });
  await rejects(game.upgrade(u, 1), 'funds');
  assert.equal((await game.getState(u))!.buildings[1], 'old_house');
});

test('улучшение: лестница до небоскрёба конечна, опыт ограничен, параллельные клики не двоят списание', async () => {
  const { game, user, store } = setup();
  const u = user('1');
  await game.createCity(u, 'Альфа');
  await store.withCity('1', (tx) => { tx.city.coins = 10_000_000; tx.city.level = 8; });
  const before = (await game.getState(u))!;
  for (let i = 0; i < 6; i++) await game.upgrade(u, 0);
  const after = (await game.getState(u))!;
  assert.equal(after.buildings[0], 'skyscraper');
  assert.equal(after.city.xp - before.city.xp, BUILDINGS.skyscraper.xp - BUILDINGS.old_house.xp);
  await rejects(game.upgrade(u, 0), 'no_upgrade');
  await store.withCity('1', (tx) => { tx.buildings.push('park'); });
  await rejects(game.upgrade(u, 3), 'no_upgrade'); // парк не улучшается

  const coins0 = (await game.getState(u))!.city.coins;
  const res = await Promise.allSettled([game.upgrade(u, 1, 'par-up-000001'), game.upgrade(u, 1, 'par-up-000002'), game.upgrade(u, 1, 'par-up-000003')]);
  const st = (await game.getState(u))!;
  const okCount = res.filter((x) => x.status === 'fulfilled').length;
  assert.equal(okCount, 3); // три разных запроса — три разных улучшения подряд, но…
  assert.equal(st.buildings[1], 'apartment'); // …old → small → house → apartment, ровно три ступени
  assert.ok(st.city.coins < coins0);
});

// ---------------------------------------------------------------- уровни

test('повышение уровня: нужно достаточно опыта, награда, новые здания', async () => {
  const { game, user, store } = setup();
  const u = user('1');
  const s0 = await game.createCity(u, 'Альфа');
  await rejects(game.levelUp(u), 'no_xp');
  await store.withCity('1', (tx) => { tx.city.xp = 520; });
  const r = await game.levelUp(u, 'levelup-0001');
  assert.equal(r.state.city.level, 2);
  assert.equal(r.state.city.xp, 20);
  assert.equal(r.state.city.crystals, s0.city.crystals + 5);
  assert.ok(r.state.city.coins >= s0.city.coins + 500);
  assert.equal(r.event?.type, 'levelup');
  assert.ok((r.event as any).unlocked.includes('park'));
  assert.equal(r.state.city.levelName, 'Маленькое поселение');
  const again = await game.levelUp(u, 'levelup-0001'); // повтор по сети
  assert.equal(again.replayed, true);
  assert.equal(again.state.city.level, 2);
  await rejects(game.levelUp(u), 'no_xp');
  await store.withCity('1', (tx) => { tx.city.level = 8; tx.city.xp = 10 ** 6; });
  await rejects(game.levelUp(u), 'max_level');
});

test('обмен кристаллов на монеты', async () => {
  const { game, user } = setup();
  const u = user('1');
  const s0 = await game.createCity(u, 'Альфа'); // 10 кристаллов
  const r = await game.exchange(u, 1, 'exchange-0001');
  assert.equal(r.state.city.crystals, s0.city.crystals - 5);
  assert.equal(r.state.city.coins, s0.city.coins + 500);
  await rejects(game.exchange(u, 5), 'funds');
  await rejects(game.exchange(u, -1), 'bad_request');
  await rejects(game.exchange(u, 1.5), 'bad_request');
});

// ---------------------------------------------------------------- рейтинг

test('рейтинг: сортировка по населению и уровню, своя позиция, профиль города', async () => {
  const { game, user, store } = setup();
  for (const [id, name] of [['1', 'Альфа'], ['2', 'Бета'], ['3', 'Гамма']]) await game.createCity(user(id), name);
  await store.withCity('2', (tx) => { tx.city.coins = 100000; });
  for (let i = 0; i < 4; i++) await game.build(user('2'), 'small_house', `rating-b-${i}00000`);
  await store.withCity('3', (tx) => { tx.city.level = 5; });

  const byPop = await game.rating(user('1'), 'population');
  assert.equal(byPop.entries[0].name, 'Бета');
  assert.equal(byPop.total, 3);
  assert.equal(byPop.me!.name, 'Альфа');
  assert.ok(byPop.entries.find((e) => e.isMe));
  assert.deepEqual(byPop.entries.map((e) => e.rank), [1, 2, 3]);
  assert.ok(byPop.entries[0].population >= byPop.entries[1].population);

  const byLevel = await game.rating(user('1'), 'level');
  assert.equal(byLevel.entries[0].name, 'Гамма');
  assert.equal(byLevel.me!.rank, byLevel.entries.findIndex((e) => e.name === 'Альфа') + 1);

  const pub = await game.publicCity(byPop.entries[0].cityId);
  assert.equal(pub.name, 'Бета');
  assert.equal(pub.buildings.length, 7);
  assert.equal(pub.rank, 1);
  assert.equal((pub as any).coins, undefined, 'публичный профиль не раскрывает баланс');
  await rejects(game.publicCity('999999'), 'not_found');
  await rejects(game.publicCity('abc'), 'not_found');
});

// ---------------------------------------------------------------- проверка баланса: «жадный» игрок

test('баланс: за 7 суток активной игры (заход каждые 30 минут) развитие не упирается в тупик', async () => {
  const { game, user, clock } = setup(3);
  const u = user('1');
  await game.createCity(u, 'Альфа');
  const log: string[] = [];
  const pop: number[] = [];
  const tier = (t: string) => UPGRADE_CHAIN.indexOf(t);
  for (let step = 0; step < 7 * 24 * 2; step++) {
    clock.t += 30 * 60_000;
    let st = (await game.getState(u))!;
    for (const q of st.quests) {
      if (q.status !== 'open') continue;
      try {
        if (q.kind === 'pay' && st.city.coins >= (q.cost ?? 0) + 200) st = (await game.completeQuest(u, q.id)).state;
        if (q.kind === 'build' && q.ready) st = (await game.completeQuest(u, q.id)).state;
      } catch { /* нет денег и т.п. */ }
    }
    const wanted = st.quests.filter((q) => q.status === 'open' && q.kind === 'build').map((q) => q.building!);
    for (const id of [...wanted, 'skyscraper', 'complex', 'midrise', 'apartment', 'house', 'small_house']) {
      try { st = (await game.build(u, id)).state; break; } catch { /* недоступно */ }
    }
    // улучшаем самый низкий дом (по одному на каждую ступень лестницы)
    for (let k = 0; k < 3; k++) {
      const idx = st.buildings.map((t, i) => [t, i] as const).filter(([t]) => tier(t) >= 0).sort((a, b) => tier(a[0]) - tier(b[0]));
      const seen = new Set<number>();
      let done = false;
      for (const [t, i] of idx) {
        if (seen.has(tier(t))) continue;
        seen.add(tier(t));
        try { st = (await game.upgrade(u, i)).state; done = true; break; } catch { /* ступень пока недоступна */ }
      }
      if (!done) break;
    }
    if (st.city.canLevelUp) st = (await game.levelUp(u)).state;
    if (step % 48 === 47) {
      pop.push(st.city.population);
      const lots = lotsUsed(countsFromList(st.buildings));
      log.push(`день ${(step + 1) / 48}: ур.${st.city.level} жит.${st.city.population} счастье ${st.city.happiness}% участков ${lots}/${MAX_LOTS} монет ${st.city.coins} (+${Math.round(st.city.net)}/ч)`);
    }
  }
  console.log('\n' + log.join('\n'));
  const fin = (await game.getState(u))!;
  assert.ok(fin.city.level >= 4, `за 7 дней достигнут только ${fin.city.level} уровень`);
  assert.ok(fin.city.net > 0);
  assert.ok(pop[6] > pop[2], `после 3-го дня рост остановился: ${pop[2]} → ${pop[6]}`);
});
