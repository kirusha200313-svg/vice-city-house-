-- Схема PostgreSQL для игры «Мой город». Скрипт идемпотентный: его можно выполнять при каждом старте.

CREATE TABLE IF NOT EXISTS cities (
  id              BIGSERIAL PRIMARY KEY,
  telegram_id     BIGINT           NOT NULL,
  name            TEXT             NOT NULL,
  name_key        TEXT             NOT NULL,              -- нижний регистр, ё=е: по нему проверяется уникальность названия
  mayor_name      TEXT             NOT NULL,
  coins           BIGINT           NOT NULL,
  carry           DOUBLE PRECISION NOT NULL DEFAULT 0,   -- дробная часть накопленного дохода
  crystals        INTEGER          NOT NULL DEFAULT 0,
  xp              INTEGER          NOT NULL DEFAULT 0,
  level           SMALLINT         NOT NULL DEFAULT 1,
  happiness_bonus INTEGER          NOT NULL DEFAULT 0,
  road_repairs    INTEGER          NOT NULL DEFAULT 0,
  solved          INTEGER          NOT NULL DEFAULT 0,
  total_earned    BIGINT           NOT NULL DEFAULT 0,
  milestone       SMALLINT         NOT NULL DEFAULT 0,
  -- денормализованные значения (пересчитываются сервером при каждом изменении) — нужны для рейтинга
  population      INTEGER          NOT NULL DEFAULT 0,
  happiness       SMALLINT         NOT NULL DEFAULT 0,
  net_income      DOUBLE PRECISION NOT NULL DEFAULT 0,
  tick_at         TIMESTAMPTZ      NOT NULL,             -- до какого момента начислен доход
  gen_at          TIMESTAMPTZ      NOT NULL,             -- когда последний раз генерировались посты
  created_at      TIMESTAMPTZ      NOT NULL DEFAULT now(),
  CONSTRAINT cities_telegram_id_uq UNIQUE (telegram_id),
  CONSTRAINT cities_coins_nonneg CHECK (coins >= 0),
  CONSTRAINT cities_crystals_nonneg CHECK (crystals >= 0),
  CONSTRAINT cities_level_range CHECK (level BETWEEN 1 AND 8)
);

CREATE UNIQUE INDEX IF NOT EXISTS cities_name_key_uq ON cities (name_key);
CREATE INDEX IF NOT EXISTS cities_rank_population_idx ON cities (population DESC, level DESC, created_at ASC, id ASC);
CREATE INDEX IF NOT EXISTS cities_rank_level_idx ON cities (level DESC, population DESC, created_at ASC, id ASC);

-- Постройки города. Порядок по id = порядок строительства (по нему клиент раскладывает город по участкам).
CREATE TABLE IF NOT EXISTS buildings (
  id       BIGSERIAL PRIMARY KEY,
  city_id  BIGINT      NOT NULL REFERENCES cities (id) ON DELETE CASCADE,
  type     TEXT        NOT NULL,
  built_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS buildings_city_idx ON buildings (city_id, id);

-- Посты ленты «Подслушано» и задания от жителей.
CREATE TABLE IF NOT EXISTS quests (
  id           UUID PRIMARY KEY,
  city_id      BIGINT      NOT NULL REFERENCES cities (id) ON DELETE CASCADE,
  template     TEXT        NOT NULL,
  category     TEXT        NOT NULL,   -- complaint | request | suggestion | thanks | news | event
  kind         TEXT        NOT NULL,   -- pay | build | info
  status       TEXT        NOT NULL,   -- open | done | info
  npc_name     TEXT        NOT NULL,
  npc_role     TEXT        NOT NULL,
  avatar       INTEGER     NOT NULL,
  text         TEXT        NOT NULL,
  cost         INTEGER,
  building     TEXT,
  baseline     INTEGER,
  reward_coins INTEGER     NOT NULL DEFAULT 0,
  reward_xp    INTEGER     NOT NULL DEFAULT 0,
  reward_happy INTEGER     NOT NULL DEFAULT 0,
  created_at   TIMESTAMPTZ NOT NULL,
  solved_at    TIMESTAMPTZ,
  CONSTRAINT quests_status_chk CHECK (status IN ('open', 'done', 'info'))
);
CREATE INDEX IF NOT EXISTS quests_city_idx ON quests (city_id, created_at DESC);

-- Журнал обработанных запросов: защита от повторной обработки (двойной тап, повтор по сети).
CREATE TABLE IF NOT EXISTS request_log (
  city_id    BIGINT      NOT NULL REFERENCES cities (id) ON DELETE CASCADE,
  request_id TEXT        NOT NULL,
  response   JSONB       NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (city_id, request_id)
);
CREATE INDEX IF NOT EXISTS request_log_city_idx ON request_log (city_id, created_at DESC);
