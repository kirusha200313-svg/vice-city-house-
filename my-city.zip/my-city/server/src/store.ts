// Контракт хранилища. Игровая логика (service.ts) работает только через него,
// поэтому её можно проверять на MemoryStore, а в проде использовать PostgreSQL (pgStore.ts).

export type QuestCategory = 'complaint' | 'request' | 'suggestion' | 'thanks' | 'news' | 'event';

export interface QuestRow {
  id: string; // UUID, создаётся приложением
  template: string;
  category: QuestCategory;
  kind: 'pay' | 'build' | 'info';
  status: 'open' | 'done' | 'info';
  npcName: string;
  npcRole: string;
  avatar: number;
  text: string;
  cost: number | null;
  building: string | null;
  baseline: number | null;
  rewardCoins: number;
  rewardXp: number;
  rewardHappy: number;
  createdAt: number;
  solvedAt: number | null;
}

export interface CityRow {
  id: string;
  telegramId: string;
  name: string;
  mayor: string;
  coins: number;
  carry: number;
  crystals: number;
  xp: number;
  level: number;
  happinessBonus: number;
  roadRepairs: number;
  solved: number;
  totalEarned: number;
  milestone: number;
  // денормализованные значения для рейтинга
  population: number;
  happiness: number;
  net: number;
  tickAt: number;
  genAt: number;
  createdAt: number;
}

export interface CityTx {
  city: CityRow;
  /** Типы построек в порядке строительства. Можно добавлять в конец и менять тип на месте (улучшение). */
  buildings: string[];
  /** Последние посты ленты, новые в конце. Можно менять поля и добавлять. */
  quests: QuestRow[];
  /** Ответ на уже обработанный requestId (защита от двойной отправки) */
  replay(requestId: string): unknown | undefined;
  record(requestId: string, response: unknown): void;
}

export interface RatingRow {
  cityId: string;
  name: string;
  mayor: string;
  population: number;
  level: number;
  thumb: string[];
}

export interface PublicCityRow {
  city: CityRow;
  buildings: string[];
  rank: number;
}

export class StoreError extends Error {
  constructor(public code: 'no_city' | 'name_taken' | 'city_exists', message: string) {
    super(message);
  }
}

export interface Store {
  /** Создаёт город; бросает StoreError('name_taken') / ('city_exists') */
  createCity(city: Omit<CityRow, 'id'>, buildings: string[], quests: QuestRow[]): Promise<void>;
  /**
   * Блокирует город игрока на время fn (SELECT ... FOR UPDATE), выполняет fn и сохраняет изменения
   * атомарно. Если fn бросает ошибку — ничего не сохраняется. Бросает StoreError('no_city').
   */
  withCity<T>(telegramId: string, fn: (tx: CityTx) => T | Promise<T>): Promise<T>;
  rating(sort: 'population' | 'level', limit: number): Promise<{ total: number; rows: RatingRow[] }>;
  /** Позиция города в рейтинге (1 = лучший) */
  rankOf(cityId: string, sort: 'population' | 'level'): Promise<number>;
  cityByTelegramId(telegramId: string): Promise<CityRow | null>;
  publicCity(cityId: string): Promise<PublicCityRow | null>;
  close(): Promise<void>;
}

/** Сравнение для сортировки рейтинга (используется MemoryStore; в SQL то же самое в ORDER BY) */
export function compareForRating(sort: 'population' | 'level') {
  return (a: CityRow, b: CityRow) => {
    const keyA = sort === 'population' ? [a.population, a.level] : [a.level, a.population];
    const keyB = sort === 'population' ? [b.population, b.level] : [b.level, b.population];
    if (keyA[0] !== keyB[0]) return keyB[0] - keyA[0];
    if (keyA[1] !== keyB[1]) return keyB[1] - keyA[1];
    return a.createdAt - b.createdAt;
  };
}
