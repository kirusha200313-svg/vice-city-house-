import { cityNameKey } from '../../shared/game';
import {
  type CityRow, type CityTx, type PublicCityRow, type QuestRow, type RatingRow, type Store,
  StoreError, compareForRating,
} from './store';

interface Record_ {
  city: CityRow;
  buildings: string[];
  quests: QuestRow[];
  requests: Map<string, unknown>;
}

const MAX_QUESTS = 60;
const MAX_REQUESTS = 100;

/**
 * Хранилище в памяти — для локального запуска без базы и для тестов.
 * Данные теряются при перезапуске. В продакшене используйте PgStore (DATABASE_URL).
 */
export class MemoryStore implements Store {
  private byTg = new Map<string, Record_>();
  private seq = 0;
  private locks = new Map<string, Promise<unknown>>();

  async createCity(city: Omit<CityRow, 'id'>, buildings: string[], quests: QuestRow[]): Promise<void> {
    if (this.byTg.has(city.telegramId)) throw new StoreError('city_exists', 'Город уже создан');
    const key = cityNameKey(city.name);
    for (const r of this.byTg.values()) if (cityNameKey(r.city.name) === key) throw new StoreError('name_taken', 'Такое название уже занято');
    this.byTg.set(city.telegramId, {
      city: { ...city, id: String(++this.seq) },
      buildings: [...buildings],
      quests: structuredClone(quests),
      requests: new Map(),
    });
  }

  async withCity<T>(telegramId: string, fn: (tx: CityTx) => T | Promise<T>): Promise<T> {
    // Последовательное выполнение операций одного игрока (аналог FOR UPDATE)
    const prev = this.locks.get(telegramId) ?? Promise.resolve();
    let release!: () => void;
    const gate = new Promise<void>((r) => (release = r));
    const chain = prev.then(() => gate);
    this.locks.set(telegramId, chain);
    await prev;
    try {
      const rec = this.byTg.get(telegramId);
      if (!rec) throw new StoreError('no_city', 'Город не найден');
      const work = {
        city: structuredClone(rec.city),
        buildings: [...rec.buildings],
        quests: structuredClone(rec.quests),
        requests: new Map(rec.requests),
      };
      const tx: CityTx = {
        city: work.city,
        buildings: work.buildings,
        quests: work.quests,
        replay: (id) => work.requests.get(id),
        record: (id, resp) => {
          work.requests.set(id, resp);
          while (work.requests.size > MAX_REQUESTS) work.requests.delete(work.requests.keys().next().value as string);
        },
      };
      const result = await fn(tx);
      // коммит
      rec.city = work.city;
      rec.buildings = work.buildings;
      rec.quests = work.quests.slice(-MAX_QUESTS);
      rec.requests = work.requests;
      return result;
    } finally {
      release();
      if (this.locks.get(telegramId) === chain) this.locks.delete(telegramId);
    }
  }

  private sorted(sort: 'population' | 'level'): Record_[] {
    return [...this.byTg.values()].sort((a, b) => compareForRating(sort)(a.city, b.city));
  }

  async rating(sort: 'population' | 'level', limit: number): Promise<{ total: number; rows: RatingRow[] }> {
    const all = this.sorted(sort);
    return {
      total: all.length,
      rows: all.slice(0, limit).map((r) => ({
        cityId: r.city.id, name: r.city.name, mayor: r.city.mayor,
        population: r.city.population, level: r.city.level, thumb: [...r.buildings],
      })),
    };
  }

  async rankOf(cityId: string, sort: 'population' | 'level'): Promise<number> {
    const idx = this.sorted(sort).findIndex((r) => r.city.id === cityId);
    return idx < 0 ? 0 : idx + 1;
  }

  async cityByTelegramId(telegramId: string): Promise<CityRow | null> {
    const r = this.byTg.get(telegramId);
    return r ? structuredClone(r.city) : null;
  }

  async publicCity(cityId: string): Promise<PublicCityRow | null> {
    for (const r of this.byTg.values()) {
      if (r.city.id === cityId) return { city: structuredClone(r.city), buildings: [...r.buildings], rank: await this.rankOf(cityId, 'population') };
    }
    return null;
  }

  async close(): Promise<void> {}
}
