// Игровая логика. Всё, что меняет деньги, опыт, население и награды, считается ТОЛЬКО здесь.
import type { ActionResponse, CityDTO, PublicCityDTO, QuestDTO, RatingEntry, RatingResponse, StateDTO } from '../../shared/api';
import {
  BUILDINGS, CRYSTAL_PACK, MAX_LEVEL, OFFLINE_CAP_HOURS, POP_MILESTONES, START_COINS, START_CRYSTALS,
  START_HAPPINESS_BONUS, START_OLD_HOUSES, checkBuild, checkUpgrade, computeStats, countOf, countsFromList,
  levelName, levelReward, normalizeCityName, unlockedAtLevel, validateCityName, xpToNext,
} from '../../shared/game';
import { type Rng, generatePost, newsPost, starterPosts, thanksPost } from './quests';
import { type CityRow, type CityTx, type QuestRow, type Store, StoreError } from './store';
import { type TgUser, mayorNameOf } from './telegram';

export class GameError extends Error {
  constructor(public code: string, message: string, public status = 400) {
    super(message);
  }
}

export interface ServiceOpts {
  now?: () => number;
  rng?: Rng;
  /** Как часто в ленте появляется новый пост */
  genIntervalMs?: number;
}

const REQUEST_ID_RE = /^[A-Za-z0-9_-]{8,64}$/;
const MAX_FEED = 40;

export class GameService {
  private now: () => number;
  private rng: Rng;
  private genIntervalMs: number;

  constructor(private store: Store, opts: ServiceOpts = {}) {
    this.now = opts.now ?? Date.now;
    this.rng = opts.rng ?? Math.random;
    this.genIntervalMs = opts.genIntervalMs ?? 90_000;
  }

  // ------------------------------------------------------------ вспомогательное

  private stats(tx: CityTx) {
    return computeStats(countsFromList(tx.buildings), tx.city.roadRepairs, tx.city.happinessBonus);
  }

  /** Пересчёт денормализованных полей + вехи населения. */
  private refresh(tx: CityTx) {
    const s = this.stats(tx);
    const c = tx.city;
    c.population = s.population;
    c.happiness = s.happiness;
    c.net = s.net;
    let reached = c.milestone;
    while (reached < POP_MILESTONES.length && s.population >= POP_MILESTONES[reached]) reached++;
    if (reached > c.milestone) {
      c.milestone = reached;
      tx.quests.push(newsPost(`Население города превысило ${POP_MILESTONES[reached - 1]} человек! Город растёт.`, this.rng, this.now()));
    }
  }

  /** Начисление дохода за прошедшее время + генерация постов. Вызывается в начале каждой операции. */
  private tick(tx: CityTx, user?: TgUser) {
    const c = tx.city;
    const now = this.now();
    if (user) c.mayor = mayorNameOf(user);

    const s = this.stats(tx);
    const hours = Math.min(Math.max(0, now - c.tickAt) / 3_600_000, OFFLINE_CAP_HOURS);
    const total = c.carry + s.net * hours;
    const whole = Math.floor(total);
    c.coins = Math.max(0, c.coins + whole);
    c.carry = total - whole;
    if (whole > 0) c.totalEarned += whole;
    c.tickAt = now;

    if (now - c.genAt >= this.genIntervalMs) {
      const n = Math.min(2, Math.floor((now - c.genAt) / this.genIntervalMs));
      const counts = countsFromList(tx.buildings);
      for (let i = 0; i < n; i++) {
        const post = generatePost({ level: c.level, stats: s, counts }, tx.quests, this.rng, now);
        if (post) tx.quests.push(post);
      }
      c.genAt = now;
    }
    this.refresh(tx);
  }

  private questDTO(q: QuestRow, counts: Record<string, number>): QuestDTO {
    return {
      id: q.id,
      npc: { name: q.npcName, role: q.npcRole, avatar: q.avatar },
      category: q.category,
      kind: q.kind,
      status: q.status,
      text: q.text,
      cost: q.cost ?? undefined,
      building: q.building ?? undefined,
      ready: q.kind === 'build' && q.status === 'open' ? countOf(counts, q.building!) > (q.baseline ?? 0) : undefined,
      reward: { coins: q.rewardCoins, xp: q.rewardXp, happy: q.rewardHappy },
      createdAt: q.createdAt,
      solvedAt: q.solvedAt ?? undefined,
    };
  }

  private cityDTO(tx: CityTx): CityDTO {
    const c = tx.city;
    const counts = countsFromList(tx.buildings);
    const s = computeStats(counts, c.roadRepairs, c.happinessBonus);
    const need = xpToNext(c.level);
    return {
      id: c.id, name: c.name, mayor: c.mayor, level: c.level, levelName: levelName(c.level),
      xp: c.xp, xpNeeded: need, canLevelUp: need !== null && c.xp >= need,
      coins: c.coins, crystals: c.crystals,
      population: s.population, housing: s.housing, happiness: s.happiness,
      buildingsCount: tx.buildings.length,
      grossIncome: s.grossIncome, upkeep: s.upkeep, net: s.net, coverage: s.coverage,
      roadRepairs: c.roadRepairs, happinessBonus: c.happinessBonus, solved: c.solved, totalEarned: c.totalEarned, createdAt: c.createdAt,
    };
  }

  private dto(tx: CityTx): StateDTO {
    const counts = countsFromList(tx.buildings);
    const feed = tx.quests.slice(-MAX_FEED).reverse().map((q) => this.questDTO(q, counts));
    return { now: this.now(), city: this.cityDTO(tx), buildings: [...tx.buildings], quests: feed };
  }

  private requestId(raw: unknown): string | undefined {
    if (raw === undefined || raw === null || raw === '') return undefined;
    if (typeof raw !== 'string' || !REQUEST_ID_RE.test(raw)) throw new GameError('bad_request', 'Некорректный requestId');
    return raw;
  }

  /** Общая обёртка для изменяющих операций: блокировка, идемпотентность, начисление дохода. */
  private async mutate(user: TgUser, rawRequestId: unknown, fn: (tx: CityTx) => Omit<ActionResponse, 'state'> & { state?: never }): Promise<ActionResponse> {
    const requestId = this.requestId(rawRequestId);
    try {
      return await this.store.withCity(user.id, (tx) => {
        if (requestId) {
          const prev = tx.replay(requestId) as ActionResponse | undefined;
          if (prev) return { ...prev, state: this.dto(tx), replayed: true };
        }
        this.tick(tx, user);
        const partial = fn(tx);
        this.refresh(tx);
        const resp: ActionResponse = { ...partial, state: this.dto(tx) };
        if (requestId) tx.record(requestId, { event: resp.event });
        return resp;
      });
    } catch (e) {
      if (e instanceof StoreError && e.code === 'no_city') throw new GameError('no_city', 'Сначала создайте город', 404);
      throw e;
    }
  }

  // ------------------------------------------------------------ публичные операции

  async getState(user: TgUser): Promise<StateDTO | null> {
    try {
      return await this.store.withCity(user.id, (tx) => {
        this.tick(tx, user);
        return this.dto(tx);
      });
    } catch (e) {
      if (e instanceof StoreError && e.code === 'no_city') return null;
      throw e;
    }
  }

  async createCity(user: TgUser, rawName: unknown): Promise<StateDTO> {
    if (typeof rawName !== 'string') throw new GameError('bad_name', 'Введите название города');
    const err = validateCityName(rawName);
    if (err) throw new GameError('bad_name', err);
    const name = normalizeCityName(rawName);
    const now = this.now();
    const buildings = Array<string>(START_OLD_HOUSES).fill('old_house');
    const counts = countsFromList(buildings);
    const s = computeStats(counts, 0, START_HAPPINESS_BONUS);
    const row: Omit<CityRow, 'id'> = {
      telegramId: user.id, name, mayor: mayorNameOf(user),
      coins: START_COINS, carry: 0, crystals: START_CRYSTALS, xp: 0, level: 1,
      happinessBonus: START_HAPPINESS_BONUS, roadRepairs: 0, solved: 0, totalEarned: 0, milestone: 0,
      population: s.population, happiness: s.happiness, net: s.net,
      tickAt: now, genAt: now, createdAt: now,
    };
    try {
      await this.store.createCity(row, buildings, starterPosts({ level: 1, stats: s, counts }, this.rng, now));
    } catch (e) {
      if (e instanceof StoreError && e.code === 'name_taken') throw new GameError('name_taken', 'Такое название уже занято — придумайте другое', 409);
      if (!(e instanceof StoreError && e.code === 'city_exists')) throw e;
      // город уже есть (повторная отправка формы) — просто вернём его
    }
    const state = await this.getState(user);
    if (!state) throw new GameError('internal', 'Не удалось создать город', 500);
    return state;
  }

  build(user: TgUser, buildingId: unknown, requestId?: unknown): Promise<ActionResponse> {
    return this.mutate(user, requestId, (tx) => {
      const d = typeof buildingId === 'string' ? BUILDINGS[buildingId] : undefined;
      const c = tx.city;
      const counts = countsFromList(tx.buildings);
      const chk = checkBuild({ level: c.level, coins: c.coins, counts, roadRepairs: c.roadRepairs, happinessBonus: c.happinessBonus }, d);
      if (!chk.ok || !d) throw new GameError(chk.ok ? 'unknown' : chk.code, chk.ok ? 'Такого здания нет' : chk.message, chk.ok ? 400 : 409);
      c.coins -= chk.price;
      c.xp += d.xp;
      const first = countOf(counts, d.id) === 0;
      tx.buildings.push(d.id);
      const hasQuest = tx.quests.some((q) => q.status === 'open' && q.kind === 'build' && q.building === d.id);
      if (first && !hasQuest) {
        const p = thanksPost(d.id, this.rng, this.now(), tx.quests[tx.quests.length - 1]?.npcName);
        if (p) tx.quests.push(p);
      }
      return { event: { type: 'built', buildingId: d.id, index: tx.buildings.length - 1 } };
    });
  }

  completeQuest(user: TgUser, questId: unknown, requestId?: unknown): Promise<ActionResponse> {
    return this.mutate(user, requestId, (tx) => {
      const q = typeof questId === 'string' ? tx.quests.find((x) => x.id === questId) : undefined;
      if (!q) throw new GameError('not_found', 'Задание не найдено', 404);
      if (q.status !== 'open') throw new GameError('already_done', 'Это задание уже выполнено', 409);
      const c = tx.city;
      if (q.kind === 'pay') {
        const cost = q.cost ?? 0;
        if (c.coins < cost) throw new GameError('funds', `Не хватает ${cost - c.coins} монет`, 409);
        c.coins -= cost;
        if (q.template === 'pothole') c.roadRepairs += 1;
      } else if (q.kind === 'build') {
        const counts = countsFromList(tx.buildings);
        if (countOf(counts, q.building!) <= (q.baseline ?? 0)) {
          throw new GameError('not_ready', `Сначала постройте: ${BUILDINGS[q.building!]?.name ?? q.building}`, 409);
        }
      } else {
        throw new GameError('not_actionable', 'Это не задание', 400);
      }
      q.status = 'done';
      q.solvedAt = this.now();
      c.coins += q.rewardCoins;
      c.totalEarned += q.rewardCoins;
      c.xp += q.rewardXp;
      c.happinessBonus += q.rewardHappy;
      c.solved += 1;
      if (q.kind === 'build') {
        const p = thanksPost(q.building!, this.rng, this.now(), q.npcName);
        if (p) tx.quests.push(p);
      }
      return { event: { type: 'quest', questId: q.id, reward: { coins: q.rewardCoins, xp: q.rewardXp, happy: q.rewardHappy } } };
    });
  }

  upgrade(user: TgUser, rawIndex: unknown, requestId?: unknown): Promise<ActionResponse> {
    return this.mutate(user, requestId, (tx) => {
      if (typeof rawIndex !== 'number' || !Number.isInteger(rawIndex) || rawIndex < 0 || rawIndex >= tx.buildings.length) {
        throw new GameError('bad_request', 'Некорректная постройка', 400);
      }
      const c = tx.city;
      const from = tx.buildings[rawIndex];
      const counts = countsFromList(tx.buildings);
      const chk = checkUpgrade({ level: c.level, coins: c.coins, counts, roadRepairs: c.roadRepairs, happinessBonus: c.happinessBonus }, from);
      if (!chk.ok) throw new GameError(chk.code, chk.message, 409);
      c.coins -= chk.price;
      c.xp += chk.xp;
      tx.buildings[rawIndex] = chk.target.id;
      return { event: { type: 'upgraded', index: rawIndex, from, to: chk.target.id } };
    });
  }

  levelUp(user: TgUser, requestId?: unknown): Promise<ActionResponse> {
    return this.mutate(user, requestId, (tx) => {
      const c = tx.city;
      const need = xpToNext(c.level);
      if (c.level >= MAX_LEVEL || need === null) throw new GameError('max_level', 'Достигнут максимальный уровень', 409);
      if (c.xp < need) throw new GameError('no_xp', `Нужно ещё ${need - c.xp} опыта`, 409);
      c.xp -= need;
      c.level += 1;
      const r = levelReward(c.level);
      c.coins += r.coins;
      c.totalEarned += r.coins;
      c.crystals += r.crystals;
      tx.quests.push(newsPost(`Город вырос: теперь это «${levelName(c.level)}»! Жители довольны.`, this.rng, this.now()));
      return {
        event: { type: 'levelup', level: c.level, name: levelName(c.level), unlocked: unlockedAtLevel(c.level).map((b) => b.id), reward: r },
      };
    });
  }

  exchange(user: TgUser, rawPacks: unknown, requestId?: unknown): Promise<ActionResponse> {
    return this.mutate(user, requestId, (tx) => {
      const packs = Number(rawPacks);
      if (!Number.isInteger(packs) || packs < 1 || packs > 20) throw new GameError('bad_request', 'Некорректное количество', 400);
      const c = tx.city;
      const crystals = packs * CRYSTAL_PACK.crystals;
      if (c.crystals < crystals) throw new GameError('funds', 'Не хватает кристаллов', 409);
      c.crystals -= crystals;
      const coins = packs * CRYSTAL_PACK.coins;
      c.coins += coins;
      return { event: { type: 'exchange', coins } };
    });
  }

  async rating(user: TgUser, rawSort: unknown): Promise<RatingResponse> {
    const sort = rawSort === 'level' ? 'level' : 'population';
    const [{ total, rows }, mine] = await Promise.all([this.store.rating(sort, 50), this.store.cityByTelegramId(user.id)]);
    const entries: RatingEntry[] = rows.map((r, i) => ({
      cityId: r.cityId, rank: i + 1, name: r.name, mayor: r.mayor, population: r.population, level: r.level,
      thumb: r.thumb, isMe: mine?.id === r.cityId,
    }));
    let me: RatingEntry | null = entries.find((e) => e.isMe) ?? null;
    if (!me && mine) {
      const full = await this.store.publicCity(mine.id);
      me = {
        cityId: mine.id, rank: await this.store.rankOf(mine.id, sort), name: mine.name, mayor: mine.mayor,
        population: mine.population, level: mine.level, thumb: full?.buildings ?? [], isMe: true,
      };
    }
    return { sort, total, entries, me };
  }

  async publicCity(rawId: unknown): Promise<PublicCityDTO> {
    if (typeof rawId !== 'string' || !/^[0-9]{1,18}$/.test(rawId)) throw new GameError('not_found', 'Город не найден', 404);
    const r = await this.store.publicCity(rawId);
    if (!r) throw new GameError('not_found', 'Город не найден', 404);
    return {
      id: r.city.id, name: r.city.name, mayor: r.city.mayor, level: r.city.level, levelName: levelName(r.city.level),
      population: r.city.population, happiness: r.city.happiness, buildingsCount: r.buildings.length,
      roadRepairs: r.city.roadRepairs, rank: r.rank, buildings: r.buildings, createdAt: r.city.createdAt,
    };
  }
}
