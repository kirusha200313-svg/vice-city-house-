// Жители (NPC), шаблоны постов «Подслушано» и генерация заданий по состоянию города.
import { randomUUID } from 'node:crypto';
import { BUILDINGS, type Counts, type Stats, countOf } from '../../shared/game';
import type { QuestRow } from './store';

export type Rng = () => number;

export interface NpcDef { name: string; role: string }

export const NPCS: NpcDef[] = [
  { name: 'Мария', role: 'Мама двоих детей' },
  { name: 'Артём', role: 'Студент' },
  { name: 'Галина Петровна', role: 'Жительница города' },
  { name: 'Иван Сергеевич', role: 'Водитель автобуса' },
  { name: 'Ольга', role: 'Учительница' },
  { name: 'Дядя Коля', role: 'Сосед' },
  { name: 'Светлана', role: 'Продавщица' },
  { name: 'Виктор', role: 'Таксист' },
  { name: 'Анна', role: 'Медсестра' },
  { name: 'Тимофей', role: 'Школьник' },
  { name: 'Зинаида Павловна', role: 'Пенсионерка' },
  { name: 'Денис', role: 'Фермер' },
  { name: 'Юлия', role: 'Блогер' },
  { name: 'Фёдор', role: 'Пенсионер' },
  { name: 'Наталья', role: 'Владелица кафе' },
  { name: 'Руслан', role: 'Строитель' },
  { name: 'Евгения', role: 'Врач' },
  { name: 'Кирилл', role: 'Велосипедист' },
];

const STREETS = ['Солнечная', 'Лесная', 'Центральная', 'Речная', 'Садовая', 'Школьная', 'Полевая', 'Мира', 'Заречная', 'Липовая'];

export interface GenCtx {
  level: number;
  stats: Stats;
  counts: Counts;
}

interface Template {
  key: string;
  category: 'complaint' | 'request' | 'suggestion';
  kind: 'pay' | 'build';
  building?: string;
  /** базовая стоимость (pay) */
  cost?: number;
  coins: number;
  xp: number;
  happy: number;
  texts: string[];
  weight: (c: GenCtx) => number;
}

const unlocked = (c: GenCtx, id: string) => {
  const d = BUILDINGS[id];
  if (!d || c.level < d.minLevel) return false;
  return d.maxCount === undefined || countOf(c.counts, id) < d.maxCount;
};
const houses = (c: GenCtx) => c.stats.houses;

export const TEMPLATES: Template[] = [
  // ----- платные задания (потратить монеты)
  {
    key: 'pothole', category: 'complaint', kind: 'pay', cost: 120, coins: 170, xp: 25, happy: 4,
    texts: [
      'Мэр, пожалуйста, обратите внимание на улицу {street}! Там уже неделю огромная яма.',
      'На улице {street} после дождя огромная яма. Когда починят?',
      'Дорогой мэр, ямы на улице {street} — это уже не дорога, а полоса препятствий. Помогите!',
      'Жители улицы {street} просят отремонтировать дорогу. Там уже месяц яма!',
    ],
    weight: (c) => (c.stats.coverage.roads < 0.7 ? 3 : 1),
  },
  {
    key: 'garbage', category: 'complaint', kind: 'pay', cost: 80, coins: 120, xp: 15, happy: 3,
    texts: [
      'Мэр, возле старого дома на улице {street} скопилось много мусора. Помогите нам!',
      'Контейнеры на улице {street} не вывозили уже давно, запах стоит на весь двор.',
      'Добрый день! Во дворе на {street} свалка. Нельзя ли организовать вывоз?',
    ],
    weight: () => 1.5,
  },
  {
    key: 'roof', category: 'request', kind: 'pay', cost: 150, coins: 210, xp: 30, happy: 4,
    texts: [
      'У нас на улице {street} прохудилась крыша общего дома. Пожалуйста, помогите с ремонтом!',
      'Мэр, в доме на {street} течёт крыша. Стыдно перед соседями, а денег у жильцов нет.',
    ],
    weight: () => 1,
  },
  {
    key: 'well', category: 'request', kind: 'pay', cost: 100, coins: 150, xp: 20, happy: 3,
    texts: [
      'Насос у колодца на улице {street} сломался. Воду приходится носить издалека.',
      'Мэр, нам нужен новый насос у колодца на {street}. Совсем неудобно без воды.',
    ],
    weight: (c) => (c.level <= 3 ? 1.5 : 0.7),
  },
  {
    key: 'cleanup', category: 'suggestion', kind: 'pay', cost: 60, coins: 100, xp: 12, happy: 2,
    texts: [
      'Предлагаю устроить субботник на улице {street}: нужны только перчатки и мешки.',
      'Двор на {street} зарос бурьяном. Давайте организуем уборку — я соберу соседей!',
    ],
    weight: () => 1,
  },
  // ----- задания «построить»
  {
    key: 'b_park', category: 'request', kind: 'build', building: 'park', coins: 250, xp: 45, happy: 6,
    texts: [
      'Добрый день! Нам очень не хватает парка в нашем районе. Хотелось бы гулять с детьми.',
      'Мэр, нужен парк в нашем районе! Детям негде гулять.',
      'Хочется свежего воздуха и тени. Когда в городе появится парк?',
    ],
    weight: (c) => (unlocked(c, 'park') && c.stats.coverage.leisure < 0.6 ? 3 : 0),
  },
  {
    key: 'b_square', category: 'suggestion', kind: 'build', building: 'square', coins: 150, xp: 25, happy: 4,
    texts: [
      'Предлагаю сделать небольшой сквер с лавочками — пожилым людям негде посидеть.',
      'Мэр, а что если разбить сквер у дороги? Там пустырь, и он ничему не мешает.',
    ],
    weight: (c) => (unlocked(c, 'square') && c.stats.coverage.leisure < 0.5 ? 2 : 0),
  },
  {
    key: 'b_lighting', category: 'complaint', kind: 'build', building: 'lighting', coins: 160, xp: 30, happy: 5,
    texts: [
      'На центральной улице совсем нет освещения. Вечером очень темно.',
      'Мэр, по вечерам на улицах ничего не видно. Поставьте, пожалуйста, фонари.',
      'Идти домой в темноте страшно. Нужны фонари вдоль дороги!',
    ],
    weight: (c) => (unlocked(c, 'lighting') && c.stats.coverage.lighting < 0.6 ? 3 : 0),
  },
  {
    key: 'b_road', category: 'complaint', kind: 'build', building: 'road', coins: 170, xp: 30, happy: 5,
    texts: [
      'Дорога у нас в плачевном состоянии: то грязь, то колдобины. Нужен нормальный асфальт.',
      'Мэр, автобус боится ездить по нашей улице. Положите асфальт, пожалуйста!',
    ],
    weight: (c) => (unlocked(c, 'road') && c.stats.coverage.roads < 0.8 ? 2.5 : 0),
  },
  {
    key: 'b_sidewalk', category: 'suggestion', kind: 'build', building: 'sidewalk', coins: 140, xp: 25, happy: 3,
    texts: [
      'Люди ходят прямо по проезжей части. Давайте сделаем тротуары!',
      'Предлагаю обустроить тротуары — с колясками по дороге ходить опасно.',
    ],
    weight: (c) => (unlocked(c, 'sidewalk') && houses(c) >= 4 ? 1.2 : 0),
  },
  {
    key: 'b_kindergarten', category: 'request', kind: 'build', building: 'kindergarten', coins: 260, xp: 40, happy: 5,
    texts: [
      'Мэр, в городе нет детского сада. Куда нам отдавать малышей, когда выходить на работу?',
      'Очередь в детский сад, которого нет... Пожалуйста, постройте его!',
    ],
    weight: (c) => (unlocked(c, 'kindergarten') && houses(c) >= 4 && c.stats.coverage.education < 0.5 ? 2 : 0),
  },
  {
    key: 'b_school', category: 'request', kind: 'build', building: 'school', coins: 420, xp: 70, happy: 6,
    texts: [
      'Детям приходится ездить в школу в соседний город. Нужна своя школа!',
      'Мэр, нам очень нужна школа. Население растёт, а учиться негде.',
    ],
    weight: (c) => (unlocked(c, 'school') && houses(c) >= 5 && c.stats.coverage.education < 0.6 ? 2.5 : 0),
  },
  {
    key: 'b_police', category: 'complaint', kind: 'build', building: 'police', coins: 350, xp: 60, happy: 5,
    texts: [
      'По вечерам у магазина шумят, а участкового у нас нет. Постройте полицейский участок!',
      'Мэр, у нас стали пропадать велосипеды. Городу нужна полиция.',
    ],
    weight: (c) => (unlocked(c, 'police') && houses(c) >= 6 && c.stats.coverage.safety < 0.5 ? 2 : 0),
  },
  {
    key: 'b_fire', category: 'request', kind: 'build', building: 'fire', coins: 420, xp: 70, happy: 5,
    texts: [
      'У соседей вчера загорелась сажа в трубе — пожарные ехали из другого города. Нужна своя станция!',
      'Мэр, а если пожар? Нам срочно нужна пожарная станция.',
    ],
    weight: (c) => (unlocked(c, 'fire') && houses(c) >= 6 && c.stats.coverage.safety < 0.6 ? 2 : 0),
  },
  {
    key: 'b_hospital', category: 'request', kind: 'build', building: 'hospital', coins: 900, xp: 140, happy: 8,
    texts: [
      'Скорая едет к нам больше часа. Городу нужна своя больница!',
      'Мэр, врачей у нас по пальцам пересчитать. Пожалуйста, постройте больницу.',
    ],
    weight: (c) => (unlocked(c, 'hospital') && c.stats.population >= 120 && c.stats.coverage.health < 0.5 ? 2.5 : 0),
  },
  {
    key: 'b_mall', category: 'suggestion', kind: 'build', building: 'mall', coins: 1500, xp: 220, happy: 7,
    texts: [
      'Кажется, нам пора открыть ещё один магазин. Население растёт, а покупать продукты негде.',
      'Предлагаю построить торговый центр — за покупками приходится ездить за город.',
    ],
    weight: (c) => (unlocked(c, 'mall') && c.stats.population >= 150 && c.stats.coverage.commerce < 0.5 ? 2 : 0),
  },
  {
    key: 'b_cinema', category: 'suggestion', kind: 'build', building: 'cinema', coins: 600, xp: 100, happy: 6,
    texts: [
      'Мэр, а давайте построим кинотеатр? По вечерам молодёжи совсем нечем заняться.',
      'Было бы здорово посмотреть новое кино не в соседнем городе. Предлагаю кинотеатр!',
    ],
    weight: (c) => (unlocked(c, 'cinema') && c.stats.coverage.leisure >= 0.4 ? 1.2 : 0),
  },
  {
    key: 'b_parking', category: 'request', kind: 'build', building: 'parking', coins: 300, xp: 50, happy: 3,
    texts: [
      'Машины стоят прямо на газонах. Нужна нормальная парковка!',
      'Мэр, во дворах не протолкнуться из-за машин. Сделайте парковку, пожалуйста.',
    ],
    weight: (c) => (unlocked(c, 'parking') && houses(c) >= 8 ? 1.2 : 0),
  },
];

// посты без заданий
export const EVENT_TEXTS: { category: 'event' | 'news'; text: string }[] = [
  { category: 'event', text: 'Сегодня утром над городом стоял такой туман, что автобус остановился «по ощущениям». Но все добрались!' },
  { category: 'event', text: 'Кот Васька снова гулял по крыше мэрии. Никто не пострадал, кот в восторге.' },
  { category: 'event', text: 'Соседи вышли на субботник и привели в порядок двор. Стало заметно чище!' },
  { category: 'news', text: 'В городе прошла осенняя ярмарка: яблоки, мёд и пироги разобрали за час.' },
  { category: 'event', text: 'Ночью был ураганный ветер, но город выстоял. Жители благодарят коммунальщиков.' },
  { category: 'news', text: 'В библиотеке открыли кружок для детей. Записалось уже двадцать человек!' },
  { category: 'event', text: 'Кто-то оставил у входа в мэрию корзину яблок с запиской «Мэру на удачу».' },
  { category: 'news', text: 'Местные ребята организовали футбольный матч «улица на улицу». Победила дружба.' },
  { category: 'event', text: 'В пекарне на углу хлеб закончился уже в девять утра — очередь стояла до самого перекрёстка.' },
  { category: 'event', text: 'Всю ночь шёл дождь, а утром над городом появилась радуга. Все высыпали во дворы с телефонами!' },
  { category: 'news', text: 'У пруда поставили новую скамейку. Говорят, на ней уже сделали два предложения руки и сердца.' },
  { category: 'event', text: 'Дворник дядя Миша поймал сбежавшую курицу и вернул хозяевам. Вся улица аплодировала.' },
  { category: 'news', text: 'В городе прошёл день соседей: накрыли столы прямо во дворе и пели под гитару.' },
  { category: 'event', text: 'Под окнами мэрии кто-то нарисовал мелом классики. Дети не расходятся до вечера.' },
  { category: 'event', text: 'Автобус сегодня пришёл вовремя — жители предлагают занести это в летопись города.' },
  { category: 'news', text: 'Школьники собрали макулатуру и выиграли районный конкурс. Весь класс гордится!' },
  { category: 'event', text: 'На городском пруду поселился лебедь. Жители уже спорят, как его назвать.' },
  { category: 'event', text: 'На рынке продавали первые арбузы — разобрали за полчаса.' },
  { category: 'news', text: 'Местный хор дал концерт на площади. Подпевали все, даже те, кто не знал слов.' },
  { category: 'event', text: 'Ночью выпал первый снег, и город сразу стал похож на открытку.' },
  { category: 'event', text: 'Двое соседей наконец помирились после трёхлетнего спора о заборе. Мир во дворах!' },
  { category: 'news', text: 'В городе заработал книжный обмен: берёшь книгу — оставляешь свою.' },
  { category: 'event', text: 'На улице {street} открылся маленький цветочный киоск. Теперь там пахнет ромашками.' },
  { category: 'event', text: 'Жители улицы {street} устроили чаепитие прямо у подъезда. Мэра тоже звали!' },
  { category: 'event', text: 'На улице {street} по утрам теперь поёт соловей — соседи записывают его на телефон.' },
  { category: 'event', text: 'Мальчишки с улицы {street} построили во дворе настоящий штаб из коробок.' },
  { category: 'event', text: 'На улице {street} нашёлся чей-то щенок. К вечеру он уже вернулся к хозяевам.' },
  { category: 'news', text: 'Жители улицы {street} вместе покрасили забор. Получилось ярко и весело!' },
];

export const THANKS: Record<string, string[]> = {
  school: ['Ура! В нашем городе наконец-то построили новую школу! Спасибо мэру!', 'Школа открыта! Дети в восторге, родители — тоже. Спасибо!'],
  kindergarten: ['Детский сад открылся! Малыши уже подружились. Огромное спасибо, мэр!'],
  hospital: ['Теперь у города есть своя больница. Спасибо вам, мэр, за заботу о здоровье!'],
  park: ['В парке уже полно гуляющих с колясками. Спасибо, мэр!', 'Такой парк получился — не нарадуемся. Спасибо!'],
  square: ['Сквер получился уютным: бабушки заняли лавочки. Благодарим!'],
  lighting: ['Фонари зажглись! Теперь вечером можно спокойно ходить по улицам. Спасибо!'],
  road: ['Асфальт ровный как стол! Автобус теперь ходит без тряски. Спасибо мэру!'],
  police: ['Теперь у нас есть свой участковый. Спокойнее стало, спасибо!'],
  fire: ['Пожарная станция заработала — на душе спокойнее. Спасибо!'],
  mall: ['В торговом центре и продукты, и кафе. Больше не нужно ездить за покупками. Спасибо!'],
  cinema: ['Сходили на сеанс в нашем кинотеатре. Было здорово, спасибо!'],
  sidewalk: ['С коляской по тротуару — одно удовольствие. Спасибо, мэр!'],
  parking: ['Дворы наконец освободились от машин. Спасибо за парковку!'],
  stadium: ['Первый матч на нашем стадионе — это было что-то! Спасибо, мэр!'],
  bridge: ['Мост через канал — теперь до центра пять минут вместо получаса. Спасибо!'],
};

// ---------------------------------------------------------------- генерация

const hashStr = (s: string) => {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
};
export const avatarSeedOf = (name: string) => hashStr(name) % 100000;

const pick = <T,>(arr: T[], rng: Rng): T => arr[Math.floor(rng() * arr.length)];
const roundTo = (n: number, step: number) => Math.max(step, Math.round(n / step) * step);
const scale = (level: number) => 1 + 0.6 * (level - 1);

function npc(rng: Rng, avoid?: string): NpcDef {
  for (let i = 0; i < 6; i++) {
    const n = pick(NPCS, rng);
    if (n.name !== avoid) return n;
  }
  return pick(NPCS, rng);
}

export function newRow(partial: Partial<QuestRow> & Pick<QuestRow, 'category' | 'kind' | 'status' | 'text' | 'template'>, rng: Rng, now: number, avoidNpc?: string): QuestRow {
  const n = npc(rng, avoidNpc);
  return {
    id: randomUUID(), npcName: n.name, npcRole: n.role, avatar: avatarSeedOf(n.name),
    cost: null, building: null, baseline: null, rewardCoins: 0, rewardXp: 0, rewardHappy: 0,
    createdAt: now, solvedAt: null, ...partial,
  };
}

/** Выбирает пост для генерации. Возвращает null, если нечего добавить. */
export function generatePost(ctx: GenCtx, existing: QuestRow[], rng: Rng, now: number): QuestRow | null {
  const open = existing.filter((q) => q.status === 'open');
  const openKeys = new Set(open.map((q) => q.template));
  const recentTexts = new Set(existing.slice(-18).map((q) => q.text));
  const recentTemplateTexts = new Set(existing.slice(-12).map((q) => q.text));
  const lastNpc = existing[existing.length - 1]?.npcName;
  const k = scale(ctx.level);

  // обычно — задание; иногда — просто новость, чтобы лента была живой
  const wantEvent = open.length >= 4 || rng() < 0.22;
  if (!wantEvent) {
    const recentKeys = new Set(existing.slice(-3).map((q) => q.template));
    const cands = TEMPLATES
      .map((t) => ({ t, w: openKeys.has(t.key) ? 0 : t.weight(ctx) * (recentKeys.has(t.key) ? 0.3 : 1) }))
      .filter((x) => x.w > 0);
    const total = cands.reduce((s, x) => s + x.w, 0);
    if (total > 0) {
      let r = rng() * total;
      let chosen = cands[0].t;
      for (const c of cands) { r -= c.w; if (r <= 0) { chosen = c.t; break; } }
      let text = '';
      for (let i = 0; i < 8; i++) {
        text = pick(chosen.texts, rng).replace('{street}', pick(STREETS, rng));
        if (!recentTemplateTexts.has(text)) break;
      }
      const cost = chosen.kind === 'pay' ? roundTo((chosen.cost ?? 0) * k, 10) : null;
      return newRow({
        template: chosen.key, category: chosen.category, kind: chosen.kind, status: 'open', text,
        cost, building: chosen.building ?? null,
        baseline: chosen.building ? countOf(ctx.counts, chosen.building) : null,
        rewardCoins: roundTo(chosen.coins * k, 10), rewardXp: roundTo(chosen.xp * (1 + 0.4 * (ctx.level - 1)), 5), rewardHappy: chosen.happy,
      }, rng, now, lastNpc);
    }
  }
  const all = EVENT_TEXTS.map((e) => ({ category: e.category, text: e.text.replace('{street}', pick(STREETS, rng)) }));
  const fresh = all.filter((e) => !recentTexts.has(e.text));
  const e = pick(fresh.length ? fresh : all, rng);
  return newRow({ template: 'event', category: e.category, kind: 'info', status: 'info', text: e.text }, rng, now, lastNpc);
}

export function thanksPost(buildingId: string, rng: Rng, now: number, avoidNpc?: string): QuestRow | null {
  const texts = THANKS[buildingId];
  if (!texts) return null;
  return newRow({ template: `thanks_${buildingId}`, category: 'thanks', kind: 'info', status: 'info', text: pick(texts, rng) }, rng, now, avoidNpc);
}

export function newsPost(text: string, rng: Rng, now: number): QuestRow {
  return newRow({ template: 'news', category: 'news', kind: 'info', status: 'info', text }, rng, now);
}

/** Стартовые посты при создании города */
export function starterPosts(ctx: GenCtx, rng: Rng, now: number): QuestRow[] {
  const mk = (key: string, minus: number) => {
    const t = TEMPLATES.find((x) => x.key === key)!;
    const text = pick(t.texts, rng).replace('{street}', pick(STREETS, rng));
    return newRow({
      template: t.key, category: t.category, kind: t.kind, status: 'open', text,
      cost: t.kind === 'pay' ? t.cost! : null, building: t.building ?? null,
      baseline: t.building ? countOf(ctx.counts, t.building) : null,
      rewardCoins: t.coins, rewardXp: t.xp, rewardHappy: t.happy, createdAt: now - minus,
    }, rng, now);
  };
  const welcome = newRow({
    template: 'news', category: 'news', kind: 'info', status: 'info', createdAt: now - 60_000,
    text: 'В городе новый мэр! Три старых домика, разбитая дорога и большие надежды. Мы в вас верим!',
  }, rng, now);
  return [welcome, mk('b_square', 30_000), mk('pothole', 0)];
}
