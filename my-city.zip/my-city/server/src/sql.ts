// Все SQL-запросы в одном месте — так их можно проверить на реальной базе (scripts/check-sql.sh).

const CITY_COLS = `
  c.id::text AS id, c.telegram_id::text AS "telegramId", c.name, c.mayor_name AS mayor,
  c.coins::float8 AS coins, c.carry, c.crystals, c.xp, c.level, c.happiness_bonus AS "happinessBonus",
  c.road_repairs AS "roadRepairs", c.solved, c.total_earned::float8 AS "totalEarned", c.milestone,
  c.population, c.happiness, c.net_income AS net,
  (extract(epoch FROM c.tick_at) * 1000)::float8 AS "tickAt",
  (extract(epoch FROM c.gen_at) * 1000)::float8 AS "genAt",
  (extract(epoch FROM c.created_at) * 1000)::float8 AS "createdAt"`;

export const SQL = {
  lockCity: `SELECT ${CITY_COLS} FROM cities c WHERE c.telegram_id = $1::bigint FOR UPDATE`,
  cityByTg: `SELECT ${CITY_COLS} FROM cities c WHERE c.telegram_id = $1::bigint`,
  cityById: `SELECT ${CITY_COLS} FROM cities c WHERE c.id = $1::bigint`,

  buildings: `SELECT type FROM buildings WHERE city_id = $1::bigint ORDER BY id`,
  quests: `
    SELECT id::text AS id, template, category, kind, status, npc_name AS "npcName", npc_role AS "npcRole", avatar, text,
           cost, building, baseline, reward_coins AS "rewardCoins", reward_xp AS "rewardXp", reward_happy AS "rewardHappy",
           (extract(epoch FROM created_at) * 1000)::float8 AS "createdAt",
           (extract(epoch FROM solved_at) * 1000)::float8 AS "solvedAt"
    FROM (SELECT * FROM quests WHERE city_id = $1::bigint ORDER BY created_at DESC, id DESC LIMIT 60) q
    ORDER BY created_at ASC, id ASC`,
  requests: `SELECT request_id AS "requestId", response FROM request_log WHERE city_id = $1::bigint ORDER BY created_at DESC LIMIT 100`,

  insertCity: `
    INSERT INTO cities (telegram_id, name, mayor_name, coins, carry, crystals, xp, level, happiness_bonus, road_repairs, solved,
                        total_earned, milestone, population, happiness, net_income, tick_at, gen_at, created_at, name_key)
    VALUES ($1::bigint, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16,
            to_timestamp($17::float8 / 1000.0), to_timestamp($18::float8 / 1000.0), to_timestamp($19::float8 / 1000.0), $20)
    RETURNING id::text AS id`,
  updateCity: `
    UPDATE cities SET mayor_name = $2, coins = $3, carry = $4, crystals = $5, xp = $6, level = $7, happiness_bonus = $8,
      road_repairs = $9, solved = $10, total_earned = $11, milestone = $12, population = $13, happiness = $14, net_income = $15,
      tick_at = to_timestamp($16::float8 / 1000.0), gen_at = to_timestamp($17::float8 / 1000.0)
    WHERE id = $1::bigint`,
  deleteBuildings: `DELETE FROM buildings WHERE city_id = $1::bigint`,
  insertBuildings: `INSERT INTO buildings (city_id, type) SELECT $1::bigint, t.type FROM unnest($2::text[]) WITH ORDINALITY AS t(type, ord) ORDER BY t.ord`,
  upsertQuest: `
    INSERT INTO quests (id, city_id, template, category, kind, status, npc_name, npc_role, avatar, text, cost, building, baseline,
                        reward_coins, reward_xp, reward_happy, created_at, solved_at)
    VALUES ($1::uuid, $2::bigint, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16,
            to_timestamp($17::float8 / 1000.0),
            CASE WHEN $18::float8 IS NULL THEN NULL ELSE to_timestamp($18::float8 / 1000.0) END)
    ON CONFLICT (id) DO UPDATE SET status = EXCLUDED.status, solved_at = EXCLUDED.solved_at`,
  pruneQuests: `
    DELETE FROM quests WHERE city_id = $1::bigint AND id NOT IN
      (SELECT id FROM quests WHERE city_id = $1::bigint ORDER BY created_at DESC, id DESC LIMIT 60)`,
  insertRequest: `INSERT INTO request_log (city_id, request_id, response) VALUES ($1::bigint, $2, $3::jsonb) ON CONFLICT DO NOTHING`,
  pruneRequests: `
    DELETE FROM request_log WHERE city_id = $1::bigint AND request_id NOT IN
      (SELECT request_id FROM request_log WHERE city_id = $1::bigint ORDER BY created_at DESC LIMIT 100)`,

  total: `SELECT count(*)::int AS total FROM cities`,
  ratingPopulation: `
    SELECT c.id::text AS "cityId", c.name, c.mayor_name AS mayor, c.population, c.level,
           COALESCE((SELECT array_agg(b.type ORDER BY b.id) FROM buildings b WHERE b.city_id = c.id), ARRAY[]::text[]) AS thumb
    FROM cities c ORDER BY c.population DESC, c.level DESC, c.created_at ASC, c.id ASC LIMIT $1::int`,
  ratingLevel: `
    SELECT c.id::text AS "cityId", c.name, c.mayor_name AS mayor, c.population, c.level,
           COALESCE((SELECT array_agg(b.type ORDER BY b.id) FROM buildings b WHERE b.city_id = c.id), ARRAY[]::text[]) AS thumb
    FROM cities c ORDER BY c.level DESC, c.population DESC, c.created_at ASC, c.id ASC LIMIT $1::int`,
  rankPopulation: `
    SELECT (1 + count(*))::int AS rank FROM cities o JOIN cities me ON me.id = $1::bigint
    WHERE o.population > me.population
       OR (o.population = me.population AND o.level > me.level)
       OR (o.population = me.population AND o.level = me.level AND o.created_at < me.created_at)
       OR (o.population = me.population AND o.level = me.level AND o.created_at = me.created_at AND o.id < me.id)`,
  rankLevel: `
    SELECT (1 + count(*))::int AS rank FROM cities o JOIN cities me ON me.id = $1::bigint
    WHERE o.level > me.level
       OR (o.level = me.level AND o.population > me.population)
       OR (o.level = me.level AND o.population = me.population AND o.created_at < me.created_at)
       OR (o.level = me.level AND o.population = me.population AND o.created_at = me.created_at AND o.id < me.id)`,
} as const;
