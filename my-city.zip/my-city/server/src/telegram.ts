import { createHmac, timingSafeEqual } from 'node:crypto';

export interface TgUser {
  id: string;
  firstName: string;
  lastName?: string;
  username?: string;
}

export class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AuthError';
  }
}

/**
 * Проверка Telegram Mini App initData (алгоритм из документации Telegram):
 *  1. разобрать строку как query-параметры;
 *  2. убрать `hash`, остальные пары `key=value` отсортировать по ключу и склеить через \n;
 *  3. secret = HMAC_SHA256(key = "WebAppData", data = bot_token);
 *  4. hash' = hex(HMAC_SHA256(key = secret, data = data_check_string)) — должен совпасть с `hash`.
 * Дополнительно проверяем свежесть auth_date.
 */
export function verifyInitData(initData: string, botToken: string, maxAgeSec: number, nowMs = Date.now()): TgUser {
  if (!initData) throw new AuthError('Нет данных авторизации Telegram');
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  if (!hash || !/^[0-9a-f]{64}$/i.test(hash)) throw new AuthError('Некорректная подпись');

  const pairs: string[] = [];
  for (const [k, v] of params.entries()) if (k !== 'hash') pairs.push(`${k}=${v}`);
  pairs.sort();
  const dataCheckString = pairs.join('\n');

  const secret = createHmac('sha256', 'WebAppData').update(botToken).digest();
  const expected = createHmac('sha256', secret).update(dataCheckString).digest();
  const given = Buffer.from(hash, 'hex');
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) throw new AuthError('Подпись не совпадает');

  const authDate = Number(params.get('auth_date'));
  if (!Number.isFinite(authDate) || authDate <= 0) throw new AuthError('Нет auth_date');
  const age = nowMs / 1000 - authDate;
  if (age > maxAgeSec) throw new AuthError('Сессия Telegram устарела, перезапустите игру');
  if (age < -300) throw new AuthError('auth_date из будущего');

  const rawUser = params.get('user');
  if (!rawUser) throw new AuthError('В initData нет пользователя');
  let u: any;
  try {
    u = JSON.parse(rawUser);
  } catch {
    throw new AuthError('Некорректный user');
  }
  if (u?.id === undefined || u?.id === null || !Number.isSafeInteger(Number(u.id))) throw new AuthError('Некорректный id');
  return {
    id: String(u.id),
    firstName: String(u.first_name ?? '').slice(0, 64),
    lastName: u.last_name ? String(u.last_name).slice(0, 64) : undefined,
    username: u.username ? String(u.username).slice(0, 64) : undefined,
  };
}

/** Собирает initData с валидной подписью — нужно для тестов и локальной отладки. */
export function signInitData(fields: Record<string, string>, botToken: string): string {
  const pairs = Object.entries(fields).map(([k, v]) => `${k}=${v}`).sort();
  const secret = createHmac('sha256', 'WebAppData').update(botToken).digest();
  const hash = createHmac('sha256', secret).update(pairs.join('\n')).digest('hex');
  const p = new URLSearchParams(fields);
  p.set('hash', hash);
  return p.toString();
}

export function mayorNameOf(u: TgUser): string {
  const full = [u.firstName, u.lastName].filter(Boolean).join(' ').trim();
  return (full || u.username || 'Мэр').slice(0, 40);
}
