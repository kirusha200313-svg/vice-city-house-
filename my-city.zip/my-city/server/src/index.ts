import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { existsSync, readFileSync, statSync } from 'node:fs';
import { extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { GameError, GameService } from './service';
import { MemoryStore } from './memoryStore';
import type { Store } from './store';
import { AuthError, type TgUser, verifyInitData } from './telegram';

// Необязательный файл .env (в папке server/ или в корне проекта). Уже заданные переменные окружения не перезаписываются.
for (const file of ['.env', '../.env']) {
  try { process.loadEnvFile(file); } catch { /* файла нет — это нормально */ }
}

const env = process.env;
const PORT = Number(env.PORT ?? 3001);
const BOT_TOKEN = env.BOT_TOKEN ?? '';
const DATABASE_URL = env.DATABASE_URL ?? '';
const DEV_AUTH = env.DEV_AUTH === '1';
const IS_PROD = env.NODE_ENV === 'production';
const INITDATA_MAX_AGE = Number(env.INITDATA_MAX_AGE_SEC ?? 24 * 3600);
const CLIENT_DIR = resolve(env.CLIENT_DIR ?? fileURLToPath(new URL('../../client/dist', import.meta.url)));

if (IS_PROD && DEV_AUTH) throw new Error('DEV_AUTH=1 нельзя использовать вместе с NODE_ENV=production');
if (!DEV_AUTH && !BOT_TOKEN) throw new Error('Задайте BOT_TOKEN (токен бота от @BotFather) или включите DEV_AUTH=1 для локальной отладки');

export async function createStore(): Promise<Store> {
  if (DATABASE_URL) {
    const { PgStore } = await import('./pgStore'); // драйвер pg нужен только при работе с PostgreSQL
    const s = new PgStore(DATABASE_URL, env.PGSSL === '1');
    await s.migrate();
    console.log('[db] PostgreSQL подключён, схема применена');
    return s;
  }
  if (IS_PROD) throw new Error('В production нужен DATABASE_URL (PostgreSQL)');
  console.warn('[db] DATABASE_URL не задан — данные хранятся в памяти и пропадут при перезапуске');
  return new MemoryStore();
}

// ----------------------------------------------------------------- вспомогательное

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.json': 'application/json',
  '.woff2': 'font/woff2', '.map': 'application/json',
};

function send(res: ServerResponse, status: number, body: unknown) {
  const data = JSON.stringify(body);
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(data);
}

async function readBody(req: IncomingMessage): Promise<any> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const ch of req) {
    size += (ch as Buffer).length;
    if (size > 16 * 1024) throw new GameError('too_large', 'Слишком большой запрос', 413);
    chunks.push(ch as Buffer);
  }
  if (!size) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new GameError('bad_json', 'Некорректный JSON', 400);
  }
}

function authenticate(req: IncomingMessage): TgUser {
  const header = String(req.headers.authorization ?? '');
  if (header.startsWith('tma ')) {
    if (!BOT_TOKEN) throw new AuthError('На сервере не задан BOT_TOKEN');
    return verifyInitData(header.slice(4), BOT_TOKEN, INITDATA_MAX_AGE);
  }
  if (DEV_AUTH) {
    // Только для локальной отладки вне Telegram: заголовок "X-Dev-User: 12345:Имя"
    const raw = String(req.headers['x-dev-user'] ?? '');
    const m = /^(\d{1,15}):(.{1,40})$/.exec(raw);
    if (m) return { id: m[1], firstName: decodeURIComponent(m[2]) };
  }
  throw new AuthError('Откройте игру из Telegram');
}

// Простейший ограничитель частоты: не более 40 запросов за 10 секунд на игрока.
const hits = new Map<string, number[]>();
function rateLimit(userId: string) {
  const now = Date.now();
  const arr = (hits.get(userId) ?? []).filter((t) => now - t < 10_000);
  arr.push(now);
  hits.set(userId, arr);
  if (arr.length > 40) throw new GameError('rate_limited', 'Слишком много запросов, подождите немного', 429);
  if (hits.size > 5000) for (const [k, v] of hits) if (now - v[v.length - 1] > 10_000) hits.delete(k);
}

// ----------------------------------------------------------------- маршруты

export function createHandler(game: GameService) {
  return async (req: IncomingMessage, res: ServerResponse) => {
    const url = new URL(req.url ?? '/', 'http://x');
    const path = url.pathname;
    try {
      if (path.startsWith('/api/')) {
        if (path === '/api/health') return send(res, 200, { ok: true });
        const user = authenticate(req);
        rateLimit(user.id);
        const m = req.method ?? 'GET';

        if (m === 'GET' && path === '/api/state') return send(res, 200, { state: await game.getState(user) });
        if (m === 'GET' && path === '/api/rating') return send(res, 200, await game.rating(user, url.searchParams.get('sort')));
        const city = /^\/api\/cities\/([^/]+)$/.exec(path);
        if (m === 'GET' && city) return send(res, 200, await game.publicCity(city[1]));

        if (m === 'POST') {
          const body = await readBody(req);
          if (path === '/api/city') return send(res, 200, { state: await game.createCity(user, body.name) });
          if (path === '/api/build') return send(res, 200, await game.build(user, body.buildingId, body.requestId));
          if (path === '/api/upgrade') return send(res, 200, await game.upgrade(user, body.index, body.requestId));
          if (path === '/api/levelup') return send(res, 200, await game.levelUp(user, body.requestId));
          if (path === '/api/exchange') return send(res, 200, await game.exchange(user, body.packs, body.requestId));
          const q = /^\/api\/quests\/([^/]+)\/complete$/.exec(path);
          if (q) return send(res, 200, await game.completeQuest(user, q[1], body.requestId));
        }
        throw new GameError('not_found', 'Не найдено', 404);
      }
      return serveStatic(req, res, path);
    } catch (e) {
      if (e instanceof AuthError) return send(res, 401, { error: { code: 'unauthorized', message: e.message } });
      if (e instanceof GameError) return send(res, e.status, { error: { code: e.code, message: e.message } });
      console.error('[error]', e);
      return send(res, 500, { error: { code: 'internal', message: 'Внутренняя ошибка сервера' } });
    }
  };
}

function serveStatic(req: IncomingMessage, res: ServerResponse, path: string) {
  if (!existsSync(CLIENT_DIR)) {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    return res.end('Клиент не собран. Выполните: npm run build (или запустите клиент через npm run dev)');
  }
  let file = normalize(join(CLIENT_DIR, decodeURIComponent(path)));
  if (file !== CLIENT_DIR && !file.startsWith(CLIENT_DIR + sep)) {
    res.writeHead(403);
    return res.end();
  }
  const isAsset = path.startsWith('/assets/');
  if (!existsSync(file) || !statSync(file).isFile()) file = join(CLIENT_DIR, 'index.html'); // SPA
  res.writeHead(200, {
    'content-type': MIME[extname(file)] ?? 'application/octet-stream',
    'cache-control': isAsset ? 'public, max-age=31536000, immutable' : 'no-cache',
  });
  res.end(readFileSync(file));
}

// ----------------------------------------------------------------- запуск

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  const store = await createStore();
  const game = new GameService(store);
  const server = createServer(createHandler(game));
  server.listen(PORT, () => {
    console.log(`[server] http://localhost:${PORT}  (${DEV_AUTH ? 'DEV_AUTH включён' : 'авторизация через Telegram initData'})`);
  });
  const stop = async () => { server.close(); await store.close(); process.exit(0); };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}
