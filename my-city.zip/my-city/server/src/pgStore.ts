import pg from 'pg';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { cityNameKey } from '../../shared/game';
import { SQL } from './sql';
import {
  type CityRow, type CityTx, type PublicCityRow, type QuestRow, type RatingRow, type Store, StoreError,
} from './store';

const { Pool } = pg;

type Q = { query: (text: string, values?: unknown[]) => Promise<{ rows: any[]; rowCount: number | null }> };

const num = (v: unknown) => (v === null || v === undefined ? null : Number(v));

function toCity(r: any): CityRow {
  return {
    id: String(r.id), telegramId: String(r.telegramId), name: r.name, mayor: r.mayor,
    coins: Number(r.coins), carry: Number(r.carry), crystals: Number(r.crystals), xp: Number(r.xp), level: Number(r.level),
    happinessBonus: Number(r.happinessBonus), roadRepairs: Number(r.roadRepairs), solved: Number(r.solved),
    totalEarned: Number(r.totalEarned), milestone: Number(r.milestone),
    population: Number(r.population), happiness: Number(r.happiness), net: Number(r.net),
    tickAt: Number(r.tickAt), genAt: Number(r.genAt), createdAt: Number(r.createdAt),
  };
}

function toQuest(r: any): QuestRow {
  return {
    id: r.id, template: r.template, category: r.category, kind: r.kind, status: r.status,
    npcName: r.npcName, npcRole: r.npcRole, avatar: Number(r.avatar), text: r.text,
    cost: num(r.cost), building: r.building, baseline: num(r.baseline),
    rewardCoins: Number(r.rewardCoins), rewardXp: Number(r.rewardXp), rewardHappy: Number(r.rewardHappy),
    createdAt: Number(r.createdAt), solvedAt: num(r.solvedAt),
  };
}

const questParams = (cityId: string, q: QuestRow) => [
  q.id, cityId, q.template, q.category, q.kind, q.status, q.npcName, q.npcRole, q.avatar, q.text,
  q.cost, q.building, q.baseline, q.rewardCoins, q.rewardXp, q.rewardHappy, q.createdAt, q.solvedAt,
];

const cityParams = (c: CityRow) => [
  c.id, c.mayor, Math.round(c.coins), c.carry, c.crystals, c.xp, c.level, c.happinessBonus, c.roadRepairs, c.solved,
  Math.round(c.totalEarned), c.milestone, c.population, c.happiness, c.net, c.tickAt, c.genAt,
];

export class PgStore implements Store {
  private pool: pg.Pool;

  constructor(connectionString: string, ssl = false) {
    this.pool = new Pool({ connectionString, max: 10, ssl: ssl ? { rejectUnauthorized: false } : undefined });
  }

  /** Создаёт таблицы (schema.sql идемпотентна). */
  async migrate(): Promise<void> {
    const sql = readFileSync(fileURLToPath(new URL('../schema.sql', import.meta.url)), 'utf8');
    await this.pool.query(sql);
  }

  private async tx<T>(fn: (c: Q) => Promise<T>): Promise<T> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const out = await fn(client);
      await client.query('COMMIT');
      return out;
    } catch (e) {
      try { await client.query('ROLLBACK'); } catch { /* соединение уже сломано */ }
      throw e;
    } finally {
      client.release();
    }
  }

  async createCity(city: Omit<CityRow, 'id'>, buildings: string[], quests: QuestRow[]): Promise<void> {
    try {
      await this.tx(async (c) => {
        const r = await c.query(SQL.insertCity, [
          city.telegramId, city.name, city.mayor, Math.round(city.coins), city.carry, city.crystals, city.xp, city.level,
          city.happinessBonus, city.roadRepairs, city.solved, Math.round(city.totalEarned), city.milestone,
          city.population, city.happiness, city.net, city.tickAt, city.genAt, city.createdAt, cityNameKey(city.name),
        ]);
        const id = String(r.rows[0].id);
        await c.query(SQL.insertBuildings, [id, buildings]);
        for (const q of quests) await c.query(SQL.upsertQuest, questParams(id, q));
      });
    } catch (e: any) {
      if (e?.code === '23505') {
        if (e.constraint === 'cities_telegram_id_uq') throw new StoreError('city_exists', 'Город уже создан');
        throw new StoreError('name_taken', 'Такое название уже занято');
      }
      throw e;
    }
  }

  async withCity<T>(telegramId: string, fn: (tx: CityTx) => T | Promise<T>): Promise<T> {
    return this.tx(async (c) => {
      const locked = await c.query(SQL.lockCity, [telegramId]);
      if (!locked.rows.length) throw new StoreError('no_city', 'Город не найден');
      const city = toCity(locked.rows[0]);
      const [b, q, rq] = await Promise.all([
        c.query(SQL.buildings, [city.id]), c.query(SQL.quests, [city.id]), c.query(SQL.requests, [city.id]),
      ]);
      const buildings: string[] = b.rows.map((r) => r.type);
      const quests = q.rows.map(toQuest);
      const requests = new Map<string, unknown>(rq.rows.map((r) => [r.requestId, r.response]));
      const origTypes = [...buildings];
      const origQuests = new Map(quests.map((x) => [x.id, JSON.stringify(x)]));
      const newRequests: [string, unknown][] = [];

      const tx: CityTx = {
        city, buildings, quests,
        replay: (id) => requests.get(id),
        record: (id, resp) => { requests.set(id, resp); newRequests.push([id, resp]); },
      };
      const result = await fn(tx);

      await c.query(SQL.updateCity, cityParams(city));
      const appendOnly = buildings.length >= origTypes.length && origTypes.every((t, i) => buildings[i] === t);
      if (appendOnly) {
        if (buildings.length > origTypes.length) await c.query(SQL.insertBuildings, [city.id, buildings.slice(origTypes.length)]);
      } else {
        // улучшение дома поменяло тип на месте — переписываем список (в нём не больше ~70 строк)
        await c.query(SQL.deleteBuildings, [city.id]);
        await c.query(SQL.insertBuildings, [city.id, buildings]);
      }
      let pruned = false;
      for (const x of quests) {
        if (origQuests.get(x.id) !== JSON.stringify(x)) {
          await c.query(SQL.upsertQuest, questParams(city.id, x));
          if (!origQuests.has(x.id)) pruned = true;
        }
      }
      if (pruned) await c.query(SQL.pruneQuests, [city.id]);
      for (const [id, resp] of newRequests) await c.query(SQL.insertRequest, [city.id, id, JSON.stringify(resp)]);
      if (newRequests.length) await c.query(SQL.pruneRequests, [city.id]);
      return result;
    });
  }

  async rating(sort: 'population' | 'level', limit: number): Promise<{ total: number; rows: RatingRow[] }> {
    const [t, r] = await Promise.all([
      this.pool.query(SQL.total),
      this.pool.query(sort === 'level' ? SQL.ratingLevel : SQL.ratingPopulation, [limit]),
    ]);
    return {
      total: Number(t.rows[0].total),
      rows: r.rows.map((x) => ({
        cityId: String(x.cityId), name: x.name, mayor: x.mayor, population: Number(x.population), level: Number(x.level), thumb: x.thumb ?? [],
      })),
    };
  }

  async rankOf(cityId: string, sort: 'population' | 'level'): Promise<number> {
    const r = await this.pool.query(sort === 'level' ? SQL.rankLevel : SQL.rankPopulation, [cityId]);
    return Number(r.rows[0]?.rank ?? 0);
  }

  async cityByTelegramId(telegramId: string): Promise<CityRow | null> {
    const r = await this.pool.query(SQL.cityByTg, [telegramId]);
    return r.rows.length ? toCity(r.rows[0]) : null;
  }

  async publicCity(cityId: string): Promise<PublicCityRow | null> {
    const r = await this.pool.query(SQL.cityById, [cityId]);
    if (!r.rows.length) return null;
    const [b, rank] = await Promise.all([this.pool.query(SQL.buildings, [cityId]), this.rankOf(cityId, 'population')]);
    return { city: toCity(r.rows[0]), buildings: b.rows.map((x) => x.type), rank };
  }

  async close(): Promise<void> {
    await this.pool.end();
  }
}
