// Общая игровая логика: каталог, уровни, формулы экономики.
// Один и тот же код использует сервер (источник истины) и клиент (только для отображения и подсказок).
// Баланс настраивается здесь: цены, доходы, пороги уровней.

export type CoverKey = 'roads' | 'lighting' | 'safety' | 'health' | 'education' | 'leisure' | 'commerce';
export type Category = 'housing' | 'infra' | 'public' | 'leisure';
export type Counts = Record<string, number>;

export interface BuildingDef {
  id: string;
  name: string;
  category: Category;
  price: number;
  /** Сколько жителей вмещает */
  capacity: number;
  /** Доход, монет/час (до множителя счастья) */
  income: number;
  /** Расходы на содержание, монет/час */
  upkeep: number;
  minLevel: number;
  /** Лимит построек этого типа */
  maxCount?: number;
  /** true — занимает участок на карте; false — уличная инфраструктура */
  takesLot: boolean;
  /** Опыт за постройку */
  xp: number;
  /** Сколько домов «покрывает» здание по каждому показателю */
  cover: Partial<Record<CoverKey, number>>;
  blurb: string;
  hidden?: boolean;
}

function def(
  id: string, name: string, category: Category, price: number, minLevel: number,
  o: Partial<Pick<BuildingDef, 'capacity' | 'income' | 'upkeep' | 'maxCount' | 'cover' | 'blurb' | 'hidden'>> & { takesLot?: boolean } = {},
): BuildingDef {
  return {
    id, name, category, price, minLevel,
    capacity: o.capacity ?? 0,
    income: o.income ?? 0,
    upkeep: o.upkeep ?? 0,
    maxCount: o.maxCount,
    takesLot: o.takesLot ?? true,
    xp: Math.round(price * 0.1) + 10,
    cover: o.cover ?? {},
    blurb: o.blurb ?? '',
    hidden: o.hidden,
  };
}

const list: BuildingDef[] = [
  // ЖИЛЫЕ ДОМА
  def('small_house', 'Маленький дом', 'housing', 300, 1, { capacity: 8, income: 24, blurb: 'Уютный домик для небольшой семьи.' }),
  def('house', 'Обычный жилой дом', 'housing', 800, 2, { capacity: 20, income: 60, blurb: 'Двухэтажный дом на несколько семей.' }),
  def('apartment', 'Многоквартирный дом', 'housing', 1800, 3, { capacity: 48, income: 130, blurb: 'Кирпичный дом с несколькими подъездами.' }),
  def('midrise', 'Многоэтажка', 'housing', 4000, 4, { capacity: 110, income: 280, blurb: 'Панельная девятиэтажка.' }),
  def('complex', 'Жилой комплекс', 'housing', 11000, 6, { capacity: 300, income: 740, blurb: 'Современный квартал с двором.' }),
  def('skyscraper', 'Небоскрёб', 'housing', 30000, 8, { capacity: 800, income: 1900, blurb: 'Стеклянная башня — визитная карточка мегаполиса.' }),
  // ИНФРАСТРУКТУРА
  def('road', 'Дорога', 'infra', 200, 1, { upkeep: 2, maxCount: 8, takesLot: false, cover: { roads: 4 }, blurb: 'Ровный асфальт на одном участке улицы.' }),
  def('sidewalk', 'Тротуары', 'infra', 150, 2, { upkeep: 1, maxCount: 8, takesLot: false, cover: { roads: 2 }, blurb: 'Пешеходная дорожка вдоль улицы.' }),
  def('lighting', 'Освещение', 'infra', 180, 2, { upkeep: 2, maxCount: 8, takesLot: false, cover: { lighting: 5 }, blurb: 'Фонари, чтобы вечером было не страшно.' }),
  def('parking', 'Парковка', 'infra', 600, 4, { income: 10, upkeep: 4, maxCount: 4, cover: { roads: 2 }, blurb: 'Место для машин жителей.' }),
  def('bridge', 'Мост', 'infra', 2500, 5, { upkeep: 8, maxCount: 2, cover: { roads: 4 }, blurb: 'Соединяет берега городского канала.' }),
  // ОБЩЕСТВЕННЫЕ ЗДАНИЯ
  def('kindergarten', 'Детский сад', 'public', 900, 2, { upkeep: 10, cover: { education: 10 }, blurb: 'Малышам — игры, родителям — спокойствие.' }),
  def('school', 'Школа', 'public', 2200, 3, { upkeep: 22, cover: { education: 25 }, blurb: 'Образование для будущих горожан.' }),
  def('police', 'Полицейский участок', 'public', 1800, 3, { upkeep: 18, cover: { safety: 15 }, blurb: 'Порядок и безопасность на улицах.' }),
  def('fire', 'Пожарная станция', 'public', 2400, 4, { upkeep: 20, cover: { safety: 15 }, blurb: 'Быстро приедет, если что-то случится.' }),
  def('hospital', 'Больница', 'public', 5500, 5, { upkeep: 45, cover: { health: 30 }, blurb: 'Врачи и скорая помощь для всего города.' }),
  // ДОСУГ
  def('square', 'Сквер', 'leisure', 350, 1, { upkeep: 2, cover: { leisure: 6 }, blurb: 'Скамейки, клумбы и фонтан.' }),
  def('park', 'Парк', 'leisure', 900, 2, { upkeep: 6, cover: { leisure: 14 }, blurb: 'Тенистые аллеи и пруд.' }),
  def('cinema', 'Кинотеатр', 'leisure', 3500, 4, { income: 70, upkeep: 30, cover: { leisure: 14 }, blurb: 'Вечерние сеансы для всей семьи.' }),
  def('mall', 'Торговый центр', 'leisure', 9000, 5, { income: 380, upkeep: 120, cover: { commerce: 40, leisure: 10 }, blurb: 'Магазины, кафе и развлечения под одной крышей.' }),
  def('stadium', 'Стадион', 'leisure', 24000, 7, { income: 900, upkeep: 350, cover: { leisure: 40 }, blurb: 'Матчи и концерты на десятки тысяч зрителей.' }),
  // Стартовое здание (нельзя построить)
  def('old_house', 'Старый домик', 'housing', 0, 1, { capacity: 5, income: 6, hidden: true, blurb: 'Покосившийся, но родной.' }),
];

export const BUILDINGS: Record<string, BuildingDef> = Object.fromEntries(list.map((b) => [b.id, b]));
export const CATALOG: BuildingDef[] = list.filter((b) => !b.hidden);

export const CATEGORIES: { id: Category; title: string; short: string }[] = [
  { id: 'housing', title: 'Жилые дома', short: 'Дома' },
  { id: 'infra', title: 'Инфраструктура', short: 'Инфра-структура' },
  { id: 'public', title: 'Общественные здания', short: 'Услуги' },
  { id: 'leisure', title: 'Досуг', short: 'Досуг' },
];

// ---------------------------------------------------------------- уровни

export const LEVELS: { level: number; name: string; xpToNext: number | null }[] = [
  { level: 1, name: 'Заброшенная деревня', xpToNext: 500 },
  { level: 2, name: 'Маленькое поселение', xpToNext: 1200 },
  { level: 3, name: 'Деревня', xpToNext: 2500 },
  { level: 4, name: 'Посёлок', xpToNext: 4500 },
  { level: 5, name: 'Небольшой город', xpToNext: 8000 },
  { level: 6, name: 'Развитый город', xpToNext: 14000 },
  { level: 7, name: 'Большой город', xpToNext: 24000 },
  { level: 8, name: 'Мегаполис', xpToNext: null },
];
export const MAX_LEVEL = LEVELS.length;
export const levelName = (level: number) => LEVELS[Math.min(Math.max(level, 1), MAX_LEVEL) - 1].name;
export const xpToNext = (level: number) => LEVELS[Math.min(Math.max(level, 1), MAX_LEVEL) - 1].xpToNext;
export const levelReward = (newLevel: number) => ({ coins: 500 * (newLevel - 1), crystals: 3 + newLevel });
export const unlockedAtLevel = (level: number) => CATALOG.filter((b) => b.minLevel === level);

// ---------------------------------------------------------------- константы экономики

export const START_COINS = 1500;
export const START_CRYSTALS = 10;
export const START_HAPPINESS_BONUS = 5;
export const START_OLD_HOUSES = 3;
export const MAX_LOTS = 56; // 8x8 клеток минус улица
export const OFFLINE_CAP_HOURS = 12;
export const PRICE_GROWTH = 1.05;
export const HAPPY_BONUS_CAP = 25;
export const CRYSTAL_PACK = { crystals: 5, coins: 500 };

export const countOf = (counts: Counts, id: string) => counts[id] ?? 0;

export function priceOf(d: BuildingDef, ownedCount: number): number {
  const raw = d.price * Math.pow(PRICE_GROWTH, ownedCount);
  return Math.max(5, Math.round(raw / 5) * 5);
}

export function countsFromList(types: string[]): Counts {
  const c: Counts = {};
  for (const t of types) c[t] = (c[t] ?? 0) + 1;
  return c;
}

export function lotsUsed(counts: Counts): number {
  let n = 0;
  for (const [id, c] of Object.entries(counts)) if (BUILDINGS[id]?.takesLot) n += c;
  return n;
}

// ---------------------------------------------------------------- статистика города

export interface Stats {
  houses: number;
  housing: number;
  population: number;
  happiness: number;
  grossIncome: number;
  upkeep: number;
  net: number;
  coverage: Record<CoverKey, number>;
  infraScore: number;
}

const HAPPY_WEIGHTS: Record<CoverKey, number> = {
  leisure: 16, roads: 12, lighting: 8, safety: 8, health: 8, education: 6, commerce: 4,
};
const HAPPY_BASE = 13;

export function computeStats(counts: Counts, roadRepairs: number, happinessBonus: number): Stats {
  let houses = 0, housing = 0, income = 0, upkeep = 0;
  const units: Record<CoverKey, number> = { roads: 2 + 2 * roadRepairs, lighting: 0, safety: 0, health: 0, education: 0, leisure: 0, commerce: 0 };
  for (const [id, c] of Object.entries(counts)) {
    const d = BUILDINGS[id];
    if (!d || c <= 0) continue;
    if (d.category === 'housing') houses += c;
    housing += d.capacity * c;
    income += d.income * c;
    upkeep += d.upkeep * c;
    for (const k of Object.keys(d.cover) as CoverKey[]) units[k] += (d.cover[k] ?? 0) * c;
  }
  const denom = Math.max(1, houses);
  const coverage = {} as Record<CoverKey, number>;
  for (const k of Object.keys(units) as CoverKey[]) coverage[k] = Math.min(1, units[k] / denom);

  const infraScore = (coverage.roads + coverage.lighting + coverage.safety + coverage.health + coverage.education) / 5;
  const occupancy = 0.55 + 0.45 * infraScore;
  const population = Math.floor(housing * occupancy);

  let happy = HAPPY_BASE + Math.min(HAPPY_BONUS_CAP, happinessBonus);
  for (const k of Object.keys(HAPPY_WEIGHTS) as CoverKey[]) happy += HAPPY_WEIGHTS[k] * coverage[k];
  const happiness = Math.max(0, Math.min(100, Math.round(happy)));

  const mult = 0.75 + 0.5 * (happiness / 100);
  const grossIncome = income * mult;
  return { houses, housing, population, happiness, grossIncome, upkeep, net: grossIncome - upkeep, coverage, infraScore };
}

// ---------------------------------------------------------------- проверка возможности постройки

export type BuildCheck = { ok: true; price: number } | { ok: false; code: 'unknown' | 'level' | 'max' | 'lots' | 'funds' | 'budget'; message: string; price: number };

export interface BuildCtx {
  level: number;
  coins: number;
  counts: Counts;
  roadRepairs: number;
  happinessBonus: number;
}

export function checkBuild(ctx: BuildCtx, d: BuildingDef | undefined): BuildCheck {
  if (!d || d.hidden) return { ok: false, code: 'unknown', message: 'Такого здания нет', price: 0 };
  const owned = countOf(ctx.counts, d.id);
  const price = priceOf(d, owned);
  if (ctx.level < d.minLevel) return { ok: false, code: 'level', message: `Нужен ${d.minLevel} уровень города`, price };
  if (d.maxCount !== undefined && owned >= d.maxCount) return { ok: false, code: 'max', message: `Достигнут лимит: ${d.maxCount} шт.`, price };
  if (d.takesLot && lotsUsed(ctx.counts) >= MAX_LOTS) return { ok: false, code: 'lots', message: 'Свободных участков не осталось', price };
  if (ctx.coins < price) return { ok: false, code: 'funds', message: `Не хватает ${price - ctx.coins} монет`, price };
  const before = computeStats(ctx.counts, ctx.roadRepairs, ctx.happinessBonus);
  const after = computeStats({ ...ctx.counts, [d.id]: owned + 1 }, ctx.roadRepairs, ctx.happinessBonus);
  if (after.net < 0 && after.net < before.net) {
    return { ok: false, code: 'budget', message: 'Бюджет уйдёт в минус — сначала постройте жильё', price };
  }
  return { ok: true, price };
}

// ---------------------------------------------------------------- прочее

export const CITY_NAME_MIN = 3;
export const CITY_NAME_MAX = 20;
const NAME_RE = /^[\p{L}\p{N}][\p{L}\p{N} '.\-]*[\p{L}\p{N}]$/u;

export function normalizeCityName(raw: string): string {
  return raw.normalize('NFC').replace(/\s+/g, ' ').trim();
}

export function validateCityName(raw: string): string | null {
  const n = normalizeCityName(raw);
  if (n.length < CITY_NAME_MIN) return `Название должно быть не короче ${CITY_NAME_MIN} символов`;
  if (n.length > CITY_NAME_MAX) return `Название должно быть не длиннее ${CITY_NAME_MAX} символов`;
  if (!NAME_RE.test(n)) return 'Используйте буквы, цифры, пробел и дефис';
  return null;
}

export const POP_MILESTONES = [25, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 25000];

// ---------------------------------------------------------------- улучшение домов
// Дом можно улучшить на месте до следующего типа. Так участки не «забиваются» дешёвыми домиками:
// игрок всегда может вырасти от деревни до небоскрёбов, а опыт за улучшения ограничен лестницей.

export const UPGRADE_CHAIN = ['old_house', 'small_house', 'house', 'apartment', 'midrise', 'complex', 'skyscraper'];
/** Какая часть цены старого здания засчитывается при улучшении */
export const UPGRADE_CREDIT = 0.5;

export function upgradeTargetOf(id: string): BuildingDef | undefined {
  const i = UPGRADE_CHAIN.indexOf(id);
  return i >= 0 && i < UPGRADE_CHAIN.length - 1 ? BUILDINGS[UPGRADE_CHAIN[i + 1]] : undefined;
}

export function upgradeCost(source: BuildingDef, target: BuildingDef, ownedTarget: number): number {
  return Math.max(5, priceOf(target, ownedTarget) - Math.floor(source.price * UPGRADE_CREDIT));
}

export type UpgradeCheck =
  | { ok: true; price: number; target: BuildingDef; xp: number }
  | { ok: false; code: 'unknown' | 'no_upgrade' | 'level' | 'funds'; message: string; price: number };

export function checkUpgrade(ctx: BuildCtx, sourceId: string | undefined): UpgradeCheck {
  const source = sourceId ? BUILDINGS[sourceId] : undefined;
  if (!source) return { ok: false, code: 'unknown', message: 'Такой постройки нет', price: 0 };
  const target = upgradeTargetOf(source.id);
  if (!target) return { ok: false, code: 'no_upgrade', message: 'Это здание нельзя улучшить', price: 0 };
  const price = upgradeCost(source, target, countOf(ctx.counts, target.id));
  if (ctx.level < target.minLevel) return { ok: false, code: 'level', message: `Нужен ${target.minLevel} уровень города`, price };
  if (ctx.coins < price) return { ok: false, code: 'funds', message: `Не хватает ${price - ctx.coins} монет`, price };
  return { ok: true, price, target, xp: Math.max(0, target.xp - source.xp) };
}

/** Ключ уникальности названия города: регистр и «ё/е» не различаются (не зависит от локали базы данных). */
export function cityNameKey(raw: string): string {
  return normalizeCityName(raw).toLowerCase().replace(/ё/g, 'е');
}
