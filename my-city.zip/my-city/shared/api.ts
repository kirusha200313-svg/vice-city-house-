// Типы, которыми обмениваются сервер и клиент.
import type { CoverKey } from './game';

export type QuestCategory = 'complaint' | 'request' | 'suggestion' | 'thanks' | 'news' | 'event';
export type QuestKind = 'pay' | 'build' | 'info';
export type QuestStatus = 'open' | 'done' | 'info';

export interface QuestDTO {
  id: string;
  npc: { name: string; role: string; avatar: number };
  category: QuestCategory;
  kind: QuestKind;
  status: QuestStatus;
  text: string;
  /** pay: сколько монет нужно потратить */
  cost?: number;
  /** build: какое здание нужно построить */
  building?: string;
  /** build: можно ли забрать награду (здание уже построено) */
  ready?: boolean;
  reward: { coins: number; xp: number; happy: number };
  createdAt: number;
  solvedAt?: number;
}

export interface CityDTO {
  id: string;
  name: string;
  mayor: string;
  level: number;
  levelName: string;
  xp: number;
  xpNeeded: number | null;
  canLevelUp: boolean;
  coins: number;
  crystals: number;
  population: number;
  housing: number;
  happiness: number;
  buildingsCount: number;
  grossIncome: number;
  upkeep: number;
  net: number;
  coverage: Record<CoverKey, number>;
  roadRepairs: number;
  /** Бонус к счастью от решённых задач (нужен клиенту для тех же расчётов, что и на сервере) */
  happinessBonus: number;
  solved: number;
  totalEarned: number;
  createdAt: number;
}

export interface StateDTO {
  now: number;
  city: CityDTO;
  /** Типы построек в порядке строительства (по ним клиент раскладывает город по участкам) */
  buildings: string[];
  quests: QuestDTO[];
}

export interface StateResponse {
  /** null — у игрока ещё нет города, нужно показать приветствие */
  state: StateDTO | null;
}

export interface ActionResponse {
  state: StateDTO;
  /** Что произошло — для анимаций и модалок */
  event?:
    | { type: 'built'; buildingId: string; index: number }
    | { type: 'quest'; questId: string; reward: { coins: number; xp: number; happy: number } }
    | { type: 'levelup'; level: number; name: string; unlocked: string[]; reward: { coins: number; crystals: number } }
    | { type: 'upgraded'; index: number; from: string; to: string }
    | { type: 'exchange'; coins: number };
  replayed?: boolean;
}

export interface RatingEntry {
  cityId: string;
  rank: number;
  name: string;
  mayor: string;
  population: number;
  level: number;
  /** Типы построек (для миниатюры) */
  thumb: string[];
  isMe: boolean;
}

export interface RatingResponse {
  sort: 'population' | 'level';
  total: number;
  entries: RatingEntry[];
  me: RatingEntry | null;
}

export interface PublicCityDTO {
  id: string;
  name: string;
  mayor: string;
  level: number;
  levelName: string;
  population: number;
  happiness: number;
  buildingsCount: number;
  roadRepairs: number;
  rank: number;
  buildings: string[];
  createdAt: number;
}

export interface ApiError {
  error: { code: string; message: string };
}
