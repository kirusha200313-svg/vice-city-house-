import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { ApiError, NetworkError, api, newRequestId } from '../lib/api';
import { haptic } from '../lib/tg';
import { fmt } from '../lib/format';
import { BUILDINGS, type ActionResponse, type StateDTO } from '../shared';

export type Tab = 'home' | 'treasury' | 'rating' | 'feed';
export type Phase = 'loading' | 'welcome' | 'ready' | 'unauth' | 'error';

export type ModalState =
  | { type: 'confirm'; id: string }
  | { type: 'quest'; id: string }
  | { type: 'levelup'; level: number; name: string; unlocked: string[]; reward: { coins: number; crystals: number } }
  | { type: 'city'; id: string }
  | { type: 'building'; index: number }
  | { type: 'exchange' };

export interface ToastItem {
  id: number;
  text: string;
  kind: 'success' | 'error' | 'info';
  action?: { label: string; run: () => void };
}

interface Ctx {
  phase: Phase;
  errorText: string;
  state: StateDTO | null;
  /** Разница между часами сервера и устройства (для «5 мин. назад») */
  now: () => number;
  busy: boolean;
  tab: Tab;
  setTab: (t: Tab) => void;
  modal: ModalState | null;
  openModal: (m: ModalState) => void;
  closeModal: () => void;
  toasts: ToastItem[];
  toast: (text: string, kind?: ToastItem['kind'], action?: ToastItem['action']) => void;
  /** Индекс только что построенного/улучшенного здания — сцена проигрывает для него анимацию */
  fresh: { index: number; key: number } | null;
  /** Здание, которое нужно показать в Казне (переход из задания жителей) */
  focusBuilding: string | null;
  goBuild: (buildingId: string) => void;
  clearFocus: () => void;
  retry: () => void;
  createCity: (name: string) => Promise<string | null>;
  build: (id: string) => Promise<boolean>;
  upgrade: (index: number) => Promise<boolean>;
  solve: (id: string) => Promise<boolean>;
  levelUp: () => Promise<boolean>;
  exchange: (packs: number) => Promise<boolean>;
}

const GameCtx = createContext<Ctx | null>(null);

export function useGame(): Ctx {
  const c = useContext(GameCtx);
  if (!c) throw new Error('GameProvider не найден');
  return c;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const POLL_MS = 20_000;

export function GameProvider({ children }: { children: ReactNode }) {
  const [phase, setPhase] = useState<Phase>('loading');
  const [errorText, setErrorText] = useState('');
  const [state, setState] = useState<StateDTO | null>(null);
  const [busy, setBusy] = useState(false);
  const [tab, setTabRaw] = useState<Tab>('home');
  const [modal, setModal] = useState<ModalState | null>(null);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [fresh, setFresh] = useState<{ index: number; key: number } | null>(null);
  const [focusBuilding, setFocusBuilding] = useState<string | null>(null);

  const skew = useRef(0);
  const busyRef = useRef(false);
  const seq = useRef(0); // растёт после каждого действия: устаревший ответ опроса отбрасывается
  const toastId = useRef(0);

  const now = useCallback(() => Date.now() + skew.current, []);

  const apply = useCallback((s: StateDTO) => {
    skew.current = s.now - Date.now();
    setState(s);
    setPhase('ready');
  }, []);

  const toast = useCallback((text: string, kind: ToastItem['kind'] = 'info', action?: ToastItem['action']) => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-2), { id, text, kind, action }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), action ? 5200 : 3200);
  }, []);

  const load = useCallback(async () => {
    setPhase('loading');
    try {
      const r = await api.getState();
      if (r.state) apply(r.state);
      else setPhase('welcome');
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) setPhase('unauth');
      else {
        setErrorText(e instanceof Error ? e.message : 'Ошибка');
        setPhase('error');
      }
    }
  }, [apply]);

  useEffect(() => { void load(); }, [load]);

  // Опрос сервера: приходят доход и новые сообщения жителей
  useEffect(() => {
    if (phase !== 'ready') return;
    const poll = async () => {
      if (busyRef.current || document.hidden) return;
      const mine = seq.current;
      try {
        const r = await api.getState();
        if (r.state && seq.current === mine && !busyRef.current) apply(r.state);
      } catch { /* временный обрыв — повторим при следующем опросе */ }
    };
    const t = setInterval(poll, POLL_MS);
    const onVis = () => { if (!document.hidden) void poll(); };
    document.addEventListener('visibilitychange', onVis);
    return () => { clearInterval(t); document.removeEventListener('visibilitychange', onVis); };
  }, [phase, apply]);

  const refreshQuiet = useCallback(async () => {
    try {
      const r = await api.getState();
      if (r.state) apply(r.state);
    } catch { /* ignore */ }
  }, [apply]);

  /** Выполняет изменяющую операцию: один запрос за раз, повтор при обрыве связи с тем же requestId */
  const run = useCallback(async (fn: (rid: string) => Promise<ActionResponse>): Promise<ActionResponse | null> => {
    if (busyRef.current) return null;
    busyRef.current = true;
    setBusy(true);
    const rid = newRequestId();
    try {
      let res: ActionResponse | null = null;
      for (let attempt = 0; ; attempt++) {
        try {
          res = await fn(rid);
          break;
        } catch (e) {
          if (e instanceof NetworkError && attempt < 2) { await sleep(600 * (attempt + 1)); continue; }
          throw e;
        }
      }
      seq.current++;
      apply(res.state);
      return res;
    } catch (e) {
      haptic.error();
      if (e instanceof ApiError) {
        toast(e.message, 'error');
        if (e.status === 409 || e.status === 404) void refreshQuiet(); // состояние могло устареть
        if (e.status === 401) setPhase('unauth');
      } else {
        toast('Нет связи с сервером. Попробуйте ещё раз', 'error');
      }
      return null;
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }, [apply, toast, refreshQuiet]);

  const setTab = useCallback((t: Tab) => { setTabRaw(t); haptic.select(); }, []);
  const openModal = useCallback((m: ModalState) => setModal(m), []);
  const closeModal = useCallback(() => setModal(null), []);

  const goBuild = useCallback((id: string) => {
    setModal(null);
    setFocusBuilding(id);
    setTabRaw('treasury');
  }, []);
  const clearFocus = useCallback(() => setFocusBuilding(null), []);

  const createCity = useCallback(async (name: string): Promise<string | null> => {
    try {
      const r = await api.createCity(name);
      if (!r.state) return 'Не удалось создать город';
      seq.current++;
      apply(r.state);
      haptic.success();
      return null;
    } catch (e) {
      haptic.error();
      if (e instanceof ApiError) {
        if (e.status === 401) setPhase('unauth');
        return e.message;
      }
      return 'Нет связи с сервером. Попробуйте ещё раз';
    }
  }, [apply]);

  const build = useCallback(async (id: string) => {
    const res = await run((rid) => api.build(id, rid));
    if (!res || res.event?.type !== 'built') return false;
    haptic.success();
    const index = res.event.index;
    setFresh({ index, key: Date.now() });
    setModal(null);
    toast(`Построено: ${BUILDINGS[id]?.name ?? id}`, 'success', { label: 'Смотреть', run: () => setTabRaw('home') });
    return true;
  }, [run, toast]);

  const upgrade = useCallback(async (index: number) => {
    const res = await run((rid) => api.upgrade(index, rid));
    if (!res || res.event?.type !== 'upgraded') return false;
    haptic.success();
    setFresh({ index: res.event.index, key: Date.now() });
    setModal(null);
    toast(`Улучшено: ${BUILDINGS[res.event.to]?.name ?? res.event.to}`, 'success');
    return true;
  }, [run, toast]);

  const solve = useCallback(async (id: string) => {
    const res = await run((rid) => api.completeQuest(id, rid));
    if (!res || res.event?.type !== 'quest') return false;
    haptic.success();
    const r = res.event.reward;
    setModal(null);
    toast(`Решено! +${fmt(r.coins)} монет, +${r.xp} опыта, +${r.happy} к счастью`, 'success');
    return true;
  }, [run, toast]);

  const levelUp = useCallback(async () => {
    const res = await run((rid) => api.levelUp(rid));
    if (!res || res.event?.type !== 'levelup') return false;
    haptic.success();
    setModal({ type: 'levelup', level: res.event.level, name: res.event.name, unlocked: res.event.unlocked, reward: res.event.reward });
    return true;
  }, [run]);

  const exchange = useCallback(async (packs: number) => {
    const res = await run((rid) => api.exchange(packs, rid));
    if (!res || res.event?.type !== 'exchange') return false;
    haptic.success();
    toast(`Обмен выполнен: +${fmt(res.event.coins)} монет`, 'success');
    setModal(null);
    return true;
  }, [run, toast]);

  const value = useMemo<Ctx>(() => ({
    phase, errorText, state, now, busy, tab, setTab, modal, openModal, closeModal, toasts, toast, fresh,
    focusBuilding, goBuild, clearFocus, retry: load, createCity, build, upgrade, solve, levelUp, exchange,
  }), [phase, errorText, state, now, busy, tab, setTab, modal, openModal, closeModal, toasts, toast, fresh,
    focusBuilding, goBuild, clearFocus, load, createCity, build, upgrade, solve, levelUp, exchange]);

  return <GameCtx.Provider value={value}>{children}</GameCtx.Provider>;
}
