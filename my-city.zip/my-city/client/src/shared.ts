// Единая точка входа в общий код (../../shared): игровые формулы и типы API.
export * from '../../shared/game';
export * from '../../shared/api';
