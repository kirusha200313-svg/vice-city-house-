import { Icon, type IconName } from './components/Icon';
import { Toasts } from './components/ui';
import { BuildingSheet } from './modals/BuildingSheet';
import { CityProfile } from './modals/CityProfile';
import { ConfirmBuild } from './modals/ConfirmBuild';
import { ExchangeModal } from './modals/ExchangeModal';
import { LevelUpModal } from './modals/LevelUpModal';
import { QuestModal } from './modals/QuestModal';
import { Feed } from './pages/Feed';
import { Home } from './pages/Home';
import { Rating } from './pages/Rating';
import { Treasury } from './pages/Treasury';
import { Welcome } from './pages/Welcome';
import { GameProvider, useGame, type Tab } from './state/GameContext';

const TABS: { id: Tab; label: string; icon: IconName }[] = [
  { id: 'home', label: 'Главная', icon: 'home' },
  { id: 'treasury', label: 'Казна', icon: 'treasury' },
  { id: 'rating', label: 'Рейтинг', icon: 'trophy' },
  { id: 'feed', label: 'Подслушано', icon: 'chat' },
];

function Notice({ title, text, action }: { title: string; text: string; action?: { label: string; run: () => void } }) {
  return (
    <div className="center-screen">
      <div className="notice card">
        <h1>{title}</h1>
        <p className="hint">{text}</p>
        {action && <button className="btn btn-gold btn-block" onClick={action.run}>{action.label}</button>}
      </div>
    </div>
  );
}

function ModalHost() {
  const { modal } = useGame();
  if (!modal) return null;
  switch (modal.type) {
    case 'confirm': return <ConfirmBuild id={modal.id} />;
    case 'quest': return <QuestModal id={modal.id} />;
    case 'levelup': return <LevelUpModal level={modal.level} name={modal.name} unlocked={modal.unlocked} reward={modal.reward} />;
    case 'city': return <CityProfile id={modal.id} />;
    case 'building': return <BuildingSheet index={modal.index} />;
    case 'exchange': return <ExchangeModal />;
  }
}

function Shell() {
  const { phase, state, tab, setTab, errorText, retry } = useGame();

  if (phase === 'loading') {
    return <div className="center-screen"><div className="splash"><span className="spinner" aria-hidden="true" /><b>Мой город</b></div></div>;
  }
  if (phase === 'unauth') {
    return <Notice title="Откройте игру из Telegram" text="Игра привязывает город к вашему аккаунту Telegram. Запустите её из бота через кнопку меню или ссылку на Mini App." action={{ label: 'Попробовать снова', run: retry }} />;
  }
  if (phase === 'error') {
    return <Notice title="Нет связи с сервером" text={errorText || 'Не удалось загрузить игру.'} action={{ label: 'Повторить', run: retry }} />;
  }
  if (phase === 'welcome' || !state) {
    return <><Welcome /><Toasts /></>;
  }

  const openTasks = state.quests.filter((q) => q.status === 'open').length;
  return (
    <div className="app">
      <main className="screen">
        <div key={tab} className="fade-in">
          {tab === 'home' && <Home />}
          {tab === 'treasury' && <Treasury />}
          {tab === 'rating' && <Rating />}
          {tab === 'feed' && <Feed />}
        </div>
      </main>
      <nav className="nav" aria-label="Разделы игры">
        {TABS.map((t) => (
          <button key={t.id} className={`nav-item ${tab === t.id ? 'active' : ''}`} onClick={() => setTab(t.id)} aria-current={tab === t.id ? 'page' : undefined}>
            <span className="nav-ico">
              <Icon name={t.icon} size={26} />
              {t.id === 'feed' && openTasks > 0 && <span className="badge">{openTasks > 9 ? '9+' : openTasks}</span>}
            </span>
            <span>{t.label}</span>
          </button>
        ))}
      </nav>
      <ModalHost />
      <Toasts />
    </div>
  );
}

export function App() {
  return (
    <GameProvider>
      <Shell />
    </GameProvider>
  );
}
