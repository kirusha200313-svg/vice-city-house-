import type { ActionResponse, PublicCityDTO, RatingResponse, StateResponse } from '../shared';
import { getInitData } from './tg';

export class ApiError extends Error {
  constructor(public code: string, message: string, public status: number) {
    super(message);
  }
}
/** Нет связи с сервером (запрос не дошёл) — такие запросы можно безопасно повторить с тем же requestId */
export class NetworkError extends Error {}

const BASE: string = (import.meta.env.VITE_API_URL as string | undefined) ?? '';
const DEV_AUTH = import.meta.env.DEV || import.meta.env.VITE_DEV_AUTH === '1';

/** Отладка вне Telegram: id игрока берётся из ?dev=123 или создаётся случайный (нужен сервер с DEV_AUTH=1). */
function devHeader(): string {
  let id = new URLSearchParams(location.search).get('dev') ?? '';
  try {
    if (!/^\d{1,15}$/.test(id)) {
      id = localStorage.getItem('mycity:dev-id') ?? '';
      if (!id) {
        id = String(100000000 + Math.floor(Math.random() * 899999999));
        localStorage.setItem('mycity:dev-id', id);
      }
    }
  } catch {
    if (!/^\d{1,15}$/.test(id)) id = '100000001';
  }
  return `${id}:${encodeURIComponent('Игрок')}`;
}

async function call<T>(method: 'GET' | 'POST', path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = {};
  if (body !== undefined) headers['content-type'] = 'application/json';
  const initData = getInitData();
  if (initData) headers.authorization = `tma ${initData}`;
  else if (DEV_AUTH) headers['x-dev-user'] = devHeader();

  let res: Response;
  try {
    res = await fetch(`${BASE}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch {
    throw new NetworkError('Нет связи с сервером');
  }
  let data: any = null;
  try {
    data = await res.json();
  } catch { /* пустой или не-JSON ответ */ }
  if (!res.ok) {
    throw new ApiError(data?.error?.code ?? 'http_' + res.status, data?.error?.message ?? 'Ошибка сервера', res.status);
  }
  return data as T;
}

export const api = {
  getState: () => call<StateResponse>('GET', '/api/state'),
  createCity: (name: string) => call<StateResponse>('POST', '/api/city', { name }),
  build: (buildingId: string, requestId: string) => call<ActionResponse>('POST', '/api/build', { buildingId, requestId }),
  upgrade: (index: number, requestId: string) => call<ActionResponse>('POST', '/api/upgrade', { index, requestId }),
  completeQuest: (id: string, requestId: string) => call<ActionResponse>('POST', `/api/quests/${encodeURIComponent(id)}/complete`, { requestId }),
  levelUp: (requestId: string) => call<ActionResponse>('POST', '/api/levelup', { requestId }),
  exchange: (packs: number, requestId: string) => call<ActionResponse>('POST', '/api/exchange', { packs, requestId }),
  rating: (sort: 'population' | 'level') => call<RatingResponse>('GET', `/api/rating?sort=${sort}`),
  city: (id: string) => call<PublicCityDTO>('GET', `/api/cities/${encodeURIComponent(id)}`),
};

/** Уникальный id запроса: сервер по нему отсекает повторную обработку (двойной тап, повтор после обрыва связи) */
export function newRequestId(): string {
  try {
    if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  } catch { /* небезопасный контекст */ }
  return 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 12);
}
