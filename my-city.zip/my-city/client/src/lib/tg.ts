// Тонкая обёртка над Telegram Mini Apps SDK (window.Telegram.WebApp).
// Вне Telegram (обычный браузер) все методы безопасно ничего не делают.

interface TgHaptic {
  impactOccurred?(style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft'): void;
  notificationOccurred?(type: 'error' | 'success' | 'warning'): void;
  selectionChanged?(): void;
}

interface TgWebApp {
  initData: string;
  initDataUnsafe?: { user?: { id: number; first_name?: string; last_name?: string; username?: string } };
  colorScheme?: 'light' | 'dark';
  ready(): void;
  expand(): void;
  close?(): void;
  setHeaderColor?(color: string): void;
  setBackgroundColor?(color: string): void;
  setBottomBarColor?(color: string): void;
  disableVerticalSwipes?(): void;
  HapticFeedback?: TgHaptic;
}

declare global {
  interface Window {
    Telegram?: { WebApp?: TgWebApp };
  }
}

const wa = (): TgWebApp | undefined => (typeof window !== 'undefined' ? window.Telegram?.WebApp : undefined);

/** Строка initData, подписанная Telegram. Сервер проверяет её подпись по токену бота. */
export const getInitData = (): string => wa()?.initData ?? '';

export const inTelegram = (): boolean => getInitData().length > 0;

export function initTelegram(): void {
  const w = wa();
  if (!w) return;
  const safe = (fn?: () => void) => {
    try { fn?.(); } catch { /* метод не поддерживается этой версией клиента Telegram */ }
  };
  safe(() => w.ready());
  safe(() => w.expand());
  safe(() => w.disableVerticalSwipes?.()); // чтобы свайп по игре не закрывал Mini App
  safe(() => w.setHeaderColor?.('#0b1226'));
  safe(() => w.setBackgroundColor?.('#0b1226'));
  safe(() => w.setBottomBarColor?.('#0b1226'));
}

const h = () => wa()?.HapticFeedback;
export const haptic = {
  tap: () => { try { h()?.impactOccurred?.('light'); } catch { /* ignore */ } },
  select: () => { try { h()?.selectionChanged?.(); } catch { /* ignore */ } },
  success: () => { try { h()?.notificationOccurred?.('success'); } catch { /* ignore */ } },
  error: () => { try { h()?.notificationOccurred?.('error'); } catch { /* ignore */ } },
};
