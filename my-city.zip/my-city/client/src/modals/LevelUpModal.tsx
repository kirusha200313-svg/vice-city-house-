import { useMemo } from 'react';
import { BUILDINGS } from '../shared';
import { fmt } from '../lib/format';
import { hash2 } from '../scene/iso';
import { Icon } from '../components/Icon';
import { BuildingThumb } from '../scene/Thumbs';
import { useGame } from '../state/GameContext';

const COLORS = ['#ffc933', '#5db7ff', '#ff7a8a', '#6cd68f', '#b79cff', '#ffffff'];

export function LevelUpModal({ level, name, unlocked, reward }: { level: number; name: string; unlocked: string[]; reward: { coins: number; crystals: number } }) {
  const { closeModal } = useGame();
  const bits = useMemo(
    () => Array.from({ length: 34 }, (_, k) => ({
      left: hash2(k, 1) * 100, delay: hash2(k, 2) * 0.9, dur: 2.2 + hash2(k, 3) * 1.6, c: COLORS[k % COLORS.length], rot: hash2(k, 4) * 360, w: 6 + hash2(k, 5) * 6,
    })),
    [],
  );
  return (
    <div className="overlay lu-overlay" onClick={(e) => { if (e.target === e.currentTarget) closeModal(); }}>
      <div className="confetti" aria-hidden="true">
        {bits.map((b, k) => (
          <i key={k} style={{ left: `${b.left}%`, background: b.c, width: b.w, height: b.w * 1.6, animationDelay: `${b.delay}s`, animationDuration: `${b.dur}s`, transform: `rotate(${b.rot}deg)` }} />
        ))}
      </div>
      <div className="lu" role="dialog" aria-modal="true" aria-label="Уровень города повышен">
        <div className="lu-burst" aria-hidden="true" />
        <Icon name="star" size={92} className="lu-star" />
        <h2 className="lu-title">Уровень города повышен!</h2>
        <div className="lu-ribbon">{level} уровень</div>
        <p className="lu-name">{name}</p>

        {unlocked.length > 0 && (
          <>
            <p className="lu-sub">Открыты новые возможности:</p>
            <ul className="lu-list">
              {unlocked.map((id) => (
                <li key={id} className="lu-item">
                  <div className="bthumb"><BuildingThumb id={id} /></div>
                  <span>{BUILDINGS[id]?.name ?? id}</span>
                </li>
              ))}
            </ul>
          </>
        )}

        <div className="lu-reward">
          <span className="rchip big"><Icon name="coin" size={20} />+{fmt(reward.coins)}</span>
          <span className="rchip big"><Icon name="gem" size={20} />+{reward.crystals}</span>
        </div>
        <button className="btn btn-gold btn-block" onClick={closeModal}>Отлично!</button>
      </div>
    </div>
  );
}
