import { CRYSTAL_PACK } from '../shared';
import { fmt } from '../lib/format';
import { Icon } from '../components/Icon';
import { Modal } from '../components/ui';
import { useGame } from '../state/GameContext';

export function ExchangeModal() {
  const { state, closeModal, exchange, busy } = useGame();
  const have = state!.city.crystals;
  const options = [1, 2];
  return (
    <Modal onClose={closeModal} title="Кристаллы" className="exchange">
      <div className="req-box">
        <Icon name="gem" size={30} />
        <div>
          <b>У вас {fmt(have)} кристаллов</b>
          <span className="hint">Кристаллы дают за повышение уровня города. Их можно обменять на монеты.</span>
        </div>
      </div>
      <div className="exchange-list">
        {options.map((packs) => {
          const gems = packs * CRYSTAL_PACK.crystals;
          const coins = packs * CRYSTAL_PACK.coins;
          return (
            <button key={packs} className="card exchange-row" disabled={busy || have < gems} onClick={() => void exchange(packs)}>
              <span><Icon name="gem" size={22} /> {gems}</span>
              <Icon name="next" size={16} />
              <span><Icon name="coin" size={22} /> {fmt(coins)}</span>
            </button>
          );
        })}
      </div>
      {have < CRYSTAL_PACK.crystals && <p className="hint center">Нужно минимум {CRYSTAL_PACK.crystals} кристаллов. Повышайте уровень города, чтобы получить их.</p>}
    </Modal>
  );
}
