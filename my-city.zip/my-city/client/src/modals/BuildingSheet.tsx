import { useMemo } from 'react';
import { BUILDINGS, checkUpgrade, computeStats, countsFromList, type BuildCtx } from '../shared';
import { fmt, fmtSigned } from '../lib/format';
import { Icon } from '../components/Icon';
import { Modal } from '../components/ui';
import { BuildingThumb } from '../scene/Thumbs';
import { useGame } from '../state/GameContext';

export function BuildingSheet({ index }: { index: number }) {
  const { state, closeModal, upgrade, busy, setTab } = useGame();
  const c = state!.city;
  const id = state!.buildings[index];
  const d = id ? BUILDINGS[id] : undefined;
  const counts = useMemo(() => countsFromList(state!.buildings), [state]);
  if (!d) return null;

  const ctx: BuildCtx = { level: c.level, coins: c.coins, counts, roadRepairs: c.roadRepairs, happinessBonus: c.happinessBonus };
  const chk = checkUpgrade(ctx, id);
  const before = computeStats(counts, c.roadRepairs, c.happinessBonus);
  let after = before;
  if (chk.ok) {
    const next = [...state!.buildings];
    next[index] = chk.target.id;
    after = computeStats(countsFromList(next), c.roadRepairs, c.happinessBonus);
  }

  return (
    <Modal onClose={closeModal} title={d.name} className="bsheet">
      <div className="confirm-head">
        <div className="bthumb big"><BuildingThumb id={id} /></div>
        <div>
          <p className="hint">{d.blurb}</p>
          <div className="bstats">
            {d.capacity > 0 && <span className="st"><Icon name="people" size={14} />{d.capacity} жителей</span>}
            {d.income > 0 && <span className="st pos"><Icon name="trend" size={14} />+{d.income}/ч</span>}
            {d.upkeep > 0 && <span className="st neg">−{d.upkeep}/ч</span>}
          </div>
        </div>
      </div>

      {chk.ok ? (
        <>
          <div className="upgrade-box">
            <div className="bthumb"><BuildingThumb id={chk.target.id} /></div>
            <div>
              <b>Улучшить до: {chk.target.name}</b>
              <span className="hint">
                Жителей: {fmt(before.population)} → <b>{fmt(after.population)}</b> · Баланс: {fmtSigned(before.net)} → <b>{fmtSigned(after.net)}</b>/ч · Опыт +{chk.xp}
              </span>
            </div>
          </div>
          <button className="btn btn-gold btn-block" disabled={busy} onClick={() => void upgrade(index)}>
            {busy ? 'Улучшаем…' : <>Улучшить за {fmt(chk.price)} <Icon name="coin" size={18} /></>}
          </button>
        </>
      ) : chk.code === 'no_upgrade' ? (
        <p className="hint center">{id === 'skyscraper' ? 'Это самое высокое здание — дальше улучшать некуда.' : 'Это здание нельзя улучшить. Улучшаются только жилые дома.'}</p>
      ) : (
        <>
          <p className="error-text center">{chk.message}</p>
          {chk.code === 'funds' && <button className="btn btn-ghost btn-block" onClick={() => { closeModal(); setTab('feed'); }}>Заработать монеты в «Подслушано»</button>}
        </>
      )}
    </Modal>
  );
}
