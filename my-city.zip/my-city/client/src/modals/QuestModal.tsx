import { BUILDINGS } from '../shared';
import { fmt, plural } from '../lib/format';
import { Avatar } from '../components/Avatar';
import { Icon } from '../components/Icon';
import { Modal } from '../components/ui';
import { BuildingThumb } from '../scene/Thumbs';
import { useGame } from '../state/GameContext';

export function QuestModal({ id }: { id: string }) {
  const { state, closeModal, solve, goBuild, busy } = useGame();
  const q = state!.quests.find((x) => x.id === id);
  if (!q) {
    return (
      <Modal onClose={closeModal} title="Задание">
        <p className="hint center">Это сообщение уже пропало из ленты.</p>
        <button className="btn btn-gold btn-block" onClick={closeModal}>Закрыть</button>
      </Modal>
    );
  }
  const coins = state!.city.coins;
  const done = q.status === 'done';
  const target = q.building ? BUILDINGS[q.building] : undefined;
  const short = q.kind === 'pay' ? Math.max(0, (q.cost ?? 0) - coins) : 0;

  return (
    <Modal onClose={closeModal} title="Задание" className="quest">
      <div className="npc">
        <Avatar seed={q.npc.avatar} name={q.npc.name} role={q.npc.role} size={64} />
        <div>
          <b className="npc-name">{q.npc.name}</b>
          <span className="npc-role">{q.npc.role}</span>
        </div>
      </div>
      <p className="quest-text">{q.text}</p>

      {q.kind === 'pay' && (
        <div className="req-box">
          <Icon name="coin" size={22} />
          <div>
            <b>Потратить {fmt(q.cost ?? 0)} {plural(q.cost ?? 0, 'монету', 'монеты', 'монет')}</b>
            <span className="hint">В казне: {fmt(coins)}</span>
          </div>
        </div>
      )}
      {q.kind === 'build' && target && (
        <div className={`req-box ${q.ready || done ? 'ok' : ''}`}>
          <div className="bthumb"><BuildingThumb id={target.id} /></div>
          <div>
            <b>Построить: {target.name}</b>
            <span className="hint">{done || q.ready ? 'Здание построено — можно забрать награду' : 'Постройте его в Казне, затем вернитесь сюда'}</span>
          </div>
          {(done || q.ready) && <Icon name="check" size={22} className="green" />}
        </div>
      )}

      <div className="reward-box">
        <b>Награда:</b>
        <div className="reward-grid">
          <div className="reward-item"><Icon name="coin" size={34} /><span>+{fmt(q.reward.coins)}</span><small>монет</small></div>
          <div className="reward-item"><Icon name="star" size={34} /><span>+{q.reward.xp}</span><small>опыта</small></div>
          <div className="reward-item"><Icon name="smile" size={34} className="mood" /><span>+{q.reward.happy}</span><small>счастья</small></div>
        </div>
      </div>

      {done ? (
        <button className="btn btn-ghost btn-block" disabled><Icon name="check" size={18} /> Решено</button>
      ) : q.kind === 'build' && !q.ready ? (
        <button className="btn btn-gold btn-block" onClick={() => target && goBuild(target.id)}>Перейти к строительству<Icon name="next" size={18} /></button>
      ) : q.kind === 'build' ? (
        <button className="btn btn-gold btn-block ready" disabled={busy} onClick={() => void solve(q.id)}>Забрать награду</button>
      ) : (
        <>
          <button className="btn btn-gold btn-block" disabled={busy || short > 0} onClick={() => void solve(q.id)}>
            {busy ? 'Выполняем…' : `Принять задание · ${fmt(q.cost ?? 0)}`}
          </button>
          {short > 0 && <p className="error-text center">Не хватает {fmt(short)} монет</p>}
        </>
      )}
    </Modal>
  );
}
