import { useMemo } from 'react';
import { BUILDINGS, checkBuild, computeStats, countOf, countsFromList, priceOf, type BuildCtx } from '../shared';
import { fmt, fmtSigned } from '../lib/format';
import { Icon } from '../components/Icon';
import { Modal } from '../components/ui';
import { BuildingThumb } from '../scene/Thumbs';
import { useGame } from '../state/GameContext';

export function ConfirmBuild({ id }: { id: string }) {
  const { state, closeModal, build, busy } = useGame();
  const c = state!.city;
  const d = BUILDINGS[id];
  const counts = useMemo(() => countsFromList(state!.buildings), [state]);
  if (!d) return null;

  const ctx: BuildCtx = { level: c.level, coins: c.coins, counts, roadRepairs: c.roadRepairs, happinessBonus: c.happinessBonus };
  const chk = checkBuild(ctx, d);
  const price = priceOf(d, countOf(counts, id));
  const before = computeStats(counts, c.roadRepairs, c.happinessBonus);
  const after = computeStats({ ...counts, [id]: countOf(counts, id) + 1 }, c.roadRepairs, c.happinessBonus);
  const dPop = after.population - before.population;
  const dNet = after.net - before.net;
  const dHappy = after.happiness - before.happiness;

  return (
    <Modal onClose={closeModal} title="Подтвердите строительство" className="confirm">
      <div className="confirm-head">
        <div className="bthumb big"><BuildingThumb id={id} /></div>
        <div>
          <h3>{d.name}</h3>
          <p className="hint">{d.blurb}</p>
        </div>
      </div>

      <dl className="rows">
        <div><dt>Население</dt><dd>{fmt(before.population)} → <b>{fmt(after.population)}</b> <em className={dPop >= 0 ? 'up' : 'down'}>({dPop >= 0 ? '+' : '−'}{fmt(Math.abs(dPop))})</em></dd></div>
        <div><dt>Баланс в час</dt><dd>{fmtSigned(before.net)} → <b>{fmtSigned(after.net)}</b> <em className={dNet >= 0 ? 'up' : 'down'}>({dNet >= 0 ? '+' : '−'}{fmt(Math.abs(dNet))})</em></dd></div>
        {dHappy !== 0 && <div><dt>Счастье</dt><dd>{before.happiness}% → <b>{after.happiness}%</b></dd></div>}
        <div><dt>Опыт города</dt><dd><b>+{d.xp}</b></dd></div>
        <div><dt>Стоимость</dt><dd className="price-line"><Icon name="coin" size={16} /><b>{fmt(price)}</b></dd></div>
        <div><dt>Останется монет</dt><dd><b>{fmt(Math.max(0, c.coins - price))}</b></dd></div>
      </dl>

      {!chk.ok && <p className="error-text center">{chk.message}</p>}

      <div className="actions">
        <button className="btn btn-ghost" onClick={closeModal}>Отмена</button>
        <button className="btn btn-gold" disabled={!chk.ok || busy} onClick={() => void build(id)}>
          {busy ? 'Строим…' : `Построить за ${fmt(price)}`}
        </button>
      </div>
    </Modal>
  );
}
