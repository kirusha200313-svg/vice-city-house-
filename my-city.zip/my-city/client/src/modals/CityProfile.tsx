import { useEffect, useState } from 'react';
import type { PublicCityDTO } from '../shared';
import { api } from '../lib/api';
import { fmt } from '../lib/format';
import { Icon } from '../components/Icon';
import { Modal } from '../components/ui';
import { CityScene } from '../scene/CityScene';
import { useGame } from '../state/GameContext';

export function CityProfile({ id }: { id: string }) {
  const { closeModal } = useGame();
  const [city, setCity] = useState<PublicCityDTO | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let alive = true;
    api.city(id).then((c) => alive && setCity(c)).catch(() => alive && setFailed(true));
    return () => { alive = false; };
  }, [id]);

  return (
    <Modal onClose={closeModal} title={city?.name ?? 'Город'} className="profile">
      {failed && <p className="error-text center">Не удалось загрузить город. Попробуйте позже.</p>}
      {!city && !failed && <div className="skeleton" style={{ height: 200 }} />}
      {city && (
        <>
          <CityScene buildings={city.buildings} level={city.level} roadRepairs={city.roadRepairs} cityName={city.name} aspect={1.35} />
          <p className="hint center">Мэр: {city.mayor} · {city.levelName}</p>
          <div className="grid4">
            <div className="stat vert"><Icon name="trophy" className="stat-ico" /><b className="stat-val">#{city.rank}</b><span className="stat-lab">Место</span></div>
            <div className="stat vert"><Icon name="people" className="stat-ico" /><b className="stat-val">{fmt(city.population)}</b><span className="stat-lab">Жителей</span></div>
            <div className="stat vert"><Icon name="bricks" className="stat-ico" /><b className="stat-val">{city.buildingsCount}</b><span className="stat-lab">Построек</span></div>
            <div className="stat vert"><Icon name="smile" className="stat-ico" /><b className="stat-val">{city.happiness}%</b><span className="stat-lab">Счастье</span></div>
          </div>
        </>
      )}
    </Modal>
  );
}
