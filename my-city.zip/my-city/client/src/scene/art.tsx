import type { ReactNode } from 'react';
import { P, px, py, pts, shade, type V3 } from './iso';

/** Границы прямоугольного основания: [x0, y0, x1, y1] в клетках */
export type B = [number, number, number, number];
const fp = (i: number, j: number, inset: number): B => [i + inset, j + inset, i + 1 - inset, j + 1 - inset];

// ------------------------------------------------------------------ примитивы

export function Box({ b, z0 = 0, h, c }: { b: B; z0?: number; h: number; c: string }) {
  const [x0, y0, x1, y1] = b;
  const z1 = z0 + h;
  const l = shade(c, -0.1);
  const r = shade(c, -0.26);
  const t = shade(c, 0.12);
  return (
    <g strokeLinejoin="round" strokeWidth={0.7}>
      <polygon points={pts([x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1])} fill={l} stroke={l} />
      <polygon points={pts([x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1])} fill={r} stroke={r} />
      <polygon points={pts([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1])} fill={t} stroke={t} />
    </g>
  );
}

/** Прямоугольник на видимой грани: 'L' — левая (y = y1), 'R' — правая (x = x1). u — доля ширины, z — высота. */
function faceQuad(face: 'L' | 'R', b: B, u0: number, u1: number, z0: number, z1: number): string {
  const [x0, y0, x1, y1] = b;
  if (face === 'L') {
    const a = x0 + (x1 - x0) * u0;
    const c = x0 + (x1 - x0) * u1;
    return pts([a, y1, z0], [c, y1, z0], [c, y1, z1], [a, y1, z1]);
  }
  const a = y0 + (y1 - y0) * u0;
  const c = y0 + (y1 - y0) * u1;
  return pts([x1, a, z0], [x1, c, z0], [x1, c, z1], [x1, a, z1]);
}

export function FaceQuad(p: { face: 'L' | 'R'; b: B; u0: number; u1: number; z0: number; z1: number; fill: string; stroke?: string }) {
  return <polygon points={faceQuad(p.face, p.b, p.u0, p.u1, p.z0, p.z1)} fill={p.fill} stroke={p.stroke} strokeWidth={p.stroke ? 0.6 : 0} />;
}

export function Windows(p: {
  b: B; face: 'L' | 'R'; z0: number; h: number; cols: number; rows: number;
  c?: string; side?: number; pad?: number; frame?: string;
}) {
  const { b, face, z0, h, cols, rows, side = 0.12, pad = 0.34, frame } = p;
  const c = face === 'L' ? (p.c ?? '#a9dcff') : shade(p.c ?? '#a9dcff', -0.2);
  const cw = (1 - 2 * side) / cols;
  const ch = h / rows;
  const out: ReactNode[] = [];
  for (let r = 0; r < rows; r++) {
    for (let k = 0; k < cols; k++) {
      const u0 = side + k * cw + (cw * pad) / 2;
      const u1 = side + (k + 1) * cw - (cw * pad) / 2;
      const za = z0 + r * ch + (ch * pad) / 2;
      const zb = z0 + (r + 1) * ch - (ch * pad) / 2;
      out.push(<polygon key={`${r}-${k}`} points={faceQuad(face, b, u0, u1, za, zb)} fill={c} stroke={frame} strokeWidth={frame ? 0.5 : 0} />);
    }
  }
  return <g>{out}</g>;
}

export function Gable({ b, z, rh, c, wall, dir = 'x', o = 0.04 }: { b: B; z: number; rh: number; c: string; wall: string; dir?: 'x' | 'y'; o?: number }) {
  const [x0, y0, x1, y1] = b;
  const xm = (x0 + x1) / 2;
  const ym = (y0 + y1) / 2;
  if (dir === 'x') {
    return (
      <g strokeLinejoin="round" strokeWidth={0.7}>
        <polygon points={pts([x1, y0, z], [x1, y1, z], [x1, ym, z + rh])} fill={shade(wall, -0.26)} stroke={shade(wall, -0.26)} />
        <polygon points={pts([x0 - o, y1 + o, z], [x1 + o, y1 + o, z], [x1 + o, ym, z + rh], [x0 - o, ym, z + rh])} fill={shade(c, -0.04)} stroke={shade(c, -0.04)} />
        <polygon points={pts([x1 + o, y1 + o, z], [x1 + o, ym, z + rh], [x1 + o, ym, z + rh - 1.6], [x1 + o, y1 + o, z - 1.6])} fill={shade(c, -0.3)} />
      </g>
    );
  }
  return (
    <g strokeLinejoin="round" strokeWidth={0.7}>
      <polygon points={pts([x0, y1, z], [x1, y1, z], [xm, y1, z + rh])} fill={shade(wall, -0.1)} stroke={shade(wall, -0.1)} />
      <polygon points={pts([x1 + o, y0 - o, z], [x1 + o, y1 + o, z], [xm, y1 + o, z + rh], [xm, y0 - o, z + rh])} fill={shade(c, -0.2)} stroke={shade(c, -0.2)} />
    </g>
  );
}

export function Pyramid({ b, z, rh, c }: { b: B; z: number; rh: number; c: string }) {
  const [x0, y0, x1, y1] = b;
  const xm = (x0 + x1) / 2;
  const ym = (y0 + y1) / 2;
  const l = shade(c, -0.02);
  const r = shade(c, -0.24);
  return (
    <g strokeLinejoin="round" strokeWidth={0.7}>
      <polygon points={pts([x0, y1, z], [x1, y1, z], [xm, ym, z + rh])} fill={l} stroke={l} />
      <polygon points={pts([x1, y0, z], [x1, y1, z], [xm, ym, z + rh])} fill={r} stroke={r} />
    </g>
  );
}

/** Плоская крыша с бортиком */
function RoofTop({ b, z, c, inset = 0.035 }: { b: B; z: number; c: string; inset?: number }) {
  const [x0, y0, x1, y1] = b;
  return <polygon points={pts([x0 + inset, y0 + inset, z + 0.4], [x1 - inset, y0 + inset, z + 0.4], [x1 - inset, y1 - inset, z + 0.4], [x0 + inset, y1 - inset, z + 0.4])} fill={c} />;
}

export function Tree({ x, y, s = 1, c = '#58b05f', pine = false }: { x: number; y: number; s?: number; c?: string; pine?: boolean }) {
  const X = px(x, y);
  const Y = py(x, y);
  return (
    <g transform={`translate(${X.toFixed(1)} ${Y.toFixed(1)})`}>
      <ellipse cx={0} cy={1} rx={9 * s} ry={4 * s} fill="rgba(20,40,20,.18)" />
      <rect x={-1.7 * s} y={-9 * s} width={3.4 * s} height={10 * s} rx={1} fill="#8a5a3b" />
      {pine ? (
        <>
          <polygon points={`0,${-30 * s} ${-9 * s},${-10 * s} ${9 * s},${-10 * s}`} fill={shade(c, -0.18)} />
          <polygon points={`0,${-37 * s} ${-7 * s},${-20 * s} ${7 * s},${-20 * s}`} fill={c} />
        </>
      ) : (
        <>
          <circle cx={0} cy={-16 * s} r={10 * s} fill={shade(c, -0.14)} />
          <circle cx={-3 * s} cy={-19 * s} r={7.6 * s} fill={c} />
          <circle cx={4.2 * s} cy={-14 * s} r={5 * s} fill={shade(c, 0.14)} />
        </>
      )}
    </g>
  );
}

export function Lamp({ x, y, on = true }: { x: number; y: number; on?: boolean }) {
  const X = px(x, y);
  const Y = py(x, y);
  return (
    <g transform={`translate(${X.toFixed(1)} ${Y.toFixed(1)})`}>
      <ellipse cx={0} cy={0.5} rx={4} ry={2} fill="rgba(0,0,0,.18)" />
      {on && <circle cx={0} cy={-28} r={11} fill="rgba(255,226,130,.30)" className="lamp-glow" />}
      <rect x={-1} y={-27} width={2} height={27} fill="#5a6180" />
      <rect x={-1} y={-28} width={6} height={1.8} fill="#5a6180" />
      <rect x={2.6} y={-27} width={4.6} height={3.2} rx={1.2} fill={on ? '#ffe58a' : '#a9b0c6'} />
    </g>
  );
}

function Smoke({ x, y, z }: { x: number; y: number; z: number }) {
  return (
    <g transform={`translate(${px(x, y).toFixed(1)} ${py(x, y, z).toFixed(1)})`}>
      {[0, 1, 2].map((k) => (
        <circle key={k} className="smoke" r={3.2} cx={0} cy={0} fill="#f4f6fb" style={{ animationDelay: `${k * 0.9}s` }} />
      ))}
    </g>
  );
}

const Ell = ({ x, y, z = 0, rx, ry, fill, stroke }: { x: number; y: number; z?: number; rx: number; ry: number; fill: string; stroke?: string }) => (
  <ellipse cx={px(x, y)} cy={py(x, y, z)} rx={rx} ry={ry} fill={fill} stroke={stroke} strokeWidth={stroke ? 0.8 : 0} />
);

// ------------------------------------------------------------------ здания

type Props = { i: number; j: number };

function OldHouse({ i, j }: Props) {
  const b = fp(i, j, 0.22);
  const wall = '#cbb799';
  const h = 24;
  return (
    <g>
      <Box b={b} h={h} c={wall} />
      <FaceQuad face="L" b={b} u0={0.12} u1={0.36} z0={7} z1={18} fill="#6b5846" />
      <FaceQuad face="L" b={b} u0={0.6} u1={0.84} z0={0} z1={15} fill="#58453a" />
      <FaceQuad face="R" b={b} u0={0.3} u1={0.62} z0={8} z1={18} fill="#6b5846" />
      <FaceQuad face="R" b={b} u0={0.34} u1={0.58} z0={10} z1={16} fill="#3e3a46" />
      <Box b={[i + 0.62, j + 0.4, i + 0.72, j + 0.5]} z0={h + 4} h={16} c="#8a6d5b" />
      <Gable b={b} z={h} rh={15} c="#8d6e63" wall={wall} dir="x" o={0.05} />
      <polygon points={pts([i + 0.4, j + 0.78, h + 6], [i + 0.55, j + 0.78, h + 6], [i + 0.55, j + 0.64, h + 11], [i + 0.4, j + 0.64, h + 11])} fill="#a98e7f" />
      <Smoke x={i + 0.67} y={j + 0.45} z={h + 20} />
      <polygon points={pts([i + 0.12, j + 0.95, 0], [i + 0.5, j + 0.95, 0], [i + 0.5, j + 0.95, 7], [i + 0.12, j + 0.95, 7])} fill="none" stroke="#9b8465" strokeWidth={1} strokeDasharray="2 2" />
    </g>
  );
}

function SmallHouse({ i, j }: Props) {
  const b = fp(i, j, 0.17);
  const wall = '#f6d5a8';
  const h = 28;
  return (
    <g>
      <Box b={b} h={h} c={wall} />
      <FaceQuad face="L" b={b} u0={0.14} u1={0.4} z0={9} z1={20} fill="#9fd6f7" stroke="#fff" />
      <FaceQuad face="L" b={b} u0={0.58} u1={0.82} z0={0} z1={17} fill="#8b5a3c" />
      <FaceQuad face="R" b={b} u0={0.3} u1={0.66} z0={9} z1={20} fill="#7bb9dd" stroke="#fff" />
      <Box b={[i + 0.62, j + 0.38, i + 0.74, j + 0.5]} z0={h + 4} h={16} c="#c9806a" />
      <Gable b={b} z={h} rh={17} c="#d9574a" wall={wall} dir="x" />
      <Smoke x={i + 0.68} y={j + 0.44} z={h + 21} />
    </g>
  );
}

function House({ i, j }: Props) {
  const b = fp(i, j, 0.12);
  const wall = '#f8e7c0';
  const h = 42;
  return (
    <g>
      <Box b={b} h={h} c={wall} />
      <Windows b={b} face="L" z0={23} h={15} cols={3} rows={1} c="#9fd6f7" frame="#fff" side={0.1} />
      <Windows b={b} face="L" z0={3} h={15} cols={3} rows={1} c="#9fd6f7" frame="#fff" side={0.1} />
      <FaceQuad face="L" b={b} u0={0.42} u1={0.58} z0={0} z1={16} fill="#8b5a3c" />
      <Windows b={b} face="R" z0={23} h={15} cols={3} rows={1} c="#9fd6f7" frame="#fff" side={0.1} />
      <Windows b={b} face="R" z0={3} h={15} cols={3} rows={1} c="#9fd6f7" frame="#fff" side={0.1} />
      <Gable b={b} z={h} rh={21} c="#4f86c6" wall={wall} dir="y" />
    </g>
  );
}

function Apartment({ i, j }: Props) {
  const b = fp(i, j, 0.1);
  const wall = '#d98f6c';
  const h = 66;
  return (
    <g>
      <Box b={b} h={h} c={wall} />
      <Windows b={b} face="L" z0={14} h={48} cols={3} rows={3} c="#bfe6ff" frame="#f5e4d6" />
      <Windows b={b} face="R" z0={6} h={56} cols={3} rows={3} c="#bfe6ff" frame="#f5e4d6" />
      <FaceQuad face="L" b={b} u0={0.4} u1={0.6} z0={0} z1={12} fill="#5b3b2d" />
      <FaceQuad face="L" b={b} u0={0.34} u1={0.66} z0={12} z1={14.5} fill="#f0dea8" />
      <RoofTop b={b} z={h} c={shade(wall, -0.18)} />
      <Box b={[i + 0.58, j + 0.22, i + 0.76, j + 0.4]} z0={h} h={9} c="#8b95ad" />
    </g>
  );
}

function Midrise({ i, j }: Props) {
  const b = fp(i, j, 0.1);
  const wall = '#a9b9d3';
  const h = 112;
  return (
    <g>
      <Box b={b} h={h} c={wall} />
      <Windows b={b} face="L" z0={10} h={96} cols={3} rows={8} c="#e0f1ff" side={0.1} pad={0.4} />
      <Windows b={b} face="R" z0={10} h={96} cols={3} rows={8} c="#e0f1ff" side={0.1} pad={0.4} />
      <FaceQuad face="L" b={b} u0={0.4} u1={0.6} z0={0} z1={9} fill="#4d5876" />
      <RoofTop b={b} z={h} c={shade(wall, -0.16)} />
      <Box b={[i + 0.35, j + 0.35, i + 0.62, j + 0.62]} z0={h} h={10} c="#8794b0" />
      <polyline points={pts([i + 0.5, j + 0.5, h + 10], [i + 0.5, j + 0.5, h + 32])} stroke="#6b7590" strokeWidth={1.2} fill="none" />
    </g>
  );
}

function Complex({ i, j }: Props) {
  const podium = fp(i, j, 0.04);
  const a: B = [i + 0.1, j + 0.1, i + 0.55, j + 0.55];
  const t: B = [i + 0.45, j + 0.45, i + 0.9, j + 0.9];
  return (
    <g>
      <Box b={podium} h={12} c="#c6bfae" />
      <Box b={a} z0={12} h={100} c="#ece0cc" />
      <Windows b={a} face="L" z0={20} h={86} cols={2} rows={7} c="#cfe9ff" side={0.14} pad={0.4} />
      <Windows b={a} face="R" z0={20} h={86} cols={2} rows={7} c="#cfe9ff" side={0.14} pad={0.4} />
      <RoofTop b={a} z={112} c="#cfc3ad" />
      <Box b={t} z0={12} h={132} c="#c8d9ec" />
      <Windows b={t} face="L" z0={20} h={118} cols={2} rows={9} c="#eef7ff" side={0.14} pad={0.4} />
      <Windows b={t} face="R" z0={20} h={118} cols={2} rows={9} c="#eef7ff" side={0.14} pad={0.4} />
      <RoofTop b={t} z={144} c="#a9bbd1" />
      <Tree x={i + 0.14} y={j + 0.88} s={0.6} />
      <Tree x={i + 0.9} y={j + 0.16} s={0.6} c="#6cbf6a" />
    </g>
  );
}

function Skyscraper({ i, j }: Props) {
  const b1 = fp(i, j, 0.1);
  const b2 = fp(i, j, 0.2);
  const b3 = fp(i, j, 0.3);
  return (
    <g>
      <Box b={b1} h={80} c="#79b9ea" />
      <Windows b={b1} face="L" z0={6} h={68} cols={4} rows={7} c="#dff3ff" side={0.1} pad={0.3} />
      <Windows b={b1} face="R" z0={6} h={68} cols={4} rows={7} c="#dff3ff" side={0.1} pad={0.3} />
      <FaceQuad face="L" b={b1} u0={0.42} u1={0.58} z0={0} z1={9} fill="#3f6e9a" />
      <Box b={b2} z0={80} h={70} c="#6aaee3" />
      <Windows b={b2} face="L" z0={84} h={62} cols={4} rows={6} c="#dff3ff" side={0.1} pad={0.3} />
      <Windows b={b2} face="R" z0={84} h={62} cols={4} rows={6} c="#dff3ff" side={0.1} pad={0.3} />
      <Box b={b3} z0={150} h={62} c="#5aa2da" />
      <Windows b={b3} face="L" z0={154} h={54} cols={3} rows={6} c="#dff3ff" side={0.1} pad={0.3} />
      <Windows b={b3} face="R" z0={154} h={54} cols={3} rows={6} c="#dff3ff" side={0.1} pad={0.3} />
      <polyline points={pts([i + 0.5, j + 0.5, 212], [i + 0.5, j + 0.5, 242])} stroke="#5d6a86" strokeWidth={1.6} fill="none" />
      <circle cx={px(i + 0.5, j + 0.5)} cy={py(i + 0.5, j + 0.5, 243)} r={2.4} fill="#ff5a5a" className="blink" />
    </g>
  );
}

function Kindergarten({ i, j }: Props) {
  const b = fp(i, j, 0.12);
  const wall = '#ffe08a';
  const h = 22;
  return (
    <g>
      <Box b={b} h={h} c={wall} />
      <Windows b={b} face="L" z0={5} h={13} cols={3} rows={1} c="#bfe6ff" frame="#fff" side={0.1} pad={0.3} />
      <FaceQuad face="L" b={b} u0={0.42} u1={0.58} z0={0} z1={12} fill="#e8765a" />
      <Windows b={b} face="R" z0={5} h={13} cols={2} rows={1} c="#bfe6ff" frame="#fff" side={0.14} pad={0.3} />
      <Gable b={b} z={h} rh={11} c="#ff8c6b" wall={wall} dir="x" />
      <circle cx={px(i + 0.2, j + 0.94)} cy={py(i + 0.2, j + 0.94, 4)} r={4} fill="#ff6b6b" />
      <circle cx={px(i + 0.34, j + 0.96)} cy={py(i + 0.34, j + 0.96, 3)} r={3.2} fill="#5db7ff" />
      <circle cx={px(i + 0.46, j + 0.94)} cy={py(i + 0.46, j + 0.94, 3)} r={3.2} fill="#5ccf86" />
    </g>
  );
}

function School({ i, j }: Props) {
  const b: B = [i + 0.08, j + 0.14, i + 0.92, j + 0.86];
  const tw: B = [i + 0.38, j + 0.38, i + 0.62, j + 0.62];
  const wall = '#e9a45f';
  const h = 34;
  return (
    <g>
      <Box b={b} h={h} c={wall} />
      <Windows b={b} face="L" z0={8} h={22} cols={5} rows={2} c="#d6efff" frame="#f7e2c8" side={0.08} pad={0.32} />
      <Windows b={b} face="R" z0={8} h={22} cols={3} rows={2} c="#d6efff" frame="#f7e2c8" side={0.1} pad={0.32} />
      <FaceQuad face="L" b={b} u0={0.44} u1={0.56} z0={0} z1={10} fill="#6b4535" />
      <RoofTop b={b} z={h} c="#c98a4a" />
      <Box b={tw} z0={h} h={22} c="#d98c47" />
      <FaceQuad face="L" b={tw} u0={0.3} u1={0.7} z0={h + 6} z1={h + 16} fill="#fff6e0" stroke="#8f4f3a" />
      <Pyramid b={tw} z={h + 22} rh={15} c="#8f4f3a" />
      <polyline points={pts([i + 0.5, j + 0.5, h + 37], [i + 0.5, j + 0.5, h + 50])} stroke="#6b5a4a" strokeWidth={1.2} fill="none" />
      <polygon points={pts([i + 0.5, j + 0.5, h + 50], [i + 0.5, j + 0.5, h + 45], [i + 0.62, j + 0.5, h + 47.5])} fill="#ff5a5a" />
    </g>
  );
}

function Police({ i, j }: Props) {
  const b = fp(i, j, 0.13);
  const wall = '#7a97e6';
  const h = 38;
  return (
    <g>
      <Box b={b} h={h} c={wall} />
      <Windows b={b} face="L" z0={8} h={24} cols={3} rows={1} c="#d6efff" frame="#e8eeff" side={0.1} pad={0.3} />
      <Windows b={b} face="R" z0={8} h={24} cols={2} rows={1} c="#d6efff" frame="#e8eeff" side={0.12} pad={0.3} />
      <FaceQuad face="L" b={b} u0={0.42} u1={0.58} z0={0} z1={12} fill="#3a4a8a" />
      <FaceQuad face="L" b={b} u0={0.4} u1={0.6} z0={26} z1={35} fill="#ffd54a" />
      <RoofTop b={b} z={h} c="#5069b8" />
      <circle cx={px(i + 0.35, j + 0.5)} cy={py(i + 0.35, j + 0.5, h + 4)} r={2.6} fill="#ff4d4d" className="blink" />
      <circle cx={px(i + 0.62, j + 0.5)} cy={py(i + 0.62, j + 0.5, h + 4)} r={2.6} fill="#4da3ff" className="blink b2" />
    </g>
  );
}

function Fire({ i, j }: Props) {
  const b = fp(i, j, 0.1);
  const tw: B = [i + 0.62, j + 0.14, i + 0.86, j + 0.38];
  const wall = '#e95b52';
  const h = 36;
  return (
    <g>
      <Box b={tw} h={h + 22} c="#c84640" />
      <Box b={b} h={h} c={wall} />
      <FaceQuad face="L" b={b} u0={0.08} u1={0.3} z0={0} z1={22} fill="#f5f0e6" stroke="#b9b3a8" />
      <FaceQuad face="L" b={b} u0={0.36} u1={0.58} z0={0} z1={22} fill="#f5f0e6" stroke="#b9b3a8" />
      <FaceQuad face="L" b={b} u0={0.64} u1={0.86} z0={0} z1={22} fill="#f5f0e6" stroke="#b9b3a8" />
      <Windows b={b} face="L" z0={25} h={9} cols={4} rows={1} c="#ffe9a8" side={0.1} pad={0.4} />
      <Windows b={b} face="R" z0={10} h={20} cols={2} rows={1} c="#ffe9a8" side={0.16} pad={0.4} />
      <RoofTop b={b} z={h} c="#a63a35" />
      <circle cx={px(i + 0.74, j + 0.26)} cy={py(i + 0.74, j + 0.26, h + 25)} r={2.6} fill="#ffcf4d" className="blink" />
    </g>
  );
}

function Hospital({ i, j }: Props) {
  const b = fp(i, j, 0.1);
  const wall = '#f4f7fc';
  const h = 72;
  return (
    <g>
      <Box b={b} h={h} c={wall} />
      <Windows b={b} face="L" z0={12} h={46} cols={3} rows={3} c="#9fd3f5" frame="#dfe6f2" side={0.1} pad={0.4} />
      <Windows b={b} face="R" z0={8} h={52} cols={3} rows={4} c="#9fd3f5" frame="#dfe6f2" side={0.1} pad={0.4} />
      <FaceQuad face="L" b={b} u0={0.4} u1={0.6} z0={0} z1={11} fill="#6dbdea" />
      <FaceQuad face="L" b={b} u0={0.34} u1={0.66} z0={11} z1={13} fill="#e5484d" />
      <FaceQuad face="L" b={b} u0={0.45} u1={0.55} z0={58} z1={70} fill="#e5484d" />
      <FaceQuad face="L" b={b} u0={0.4} u1={0.6} z0={62} z1={66} fill="#e5484d" />
      <RoofTop b={b} z={h} c="#d6deec" />
      <Box b={[i + 0.52, j + 0.52, i + 0.7, j + 0.7]} z0={h} h={9} c="#c7d1e3" />
    </g>
  );
}

function Lawn({ b, c = '#7cc86e' }: { b: B; c?: string }) {
  const [x0, y0, x1, y1] = b;
  return <polygon points={pts([x0, y0, 0.4], [x1, y0, 0.4], [x1, y1, 0.4], [x0, y1, 0.4])} fill={c} stroke={shade(c, -0.12)} strokeWidth={0.8} />;
}

function Square({ i, j }: Props) {
  const b = fp(i, j, 0.05);
  const cx = i + 0.5;
  const cy = j + 0.5;
  return (
    <g>
      <Lawn b={b} />
      <polygon points={pts([i + 0.44, j + 0.05, 0.6], [i + 0.56, j + 0.05, 0.6], [i + 0.56, j + 0.95, 0.6], [i + 0.44, j + 0.95, 0.6])} fill="#efe3c0" />
      <polygon points={pts([i + 0.05, j + 0.44, 0.6], [i + 0.95, j + 0.44, 0.6], [i + 0.95, j + 0.56, 0.6], [i + 0.05, j + 0.56, 0.6])} fill="#efe3c0" />
      <Ell x={cx} y={cy} z={1} rx={14} ry={7} fill="#dfe8f5" stroke="#b8c6dc" />
      <Ell x={cx} y={cy} z={3} rx={10.5} ry={5.2} fill="#8bd3f5" />
      <rect x={px(cx, cy) - 1.2} y={py(cx, cy, 14)} width={2.4} height={11} fill="#d6f1ff" rx={1} />
      <circle cx={px(cx, cy)} cy={py(cx, cy, 15)} r={2.4} fill="#e9f8ff" />
      <Box b={[i + 0.12, j + 0.18, i + 0.34, j + 0.26]} h={4} c="#9b6a43" />
      <Box b={[i + 0.66, j + 0.74, i + 0.88, j + 0.82]} h={4} c="#9b6a43" />
      <Tree x={i + 0.22} y={j + 0.8} s={0.75} c="#62b866" />
      <Tree x={i + 0.82} y={j + 0.24} s={0.7} c="#6cc16f" />
    </g>
  );
}

function Park({ i, j }: Props) {
  const b = fp(i, j, 0.03);
  return (
    <g>
      <Lawn b={b} c="#74c46a" />
      <polygon points={pts([i + 0.08, j + 0.78, 0.6], [i + 0.2, j + 0.7, 0.6], [i + 0.9, j + 0.4, 0.6], [i + 0.92, j + 0.5, 0.6], [i + 0.2, j + 0.86, 0.6])} fill="#efe3c0" />
      <Ell x={i + 0.66} y={j + 0.3} z={1} rx={17} ry={8.5} fill="#6bc1e8" stroke="#4aa3cf" />
      <Ell x={i + 0.6} y={j + 0.28} z={1.5} rx={7} ry={3} fill="#a9e2f7" />
      <Tree x={i + 0.2} y={j + 0.25} s={1.05} c="#4fae5a" />
      <Tree x={i + 0.45} y={j + 0.14} s={0.85} c="#5bbb62" pine />
      <Tree x={i + 0.9} y={j + 0.7} s={1.0} c="#4fae5a" />
      <Tree x={i + 0.42} y={j + 0.62} s={0.8} c="#67c46c" />
      <Tree x={i + 0.15} y={j + 0.92} s={0.9} c="#58b05f" />
      <circle cx={px(i + 0.3, j + 0.5)} cy={py(i + 0.3, j + 0.5, 1)} r={1.8} fill="#ff8fb1" />
      <circle cx={px(i + 0.36, j + 0.54)} cy={py(i + 0.36, j + 0.54, 1)} r={1.8} fill="#ffd54a" />
      <circle cx={px(i + 0.58, j + 0.82)} cy={py(i + 0.58, j + 0.82, 1)} r={1.8} fill="#ff8fb1" />
    </g>
  );
}

function Cinema({ i, j }: Props) {
  const b = fp(i, j, 0.12);
  const wall = '#6a4fa5';
  const h = 46;
  return (
    <g>
      <Box b={b} h={h} c={wall} />
      <FaceQuad face="L" b={b} u0={0.08} u1={0.92} z0={18} z1={30} fill="#ffd54a" stroke="#c9a02e" />
      {[0.16, 0.3, 0.44, 0.58, 0.72, 0.86].map((u) => (
        <FaceQuad key={u} face="L" b={b} u0={u - 0.02} u1={u + 0.02} z0={22} z1={26} fill="#fff6c8" />
      ))}
      <FaceQuad face="L" b={b} u0={0.4} u1={0.6} z0={0} z1={13} fill="#2f2350" />
      <Windows b={b} face="R" z0={10} h={26} cols={2} rows={1} c="#ffb6d9" side={0.16} pad={0.4} />
      <RoofTop b={b} z={h} c="#503a86" />
      <Box b={[i + 0.2, j + 0.4, i + 0.8, j + 0.5]} z0={h} h={20} c="#ff6fae" />
      <FaceQuad face="L" b={[i + 0.2, j + 0.4, i + 0.8, j + 0.5]} u0={0.12} u1={0.88} z0={h + 4} z1={h + 16} fill="#fff0f7" />
    </g>
  );
}

function Mall({ i, j }: Props) {
  const b: B = [i + 0.06, j + 0.14, i + 0.94, j + 0.86];
  const wall = '#f3eef2';
  const h = 44;
  return (
    <g>
      <Box b={b} h={h} c={wall} />
      <Windows b={b} face="L" z0={6} h={30} cols={6} rows={2} c="#7fd0ff" frame="#e6e0e6" side={0.06} pad={0.22} />
      <Windows b={b} face="R" z0={6} h={30} cols={3} rows={2} c="#7fd0ff" frame="#e6e0e6" side={0.08} pad={0.22} />
      <FaceQuad face="L" b={b} u0={0.4} u1={0.6} z0={0} z1={13} fill="#3f8fc4" />
      <FaceQuad face="L" b={b} u0={0.34} u1={0.66} z0={13} z1={16} fill="#ff7a59" />
      <RoofTop b={b} z={h} c="#d8d1d8" />
      <Box b={[i + 0.32, j + 0.4, i + 0.68, j + 0.62]} z0={h} h={14} c="#ff7a59" />
      <FaceQuad face="L" b={[i + 0.32, j + 0.4, i + 0.68, j + 0.62]} u0={0.15} u1={0.85} z0={h + 4} z1={h + 11} fill="#fff2ea" />
    </g>
  );
}

function Stadium({ i, j }: Props) {
  const cx = px(i + 0.5, j + 0.5);
  const cy = py(i + 0.5, j + 0.5);
  const rx = 31;
  const ry = 15.5;
  const hh = 26;
  const side = '#c4cde0';
  return (
    <g>
      <ellipse cx={cx} cy={cy + 2} rx={rx + 2} ry={ry + 1} fill="rgba(30,50,30,.18)" />
      <path d={`M${cx - rx},${cy - hh} L${cx - rx},${cy} A${rx},${ry} 0 0 0 ${cx + rx},${cy} L${cx + rx},${cy - hh} Z`} fill={side} />
      <path d={`M${cx},${cy + ry} A${rx},${ry} 0 0 0 ${cx + rx},${cy} L${cx + rx},${cy - hh} A${rx},${ry} 0 0 1 ${cx},${cy - hh + ry} Z`} fill="#a9b4cc" />
      <ellipse cx={cx} cy={cy - hh} rx={rx} ry={ry} fill="#e6ebf5" stroke="#b4bfd6" strokeWidth={0.8} />
      <ellipse cx={cx} cy={cy - hh + 1.5} rx={rx - 7} ry={ry - 3.5} fill="#cdd5e6" />
      <ellipse cx={cx} cy={cy - hh + 5} rx={rx - 11} ry={ry - 5.6} fill="#5bbf63" />
      <ellipse cx={cx} cy={cy - hh + 5} rx={rx - 17} ry={ry - 8.5} fill="none" stroke="#e8fbe8" strokeWidth={0.9} />
      <line x1={cx} y1={cy - hh + 5 - (ry - 5.6)} x2={cx} y2={cy - hh + 5 + (ry - 5.6)} stroke="#e8fbe8" strokeWidth={0.9} />
      {[-1, 1].map((s) => (
        <g key={s}>
          <rect x={cx + s * (rx - 3) - 0.9} y={cy - hh - 22 - (s === 1 ? 0 : 0)} width={1.8} height={24} fill="#6a7390" />
          <rect x={cx + s * (rx - 3) - 4} y={cy - hh - 26} width={8} height={4.5} rx={1} fill="#fff3b0" />
        </g>
      ))}
    </g>
  );
}

function Parking({ i, j }: Props) {
  const b = fp(i, j, 0.05);
  return (
    <g>
      <Lawn b={b} c="#6d7388" />
      {[0.25, 0.5, 0.75].map((v) => (
        <polygon key={v} points={pts([i + v - 0.015, j + 0.12, 0.7], [i + v + 0.015, j + 0.12, 0.7], [i + v + 0.015, j + 0.88, 0.7], [i + v - 0.015, j + 0.88, 0.7])} fill="#f0f2f8" />
      ))}
      <Box b={[i + 0.31, j + 0.22, i + 0.44, j + 0.46]} h={6} c="#e5584f" />
      <Box b={[i + 0.33, j + 0.26, i + 0.42, j + 0.4]} z0={6} h={4} c="#f3b0aa" />
      <Box b={[i + 0.56, j + 0.52, i + 0.69, j + 0.76]} h={6} c="#4f86c6" />
      <Box b={[i + 0.58, j + 0.56, i + 0.67, j + 0.7]} z0={6} h={4} c="#a9c8ea" />
    </g>
  );
}

function Bridge({ i, j }: Props) {
  const b = fp(i, j, 0.02);
  return (
    <g>
      <Lawn b={b} c="#6bc1e8" />
      <Box b={[i + 0.0, j + 0.14, i + 0.08, j + 0.86]} h={4} c="#a8946f" />
      <Box b={[i + 0.92, j + 0.14, i + 1.0, j + 0.86]} h={4} c="#a8946f" />
      <Box b={[i + 0.2, j + 0.0, i + 0.8, j + 1.0]} z0={3} h={5} c="#dcd2c0" />
      <Box b={[i + 0.2, j + 0.0, i + 0.26, j + 1.0]} z0={8} h={4} c="#b9ad98" />
      <Box b={[i + 0.74, j + 0.0, i + 0.8, j + 1.0]} z0={8} h={4} c="#b9ad98" />
      <polygon points={pts([i + 0.2, j + 1.0, 3], [i + 0.8, j + 1.0, 3], [i + 0.8, j + 1.0, 0], [i + 0.2, j + 1.0, 0])} fill="#8f8570" />
    </g>
  );
}

function RoadArt({ i, j }: Props) {
  return (
    <g>
      <Lawn b={[i, j, i + 1, j + 1]} c="#5a6177" />
      <polygon points={pts([i + 0.46, j + 0.1, 0.7], [i + 0.54, j + 0.1, 0.7], [i + 0.54, j + 0.4, 0.7], [i + 0.46, j + 0.4, 0.7])} fill="#f4e9b8" />
      <polygon points={pts([i + 0.46, j + 0.6, 0.7], [i + 0.54, j + 0.6, 0.7], [i + 0.54, j + 0.9, 0.7], [i + 0.46, j + 0.9, 0.7])} fill="#f4e9b8" />
    </g>
  );
}
function SidewalkArt({ i, j }: Props) {
  return (
    <g>
      <Lawn b={[i, j, i + 1, j + 1]} c="#5a6177" />
      <polygon points={pts([i, j, 0.8], [i + 0.22, j, 0.8], [i + 0.22, j + 1, 0.8], [i, j + 1, 0.8])} fill="#dcd8cc" />
      <polygon points={pts([i + 0.78, j, 0.8], [i + 1, j, 0.8], [i + 1, j + 1, 0.8], [i + 0.78, j + 1, 0.8])} fill="#dcd8cc" />
    </g>
  );
}
function LightingArt({ i, j }: Props) {
  return (
    <g>
      <Lawn b={[i, j, i + 1, j + 1]} c="#7cc86e" />
      <Lamp x={i + 0.5} y={j + 0.7} />
    </g>
  );
}

const ART: Record<string, (p: Props) => ReactNode> = {
  old_house: OldHouse, small_house: SmallHouse, house: House, apartment: Apartment, midrise: Midrise,
  complex: Complex, skyscraper: Skyscraper, kindergarten: Kindergarten, school: School, police: Police,
  fire: Fire, hospital: Hospital, square: Square, park: Park, cinema: Cinema, mall: Mall, stadium: Stadium,
  parking: Parking, bridge: Bridge, road: RoadArt, sidewalk: SidewalkArt, lighting: LightingArt,
};

/** Высота рисунка здания в пикселях (для кадрирования миниатюр и камеры) */
export const ART_HEIGHT: Record<string, number> = {
  old_house: 48, small_house: 56, house: 70, apartment: 80, midrise: 142, complex: 158, skyscraper: 252,
  kindergarten: 40, school: 92, police: 50, fire: 70, hospital: 96, square: 42, park: 48, cinema: 90,
  mall: 70, stadium: 60, parking: 24, bridge: 24, road: 12, sidewalk: 12, lighting: 36,
};

export function BuildingArt({ id, i, j }: { id: string; i: number; j: number }) {
  const C = ART[id];
  return C ? <>{C({ i, j })}</> : null;
}
