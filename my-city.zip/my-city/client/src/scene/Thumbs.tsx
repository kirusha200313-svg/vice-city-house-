import { useMemo } from 'react';
import { BUILDINGS } from '../shared';
import { ART_HEIGHT, Box, BuildingArt } from './art';
import { AVENUE_X, LOTS, MAP, pts, px, py } from './iso';

/** Миниатюра одного здания (каталог, уровень, профиль) */
export function BuildingThumb({ id, className = 'thumb' }: { id: string; className?: string }) {
  const h = Math.min(ART_HEIGHT[id] ?? 40, 210);
  return (
    <svg className={className} viewBox={`-37 ${-h - 6} 74 ${h + 6 + 38}`} preserveAspectRatio="xMidYMax meet" aria-hidden="true">
      <polygon points={pts([0, 0], [1, 0], [1, 1], [0, 1])} fill="#9bd77a" stroke="#86c566" strokeWidth={0.8} />
      <BuildingArt id={id} i={0} j={0} />
    </svg>
  );
}

const MINI: Record<string, string> = {
  old_house: '#c9b79c', small_house: '#f0c89a', house: '#f4e0b0', apartment: '#d98f6c', midrise: '#a9b9d3',
  complex: '#d8cdb6', skyscraper: '#6aaee3', kindergarten: '#ffd36e', school: '#e9a45f', police: '#7a97e6',
  fire: '#e95b52', hospital: '#f4f7fc', square: '#5fbf6a', park: '#4fae5a', cinema: '#6a4fa5', mall: '#f3eef2',
  stadium: '#c4cde0', parking: '#6d7388', bridge: '#6bc1e8',
};

/** Упрощённая миниатюра города для рейтинга: цветные кубики по участкам */
export function MiniCity({ buildings }: { buildings: string[] }) {
  const boxes = useMemo(() => {
    const out: { id: string; i: number; j: number }[] = [];
    let k = 0;
    for (const id of buildings) {
      if (!BUILDINGS[id]?.takesLot) continue;
      const lot = LOTS[k++];
      if (lot) out.push({ id, i: lot.i, j: lot.j });
    }
    return out.sort((a, b) => a.i + a.j - (b.i + b.j));
  }, [buildings]);

  let top = 0;
  for (const b of boxes) top = Math.max(top, (ART_HEIGHT[b.id] ?? 30) * 0.5 - py(b.i, b.j));
  const y0 = -top - 8;
  return (
    <svg className="mini-city" viewBox={`-266 ${y0} 532 ${py(MAP, MAP) + 30 - y0}`} preserveAspectRatio="xMidYMid meet" aria-hidden="true">
      <polygon points={pts([0, 0], [MAP, 0], [MAP, MAP], [0, MAP])} fill="#8fd179" />
      <polygon points={pts([AVENUE_X, 0], [AVENUE_X + 1, 0], [AVENUE_X + 1, MAP], [AVENUE_X, MAP])} fill="#6a7088" />
      <polygon points={pts([0, MAP, 0], [MAP, MAP, 0], [MAP, MAP, -16], [0, MAP, -16])} fill="#8d6e4f" />
      <polygon points={pts([MAP, MAP, 0], [MAP, 0, 0], [MAP, 0, -16], [MAP, MAP, -16])} fill="#6f553e" />
      {boxes.map((b) => {
        const flat = b.id === 'park' || b.id === 'square' || b.id === 'parking' || b.id === 'bridge';
        return <Box key={`${b.i}-${b.j}`} b={[b.i + 0.08, b.j + 0.08, b.i + 0.92, b.j + 0.92]} h={flat ? 4 : Math.max(10, (ART_HEIGHT[b.id] ?? 30) * 0.55)} c={MINI[b.id] ?? '#ccc'} />;
      })}
      <circle cx={px(0, 0)} cy={py(0, 0)} r={0} />
    </svg>
  );
}
