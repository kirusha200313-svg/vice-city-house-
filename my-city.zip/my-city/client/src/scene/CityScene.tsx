import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { BUILDINGS } from '../shared';
import { ART_HEIGHT, BuildingArt, Lamp, Tree } from './art';
import { AVENUE_X, ISLAND_DEPTH, LOTS, MAP, P, SEGMENT_ORDER, hash2, mix, px, py, pts, type Lot } from './iso';

interface Props {
  buildings: string[];
  level: number;
  roadRepairs?: number;
  selected?: number | null;
  fresh?: { index: number; key: number } | null;
  onSelect?: (index: number) => void;
  cityName?: string;
  /** Отношение ширины к высоте окна сцены */
  aspect?: number;
  className?: string;
  children?: ReactNode;
}

interface View { x: number; y: number; w: number; h: number }

interface Placed { id: string; index: number; lot: Lot }

function computeView(placed: Placed[], aspect: number): View {
  const shown = LOTS.slice(0, Math.max(13, placed.length + 3));
  const heightByLot = new Map<number, number>();
  placed.forEach((p, k) => heightByLot.set(k, ART_HEIGHT[p.id] ?? 40));
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  shown.forEach((l, k) => {
    const H = heightByLot.get(k) ?? 32;
    minX = Math.min(minX, px(l.i, l.j + 1) - 6);
    maxX = Math.max(maxX, px(l.i + 1, l.j) + 6);
    minY = Math.min(minY, py(l.i, l.j) - H);
    maxY = Math.max(maxY, py(l.i + 1, l.j + 1) + 8);
  });
  minX -= 22; maxX += 22; minY -= 14; maxY += 40;
  let w = maxX - minX;
  let h = maxY - minY;
  const cx = (minX + maxX) / 2;
  const cy = (minY + maxY) / 2;
  if (w < 340) w = 340;
  if (w / h < aspect) w = h * aspect;
  else h = w / aspect;
  return { x: cx - w / 2, y: cy - h / 2, w, h };
}

export function CityScene({ buildings, level, roadRepairs = 0, selected = null, fresh = null, onSelect, cityName, aspect = 1.22, className = '', children }: Props) {
  const { placed, roads, walks, lamps } = useMemo(() => {
    const placed: Placed[] = [];
    let roads = 0, walks = 0, lamps = 0;
    buildings.forEach((id, index) => {
      if (id === 'road') roads++;
      else if (id === 'sidewalk') walks++;
      else if (id === 'lighting') lamps++;
      else if (BUILDINGS[id]?.takesLot) {
        const lot = LOTS[placed.length];
        if (lot) placed.push({ id, index, lot });
      }
    });
    return { placed, roads, walks, lamps };
  }, [buildings]);

  // ---- камера: плавно приближается/отдаляется по мере роста города
  const target = useMemo(() => computeView(placed, aspect), [placed, aspect]);
  const [view, setView] = useState<View>(target);
  const cur = useRef<View>(target);
  useEffect(() => {
    const reduce = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) { cur.current = target; setView(target); return; }
    const from = cur.current;
    const t0 = performance.now();
    let raf = 0;
    const step = (t: number) => {
      const k = Math.min(1, (t - t0) / 800);
      const e = 1 - Math.pow(1 - k, 3);
      const v = { x: from.x + (target.x - from.x) * e, y: from.y + (target.y - from.y) * e, w: from.w + (target.w - from.w) * e, h: from.h + (target.h - from.h) * e };
      cur.current = v;
      setView(v);
      if (k < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target]);

  // ---- земля: клетки, проспект, свободные участки
  const t = Math.min(1, Math.max(0, (level - 1) / 7));
  const grassA = mix('#a9c97a', '#86d474', t);
  const grassB = mix('#a1c272', '#7bcb6b', t);
  const paved = Math.min(MAP, roads + roadRepairs);
  const walkSeg = Math.min(MAP, walks);

  const ground = useMemo(() => {
    const occupied = new Set(placed.map((p) => `${p.lot.i},${p.lot.j}`));
    const out: ReactNode[] = [];
    for (let i = 0; i < MAP; i++) {
      for (let j = 0; j < MAP; j++) {
        const key = `${i}-${j}`;
        if (i === AVENUE_X) {
          const rank = SEGMENT_ORDER.indexOf(j);
          const isPaved = rank < paved;
          const hasWalk = rank < walkSeg;
          const base = isPaved ? '#59607a' : '#c7a77b';
          out.push(
            <g key={key}>
              <polygon points={pts([i, j], [i + 1, j], [i + 1, j + 1], [i, j + 1])} fill={base} stroke={base} strokeWidth={0.6} />
              {isPaved ? (
                <>
                  <polygon points={pts([i + 0.47, j + 0.08, 0], [i + 0.53, j + 0.08, 0], [i + 0.53, j + 0.4, 0], [i + 0.47, j + 0.4, 0])} fill="#f4e9b8" />
                  <polygon points={pts([i + 0.47, j + 0.6, 0], [i + 0.53, j + 0.6, 0], [i + 0.53, j + 0.92, 0], [i + 0.47, j + 0.92, 0])} fill="#f4e9b8" />
                </>
              ) : (
                <>
                  <ellipse cx={px(i + 0.3 + hash2(j, 1) * 0.3, j + 0.3)} cy={py(i + 0.3 + hash2(j, 1) * 0.3, j + 0.3)} rx={9} ry={4.4} fill="#6f5a40" />
                  <ellipse cx={px(i + 0.3 + hash2(j, 1) * 0.3, j + 0.3)} cy={py(i + 0.3 + hash2(j, 1) * 0.3, j + 0.3) - 0.8} rx={7.6} ry={3.5} fill="#9b8061" />
                  <ellipse cx={px(i + 0.62, j + 0.74)} cy={py(i + 0.62, j + 0.74)} rx={6} ry={3} fill="#6f5a40" />
                  <polyline points={pts([i + 0.12, j + 0.5], [i + 0.3, j + 0.58], [i + 0.4, j + 0.5], [i + 0.55, j + 0.62])} fill="none" stroke="#8a7050" strokeWidth={1} />
                </>
              )}
              {hasWalk && (
                <>
                  <polygon points={pts([i, j, 0], [i + 0.13, j, 0], [i + 0.13, j + 1, 0], [i, j + 1, 0])} fill="#e0dccf" />
                  <polygon points={pts([i + 0.87, j, 0], [i + 1, j, 0], [i + 1, j + 1, 0], [i + 0.87, j + 1, 0])} fill="#e0dccf" />
                </>
              )}
            </g>,
          );
        } else {
          const base = (i + j) % 2 === 0 ? grassA : grassB;
          const empty = !occupied.has(`${i},${j}`);
          out.push(
            <g key={key}>
              <polygon points={pts([i, j], [i + 1, j], [i + 1, j + 1], [i, j + 1])} fill={base} stroke={base} strokeWidth={0.6} />
              {empty && hash2(i, j) < 0.45 && level <= 4 && (
                <ellipse cx={px(i + 0.5, j + 0.55)} cy={py(i + 0.5, j + 0.55)} rx={13 + hash2(j, i) * 6} ry={6 + hash2(i, i) * 2} fill="#c9b27c" opacity={0.7} />
              )}
            </g>,
          );
        }
      }
    }
    return out;
  }, [placed, paved, walkSeg, grassA, grassB, level]);

  // ---- объекты (деревья, фонари, здания) сортируются по глубине
  const objects = useMemo(() => {
    const items: { depth: number; key: string; node: ReactNode }[] = [];
    const occupied = placed.length;
    LOTS.forEach((l, k) => {
      if (k < occupied) return;
      const r = hash2(l.i * 3 + 1, l.j * 5 + 2);
      if (r < 0.45) {
        const n = r < 0.12 ? 2 : 1;
        for (let q = 0; q < n; q++) {
          const x = l.i + 0.25 + hash2(l.i + q, l.j) * 0.5;
          const y = l.j + 0.25 + hash2(l.j + q, l.i + 7) * 0.5;
          items.push({ depth: x + y, key: `t${l.i}-${l.j}-${q}`, node: <Tree x={x} y={y} s={0.8 + hash2(q, l.i + l.j) * 0.35} pine={hash2(l.j, q + 3) < 0.3} c={hash2(l.i, l.j + q) < 0.5 ? '#58b05f' : '#67c06c'} /> });
        }
      }
    });
    for (let k = 0; k < lamps; k++) {
      const seg = SEGMENT_ORDER[Math.floor(k / 2) % MAP];
      const side = k % 2;
      const x = AVENUE_X + (side === 0 ? 0.07 : 0.93);
      items.push({ depth: x + seg + 0.5, key: `l${k}`, node: <Lamp x={x} y={seg + 0.5} /> });
    }
    placed.forEach((p) => {
      const isFresh = fresh?.index === p.index;
      const isSel = selected === p.index;
      items.push({
        depth: p.lot.i + p.lot.j + 1,
        key: `b${p.index}${isFresh ? '-' + fresh!.key : ''}`,
        node: (
          <g
            className={`bld${isFresh ? ' drop' : ''}${isSel ? ' sel' : ''}${onSelect ? ' tap' : ''}`}
            onClick={onSelect ? () => onSelect(p.index) : undefined}
          >
            <BuildingArt id={p.id} i={p.lot.i} j={p.lot.j} />
          </g>
        ),
      });
    });
    return items.sort((a, b) => a.depth - b.depth || (a.key < b.key ? -1 : 1));
  }, [placed, lamps, fresh, selected, onSelect]);

  const selLot = selected !== null ? placed.find((p) => p.index === selected)?.lot : undefined;

  return (
    <div className={`scene ${className}`} style={{ aspectRatio: String(aspect) }}>
      <Skyline level={level} />
      <div className="cloud c1" />
      <div className="cloud c2" />
      <div className="cloud c3" />
      <svg className="scene-svg" viewBox={`${view.x.toFixed(1)} ${view.y.toFixed(1)} ${view.w.toFixed(1)} ${view.h.toFixed(1)}`} preserveAspectRatio="xMidYMid slice" role="img" aria-label={cityName ? `Город ${cityName}` : 'Город'}>
        <polygon points={pts([0, MAP, 0], [MAP, MAP, 0], [MAP, MAP, -ISLAND_DEPTH], [0, MAP, -ISLAND_DEPTH])} fill="#8d6e4f" />
        <polygon points={pts([MAP, MAP, 0], [MAP, 0, 0], [MAP, 0, -ISLAND_DEPTH], [MAP, MAP, -ISLAND_DEPTH])} fill="#6f553e" />
        <polygon points={pts([0, MAP, 0], [MAP, MAP, 0], [MAP, MAP, -4], [0, MAP, -4])} fill="#6fb35c" />
        <polygon points={pts([MAP, MAP, 0], [MAP, 0, 0], [MAP, 0, -4], [MAP, MAP, -4])} fill="#5a9a4a" />
        <g>{ground}</g>
        {selLot && (
          <polygon className="sel-tile" points={pts([selLot.i, selLot.j, 0.5], [selLot.i + 1, selLot.j, 0.5], [selLot.i + 1, selLot.j + 1, 0.5], [selLot.i, selLot.j + 1, 0.5])} />
        )}
        {objects.map((o) => <g key={o.key}>{o.node}</g>)}
      </svg>
      {cityName && <Sign name={cityName} />}
      {children}
    </div>
  );
}

function Sign({ name }: { name: string }) {
  const fs = name.length <= 9 ? 13 : name.length <= 13 ? 11 : name.length <= 17 ? 9.5 : 8.5;
  return (
    <div className="sign" aria-hidden="true">
      <div className="sign-board"><span style={{ fontSize: fs }}>{name}</span></div>
      <div className="sign-post" />
    </div>
  );
}

/** Силуэт далёкого города: растёт с уровнем (3 → небоскрёбы на 8-м) */
function Skyline({ level }: { level: number }) {
  const towers = useMemo(() => {
    const out: { x: number; w: number; h: number; lv: number }[] = [];
    for (let k = 0; k < 15; k++) {
      const lv = 2 + Math.floor(hash2(k, 9) * 7);
      out.push({ x: 6 + k * 26 + hash2(k, 3) * 6, w: 14 + hash2(k, 5) * 12, h: 20 + lv * 7 + hash2(k, 7) * 26, lv });
    }
    return out;
  }, []);
  return (
    <svg className="skyline" viewBox="0 0 400 170" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
      <path d="M0 170 L0 128 Q50 96 120 124 T250 118 T400 126 L400 170Z" fill="#b4dba0" />
      {towers.filter((tw) => tw.lv <= level).map((tw, k) => (
        <g key={k}>
          <rect x={tw.x} y={150 - tw.h} width={tw.w} height={tw.h + 30} fill={tw.lv >= 6 ? '#a9c3e4' : '#bcd0ea'} />
          {tw.lv >= 4 && Array.from({ length: Math.floor(tw.h / 11) }, (_, r) => (
            <rect key={r} x={tw.x + 3} y={150 - tw.h + 5 + r * 11} width={tw.w - 6} height={2.4} fill="#e6f1ff" opacity={0.8} />
          ))}
        </g>
      ))}
      <path d="M0 170 L0 142 Q70 124 150 142 T300 136 T400 142 L400 170Z" fill="#9ccf86" />
    </svg>
  );
}
