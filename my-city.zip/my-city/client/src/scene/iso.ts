// Изометрия 2:1. Клетка карты (gx, gy) -> экран; z — высота в пикселях.
// Карта 8x8. Центральная улица (проспект) — столбец x = 3, остальные клетки — участки под застройку.

export const TW = 64;
export const TH = 32;
export const MAP = 8;
export const AVENUE_X = 3;
export const ISLAND_DEPTH = 22;

export const px = (x: number, y: number): number => ((x - y) * TW) / 2;
export const py = (x: number, y: number, z = 0): number => ((x + y) * TH) / 2 - z;

const r1 = (n: number) => Math.round(n * 10) / 10;
export type V3 = [number, number, number?]; // z необязателен: плоские фигуры лежат на земле (z = 0)
export const P = (x: number, y: number, z = 0): string => `${r1(px(x, y))},${r1(py(x, y, z))}`;
export const pts = (...v: V3[]): string => v.map((p) => P(p[0], p[1], p[2])).join(' ');

function rgb(hex: string): [number, number, number] {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
const toHex = (r: number, g: number, b: number) =>
  '#' + ((1 << 24) + (Math.round(r) << 16) + (Math.round(g) << 8) + Math.round(b)).toString(16).slice(1);

/** amt < 0 — затемнить, amt > 0 — осветлить (-1..1) */
export function shade(hex: string, amt: number): string {
  const [r, g, b] = rgb(hex);
  const t = amt < 0 ? 0 : 255;
  const k = Math.abs(amt);
  return toHex(r + (t - r) * k, g + (t - g) * k, b + (t - b) * k);
}

export function mix(a: string, b: string, t: number): string {
  const [r1_, g1, b1] = rgb(a);
  const [r2, g2, b2] = rgb(b);
  return toHex(r1_ + (r2 - r1_) * t, g1 + (g2 - g1) * t, b1 + (b2 - b1) * t);
}

/** Детерминированный «случайный» 0..1 по двум числам (деревья, трещины и т.п. не прыгают при перерисовке) */
export function hash2(a: number, b: number): number {
  let h = (Math.imul(a + 17, 374761393) + Math.imul(b + 31, 668265263)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

export interface Lot { i: number; j: number }

/** Участки в порядке застройки: от центра проспекта наружу. Постройка №k занимает LOTS[k]. */
export const LOTS: Lot[] = (() => {
  const all: Lot[] = [];
  for (let i = 0; i < MAP; i++) for (let j = 0; j < MAP; j++) if (i !== AVENUE_X) all.push({ i, j });
  const cx = AVENUE_X + 0.5;
  const cy = 4;
  const d = (l: Lot) => (l.i + 0.5 - cx) ** 2 + (l.j + 0.5 - cy) ** 2;
  return all.sort((a, b) => d(a) - d(b) || ((a.i * 31 + a.j * 17) % 11) - ((b.i * 31 + b.j * 17) % 11));
})();

/** Порядок «освоения» сегментов проспекта (по y): от центра к краям */
export const SEGMENT_ORDER = [4, 3, 5, 2, 6, 1, 7, 0];
