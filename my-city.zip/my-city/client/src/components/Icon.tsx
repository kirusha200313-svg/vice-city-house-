import type { CSSProperties, ReactNode } from 'react';

export type IconName =
  | 'home' | 'treasury' | 'trophy' | 'chat' | 'back' | 'plus' | 'check' | 'lock' | 'people' | 'bricks' | 'smile'
  | 'trend' | 'wallet' | 'road' | 'tree' | 'columns' | 'close' | 'next' | 'up'
  | 'coin' | 'gem' | 'star' | 'crown';

const STROKE: Partial<Record<IconName, ReactNode>> = {
  home: <><path d="M3 11.5 12 4l9 7.5" /><path d="M5.5 10v9.5h13V10" /><path d="M10 19.5v-5h4v5" /></>,
  treasury: <><ellipse cx="12" cy="6.5" rx="7" ry="3" /><path d="M5 6.5v5c0 1.7 3.1 3 7 3s7-1.3 7-3v-5" /><path d="M5 11.5v5c0 1.7 3.1 3 7 3s7-1.3 7-3v-5" /></>,
  trophy: <><path d="M8 4h8v5a4 4 0 0 1-8 0V4Z" /><path d="M8 6H4.5A3.2 3.2 0 0 0 8 10.2" /><path d="M16 6h3.5A3.2 3.2 0 0 1 16 10.2" /><path d="M12 13v4M8.5 20h7M10 17h4" /></>,
  chat: <><path d="M4 5.5h16v10H12l-4.5 3.5v-3.5H4z" /><path d="M8 9.5h8M8 12.5h5" /></>,
  back: <path d="M14.5 5 7.5 12l7 7" />,
  next: <path d="m9 5 7 7-7 7" />,
  up: <path d="m6 14 6-6 6 6" />,
  plus: <path d="M12 5v14M5 12h14" />,
  check: <path d="m5 12.5 4.5 4.5L19 7.5" />,
  close: <path d="M6 6l12 12M18 6 6 18" />,
  lock: <><rect x="5" y="10.5" width="14" height="9.5" rx="2.5" /><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" /></>,
  people: <><circle cx="9" cy="8.5" r="3.2" /><path d="M3.5 19c.4-3.3 2.6-5 5.5-5s5.1 1.7 5.5 5" /><circle cx="17" cy="9.5" r="2.5" /><path d="M16.5 14.2c2.6.2 4 1.6 4.4 4.3" /></>,
  bricks: <><rect x="4" y="5" width="16" height="14" rx="2" /><path d="M4 9.7h16M4 14.4h16M10 5v4.7M15 9.7v4.7M9 14.4V19" /></>,
  smile: <><circle cx="12" cy="12" r="8.5" /><path d="M8.5 14c1 1.5 2.2 2.2 3.5 2.2s2.5-.7 3.5-2.2" /><path d="M9 9.8h.01M15 9.8h.01" strokeWidth="2.6" /></>,
  trend: <><path d="m4 16 5-5 4 3.5L20 7" /><path d="M15 7h5v5" /></>,
  wallet: <><path d="M4 8.5A2.5 2.5 0 0 1 6.5 6H18v3" /><rect x="4" y="8.5" width="16" height="10.5" rx="2.5" /><path d="M16 13.8h.01" strokeWidth="2.6" /></>,
  road: <path d="M8.5 3 5 21M15.5 3 19 21M12 5v3M12 11v3M12 17v3" />,
  tree: <><path d="M12 20v-5" /><path d="M12 3.5c3.5 2.5 5 5 5 7.5a5 5 0 0 1-10 0c0-2.5 1.5-5 5-7.5Z" /></>,
  columns: <><path d="M3.5 9 12 4l8.5 5" /><path d="M5.5 10.5v7.5M10 10.5v7.5M14 10.5v7.5M18.5 10.5v7.5M4 20h16" /></>,
};

const FILLED: Partial<Record<IconName, ReactNode>> = {
  coin: <>
    <circle cx="12" cy="12" r="9.5" fill="#ffc933" stroke="#d99a00" strokeWidth="1.5" />
    <circle cx="12" cy="12" r="6.1" fill="#ffd95a" stroke="#e8a900" strokeWidth="1.2" />
    <path d="M9.6 9.4h4.8M12 9.4v5.6" stroke="#c98a00" strokeWidth="1.6" strokeLinecap="round" />
  </>,
  gem: <>
    <path d="M12 21 3.5 9.8 7 4.5h10l3.5 5.3z" fill="#4db8ff" stroke="#1e86d6" strokeWidth="1.4" strokeLinejoin="round" />
    <path d="M3.5 9.8h17M9 4.5l-1 5.3 4 11.2 4-11.2-1-5.3" fill="none" stroke="#c9ecff" strokeWidth="1.1" strokeLinejoin="round" />
  </>,
  star: <path d="m12 3 2.7 5.6 6.1.8-4.5 4.2 1.1 6-5.4-3-5.4 3 1.1-6L3.2 9.4l6.1-.8Z" fill="#ffc933" stroke="#d99a00" strokeWidth="1.4" strokeLinejoin="round" />,
  crown: <path d="M3.5 8.5 8 12l4-6.5 4 6.5 4.5-3.5-1.8 9.5H5.3Z" fill="currentColor" stroke="rgba(0,0,0,.25)" strokeWidth="1.2" strokeLinejoin="round" />,
};

export function Icon({ name, size = 22, className, style }: { name: IconName; size?: number; className?: string; style?: CSSProperties }) {
  const filled = FILLED[name];
  return (
    <svg
      className={`icon ${className ?? ''}`}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      style={style}
      aria-hidden="true"
      fill="none"
      stroke={filled ? undefined : 'currentColor'}
      strokeWidth={filled ? undefined : 2}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {filled ?? STROKE[name]}
    </svg>
  );
}
