import { useEffect, type ReactNode } from 'react';
import { useGame } from '../state/GameContext';
import { Icon } from './Icon';

export function Modal({ children, onClose, className = '', title }: { children: ReactNode; onClose: () => void; className?: string; title?: string }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`sheet ${className}`} role="dialog" aria-modal="true" aria-label={title}>
        <button className="sheet-close" onClick={onClose} aria-label="Закрыть"><Icon name="close" size={18} /></button>
        {title && <h2 className="sheet-title">{title}</h2>}
        {children}
      </div>
    </div>
  );
}

export function Toasts() {
  const { toasts } = useGame();
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`toast ${t.kind}`}>
          <Icon name={t.kind === 'error' ? 'lock' : 'check'} size={18} />
          <span>{t.text}</span>
          {t.action && <button className="toast-action" onClick={t.action.run}>{t.action.label}</button>}
        </div>
      ))}
    </div>
  );
}

export function ProgressBar({ value, max, className = '' }: { value: number; max: number; className?: string }) {
  const pct = max > 0 ? Math.max(0, Math.min(100, (value / max) * 100)) : 100;
  return (
    <div className={`bar ${className}`} role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={max}>
      <i style={{ width: `${pct}%` }} />
    </div>
  );
}

export function PageHeader({ title }: { title: string }) {
  const { setTab } = useGame();
  return (
    <header className="page-head">
      <button className="back" onClick={() => setTab('home')} aria-label="На главную"><Icon name="back" size={22} /></button>
      <h1 className="page-title">{title}</h1>
      <span className="back ghost" />
    </header>
  );
}

export function Empty({ title, text }: { title: string; text?: string }) {
  return (
    <div className="empty">
      <strong>{title}</strong>
      {text && <span>{text}</span>}
    </div>
  );
}
