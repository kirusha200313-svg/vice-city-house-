import { hash2 } from '../scene/iso';

const SKIN = ['#f6d3b3', '#eab98d', '#cf9a6b', '#a86f4a'];
const HAIR = ['#3b2a22', '#6b4a32', '#c8892e', '#1f1f28', '#8a3b2b'];
const SHIRT = ['#e86a5a', '#5aa9e6', '#6cc08b', '#f2b84b', '#9b7bd8', '#4fbfb3'];
const BG = ['#fde8d0', '#d8ecff', '#dff5e3', '#fff0c8', '#ecdfff', '#d7f4f0'];

const FEMALE = new Set(['Мария', 'Галина Петровна', 'Ольга', 'Светлана', 'Анна', 'Зинаида Павловна', 'Юлия', 'Наталья', 'Евгения']);
const ELDER = new Set(['Галина Петровна', 'Зинаида Павловна', 'Фёдор', 'Дядя Коля']);

/** Портрет жителя: рисуется по seed из сервера, роль и имя добавляют детали (каска, кепка, очки) */
export function Avatar({ seed, name, role, size = 48 }: { seed: number; name: string; role: string; size?: number }) {
  const r = (n: number) => hash2(seed, n);
  const skin = SKIN[Math.floor(r(1) * SKIN.length)];
  const female = FEMALE.has(name);
  const elder = ELDER.has(name) || /Пенсион/.test(role);
  const hair = elder ? '#d9dde6' : HAIR[Math.floor(r(2) * HAIR.length)];
  const shirt = SHIRT[Math.floor(r(3) * SHIRT.length)];
  const bg = BG[Math.floor(r(4) * BG.length)];
  const helmet = /Строитель/.test(role);
  const cap = /Водитель|Таксист/.test(role);
  const nurse = /Медсестра/.test(role);
  const doctor = /Врач/.test(role);
  const glasses = elder || /Учитель|Блогер/.test(role);
  return (
    <svg className="avatar" width={size} height={size} viewBox="0 0 48 48" role="img" aria-label={name}>
      <circle cx="24" cy="24" r="24" fill={bg} />
      <path d="M6 46c1-9 8-13 18-13s17 4 18 13z" fill={doctor || nurse ? '#f4f7fc' : shirt} />
      {(doctor || nurse) && <path d="M20 34l4 6 4-6" fill="none" stroke="#9fd3f5" strokeWidth="2" />}
      <rect x="21" y="28" width="6" height="7" rx="2" fill={skin} />
      {female && !elder && <path d="M12 22c0-9 5-13 12-13s12 4 12 13v12c-3 0-4-3-4-6H16c0 3-1 6-4 6z" fill={hair} />}
      <ellipse cx="24" cy="22" rx="9" ry="10" fill={skin} />
      {!helmet && !cap && !nurse && (female && !elder
        ? <path d="M14.5 21c0-6 4-10 9.5-10s9.5 4 9.5 10c-3-3-6-4.5-9.5-4.5S17.5 18 14.5 21z" fill={hair} />
        : <path d="M14.8 20.5c.2-6 4-9.5 9.2-9.5s9 3.5 9.2 9.5c-2-2.6-5-3.8-9.2-3.8s-7.2 1.2-9.2 3.8z" fill={hair} />)}
      {elder && !female && <path d="M14.8 20.5c.2-6 4-9.5 9.2-9.5s9 3.5 9.2 9.5c-2-2.6-5-3.8-9.2-3.8s-7.2 1.2-9.2 3.8z" fill={hair} />}
      {elder && female && <circle cx="24" cy="10.5" r="4.4" fill={hair} />}
      {helmet && <><path d="M14 19c0-6 4-9.5 10-9.5S34 13 34 19z" fill="#ffc933" /><rect x="12.5" y="18.5" width="23" height="3" rx="1.5" fill="#f0a800" /></>}
      {cap && <><path d="M14.5 19c0-5.5 4-8.5 9.5-8.5s9.5 3 9.5 8.5z" fill="#3d4a73" /><rect x="22" y="17" width="14" height="2.6" rx="1.3" fill="#2d3860" /></>}
      {nurse && <><path d="M15 19c0-5 4-7.5 9-7.5s9 2.5 9 7.5z" fill="#fff" /><path d="M24 12.5v4M22 14.5h4" stroke="#e5484d" strokeWidth="1.6" /></>}
      <circle cx="20" cy="22.5" r="1.3" fill="#2b2230" />
      <circle cx="28" cy="22.5" r="1.3" fill="#2b2230" />
      {glasses && <g fill="none" stroke="#4a4a5c" strokeWidth="1.2"><circle cx="20" cy="22.5" r="3.2" /><circle cx="28" cy="22.5" r="3.2" /><path d="M23.2 22.5h1.6" /></g>}
      <path d="M20.5 27.3c1 1 2.2 1.5 3.5 1.5s2.5-.5 3.5-1.5" fill="none" stroke="#a3524a" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}
