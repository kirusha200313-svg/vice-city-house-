import { fmt, fmtSigned, useCountUp } from '../lib/format';
import { Icon } from '../components/Icon';
import { ProgressBar } from '../components/ui';
import { CityScene } from '../scene/CityScene';
import { MiniCity } from '../scene/Thumbs';
import { useGame } from '../state/GameContext';

export function Home() {
  const { state, fresh, openModal, setTab, levelUp, busy } = useGame();
  const c = state!.city;
  const coins = useCountUp(c.coins);
  const crystals = useCountUp(c.crystals);

  const mood = c.happiness >= 70 ? 'good' : c.happiness >= 40 ? 'mid' : 'bad';
  const need = c.xpNeeded;
  const left = need === null ? 0 : Math.max(0, need - c.xp);

  return (
    <div className="page home">
      <header className="topbar">
        <div className="city-badge"><MiniCity buildings={state!.buildings} /></div>
        <div className="city-meta">
          <div className="city-name">{c.name}</div>
          <div className="city-sub">Уровень {c.level}</div>
          <ProgressBar value={need === null ? 1 : c.xp} max={need ?? 1} className="xp-mini" />
        </div>
        <div className="cur">
          <button className="cur-pill" onClick={() => setTab('feed')} aria-label="Заработать монеты — задания жителей">
            <Icon name="coin" size={20} /><b>{fmt(coins)}</b><span className="cur-plus"><Icon name="plus" size={12} /></span>
          </button>
          <button className="cur-pill" onClick={() => openModal({ type: 'exchange' })} aria-label="Обменять кристаллы">
            <Icon name="gem" size={20} /><b>{fmt(crystals)}</b><span className="cur-plus"><Icon name="plus" size={12} /></span>
          </button>
        </div>
      </header>

      <section className="stat-row" aria-label="Показатели города">
        <div className="stat"><Icon name="people" className="stat-ico" /><div><span className="stat-lab">Жителей</span><b className="stat-val">{fmt(c.population)}</b></div></div>
        <div className="stat"><Icon name="bricks" className="stat-ico" /><div><span className="stat-lab">Построек</span><b className="stat-val">{fmt(c.buildingsCount)}</b></div></div>
        <div className={`stat mood-${mood}`}><Icon name="smile" className="stat-ico" /><div><span className="stat-lab">Счастье</span><b className="stat-val">{c.happiness}%</b></div></div>
      </section>

      <CityScene
        buildings={state!.buildings}
        level={c.level}
        roadRepairs={c.roadRepairs}
        fresh={fresh}
        cityName={c.name}
        onSelect={(index) => openModal({ type: 'building', index })}
      >
        <div className="scene-hint">Нажмите на здание — можно улучшить</div>
      </CityScene>

      <section className="stat-row two" aria-label="Экономика">
        <div className="stat"><Icon name="trend" className="stat-ico green" /><div><span className="stat-lab">Доход города</span><b className="stat-val">{fmtSigned(c.net)}<small>/ч</small></b></div></div>
        <div className="stat"><Icon name="star" className="stat-ico" /><div><span className="stat-lab">Статус</span><b className="stat-val sm">{c.levelName}</b></div></div>
      </section>

      <section className="card level-card">
        <div className="level-head">
          <div>
            <h2>Уровень города</h2>
            <p className="hint">{need === null ? 'Достигнут максимальный уровень' : `Опыт: ${fmt(c.xp)} из ${fmt(need)}`}</p>
          </div>
          <div className="level-badge"><Icon name="star" size={26} /><b>{c.level}</b></div>
        </div>
        <ProgressBar value={need === null ? 1 : c.xp} max={need ?? 1} className="xp" />
        <button
          className={`btn btn-gold btn-block ${c.canLevelUp ? 'ready' : ''}`}
          disabled={!c.canLevelUp || busy}
          onClick={() => void levelUp()}
        >
          {need === null ? 'Максимальный уровень' : 'Следующий уровень'}
          {need !== null && <Icon name="next" size={18} />}
        </button>
        {need !== null && !c.canLevelUp && (
          <p className="hint center">Нужно ещё {fmt(left)} опыта — стройте здания и решайте задачи жителей.</p>
        )}
      </section>
    </div>
  );
}
