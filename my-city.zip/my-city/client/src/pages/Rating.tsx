import { useEffect, useState } from 'react';
import type { RatingEntry, RatingResponse } from '../shared';
import { api } from '../lib/api';
import { fmt } from '../lib/format';
import { Icon } from '../components/Icon';
import { Empty, PageHeader } from '../components/ui';
import { MiniCity } from '../scene/Thumbs';
import { useGame } from '../state/GameContext';

type Sort = 'population' | 'level';

export function Rating() {
  const { openModal, state } = useGame();
  const [sort, setSort] = useState<Sort>('population');
  const [data, setData] = useState<RatingResponse | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let alive = true;
    const load = () =>
      api.rating(sort).then((r) => { if (alive) { setData(r); setFailed(false); } }).catch(() => { if (alive) setFailed(true); });
    setData(null);
    void load();
    const t = setInterval(() => { if (!document.hidden) void load(); }, 30_000);
    return () => { alive = false; clearInterval(t); };
  }, [sort]);

  const open = (e: RatingEntry) => openModal({ type: 'city', id: e.cityId });
  const mine = data?.me ?? null;
  const mineInList = !!data?.entries.some((e) => e.isMe);

  return (
    <div className="page rating">
      <PageHeader title="Рейтинг" />

      <div className="seg" role="tablist" aria-label="Сортировка рейтинга">
        <button role="tab" aria-selected={sort === 'population'} className={`seg-btn ${sort === 'population' ? 'active' : ''}`} onClick={() => setSort('population')}>
          <Icon name="people" size={18} /> По населению
        </button>
        <button role="tab" aria-selected={sort === 'level'} className={`seg-btn ${sort === 'level' ? 'active' : ''}`} onClick={() => setSort('level')}>
          <Icon name="star" size={18} /> По уровню
        </button>
      </div>

      {mine && (
        <button className="card rate-sum" onClick={() => open(mine)}>
          <div className="rate-place">#{mine.rank}</div>
          <div>
            <b>Ваше место в рейтинге</b>
            <span className="hint">из {fmt(data!.total)} {data!.total === 1 ? 'города' : 'городов'} · {fmt(mine.population)} жителей · ур. {mine.level}</span>
          </div>
          <Icon name="next" size={18} />
        </button>
      )}

      {failed && !data && <Empty title="Не удалось загрузить рейтинг" text="Проверьте соединение и откройте вкладку ещё раз." />}
      {!data && !failed && <div className="rlist">{Array.from({ length: 6 }, (_, k) => <div key={k} className="rrow skeleton" />)}</div>}
      {data && data.entries.length === 0 && <Empty title="Пока нет ни одного города" text="Станьте первым — постройте свой город." />}

      {data && (
        <div className="rlist">
          {data.entries.map((e) => (
            <button key={e.cityId} className={`rrow ${e.rank <= 3 ? `top${e.rank}` : ''} ${e.isMe ? 'me' : ''}`} onClick={() => open(e)}>
              <div className={`rank ${e.rank <= 3 ? 'medal' : ''}`}>{e.rank <= 3 ? <Icon name="crown" size={24} /> : e.rank}<span className="sr">{e.rank <= 3 ? e.rank : ''}</span></div>
              <div className="rmini"><MiniCity buildings={e.thumb} /></div>
              <div className="rinfo">
                <div className="rname">{e.name}{e.isMe && <span className="me-tag">Вы</span>}</div>
                <div className="rmayor">{e.isMe ? 'Мэр: вы' : `Мэр: ${e.mayor}`}</div>
              </div>
              <div className="rnum">
                <b>{fmt(e.population)}</b>
                <span>Ур. {e.level}</span>
              </div>
            </button>
          ))}
          {mine && !mineInList && (
            <>
              <div className="rgap" aria-hidden="true">···</div>
              <button className="rrow me" onClick={() => open(mine)}>
                <div className="rank">{mine.rank}</div>
                <div className="rmini"><MiniCity buildings={state!.buildings} /></div>
                <div className="rinfo"><div className="rname">{mine.name}<span className="me-tag">Вы</span></div><div className="rmayor">Мэр: вы</div></div>
                <div className="rnum"><b>{fmt(mine.population)}</b><span>Ур. {mine.level}</span></div>
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
