import { useState } from 'react';
import type { QuestCategory, QuestDTO } from '../shared';
import { fmt, timeAgo } from '../lib/format';
import { Avatar } from '../components/Avatar';
import { Icon } from '../components/Icon';
import { Empty, PageHeader } from '../components/ui';
import { useGame } from '../state/GameContext';

const TAG: Record<QuestCategory, string> = {
  complaint: 'Жалоба', request: 'Просьба', suggestion: 'Предложение', thanks: 'Благодарность', news: 'Новости города', event: 'Событие',
};

type Filter = 'all' | 'open' | 'done';

export function Feed() {
  const { state, now, openModal } = useGame();
  const [filter, setFilter] = useState<Filter>('all');
  const c = state!.city;
  const all = state!.quests;
  const open = all.filter((q) => q.status === 'open');
  const list = all.filter((q) => (filter === 'all' ? true : filter === 'open' ? q.status === 'open' : q.status === 'done'));

  return (
    <div className="page feed">
      <PageHeader title={`Подслушано | ${c.name}`} />

      <div className="seg three" role="tablist" aria-label="Фильтр ленты">
        <button role="tab" aria-selected={filter === 'all'} className={`seg-btn ${filter === 'all' ? 'active' : ''}`} onClick={() => setFilter('all')}>Все</button>
        <button role="tab" aria-selected={filter === 'open'} className={`seg-btn ${filter === 'open' ? 'active' : ''}`} onClick={() => setFilter('open')}>
          Просьбы{open.length > 0 && <span className="seg-count">{open.length}</span>}
        </button>
        <button role="tab" aria-selected={filter === 'done'} className={`seg-btn ${filter === 'done' ? 'active' : ''}`} onClick={() => setFilter('done')}>Решённые</button>
      </div>

      {list.length === 0 && (
        <Empty
          title={filter === 'open' ? 'Все просьбы выполнены' : filter === 'done' ? 'Пока ничего не решено' : 'В городе тихо'}
          text={filter === 'open' ? 'Жители скоро напишут снова — новые сообщения появляются сами.' : filter === 'done' ? 'Решайте просьбы жителей — они попадут сюда.' : 'Жители скоро начнут писать.'}
        />
      )}

      <div className="feed-list">
        {list.map((q) => <Post key={q.id} q={q} ago={timeAgo(q.createdAt, now())} onOpen={() => openModal({ type: 'quest', id: q.id })} />)}
      </div>
    </div>
  );
}

function Post({ q, ago, onOpen }: { q: QuestDTO; ago: string; onOpen: () => void }) {
  const actionable = q.kind !== 'info';
  return (
    <article className={`post ${q.status}`}>
      <div className="post-head">
        <Avatar seed={q.npc.avatar} name={q.npc.name} role={q.npc.role} size={46} />
        <div className="post-who">
          <b className="post-name">{q.npc.name}</b>
          <span className="post-time">{ago}</span>
        </div>
        <span className={`tag tag-${q.category}`}>{TAG[q.category]}</span>
      </div>
      <p className="post-text">{q.text}</p>
      {actionable && q.status === 'open' && (
        <div className="post-foot">
          <div className="rchips" aria-label="Награда">
            <span className="rchip"><Icon name="coin" size={14} />+{fmt(q.reward.coins)}</span>
            <span className="rchip"><Icon name="star" size={14} />+{q.reward.xp}</span>
            <span className="rchip"><Icon name="smile" size={14} />+{q.reward.happy}</span>
          </div>
          <button className={`btn btn-gold btn-sm ${q.ready ? 'ready' : ''}`} onClick={onOpen}>
            {q.ready ? 'Забрать награду' : 'Решить проблему'}
          </button>
        </div>
      )}
      {actionable && q.status === 'done' && (
        <div className="post-foot"><span className="done-mark"><Icon name="check" size={16} />Решено</span></div>
      )}
    </article>
  );
}
