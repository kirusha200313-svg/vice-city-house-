import { useState, type FormEvent } from 'react';
import { CITY_NAME_MAX, validateCityName } from '../shared';
import { useGame } from '../state/GameContext';
import { CityScene } from '../scene/CityScene';

const START = ['old_house', 'old_house', 'old_house'];

export function Welcome() {
  const { createCity } = useGame();
  const [name, setName] = useState('');
  const [touched, setTouched] = useState(false);
  const [serverError, setServerError] = useState('');
  const [sending, setSending] = useState(false);

  const localError = validateCityName(name);
  const error = serverError || (touched ? localError : null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setTouched(true);
    if (localError || sending) return;
    setSending(true);
    setServerError('');
    const err = await createCity(name);
    if (err) { setServerError(err); setSending(false); }
  };

  return (
    <div className="welcome">
      <CityScene className="welcome-scene" buildings={START} level={1} cityName={name.trim() || 'Твой город'} aspect={1.1} />
      <form className="welcome-card" onSubmit={submit} noValidate>
        <h1 className="welcome-title">Добро пожаловать, мэр! Твой город ждёт своего будущего</h1>
        <label className="field" htmlFor="city-name">
          <span>Как назовём твой город?</span>
          <input
            id="city-name"
            className={`input ${error ? 'bad' : ''}`}
            value={name}
            maxLength={CITY_NAME_MAX}
            autoComplete="off"
            autoCapitalize="words"
            placeholder="Например, Солнечногорск"
            onChange={(e) => { setName(e.target.value); setServerError(''); }}
            onBlur={() => setTouched(true)}
            aria-invalid={!!error}
            aria-describedby="city-name-hint"
          />
          <small id="city-name-hint" className={error ? 'error-text' : 'hint'}>
            {error ?? `От 3 до ${CITY_NAME_MAX} символов. Название можно сделать только один раз.`}
          </small>
        </label>
        <button className="btn btn-gold btn-block" type="submit" disabled={sending}>
          {sending ? 'Создаём…' : 'Создать город'}
        </button>
      </form>
    </div>
  );
}
