import { useEffect, useMemo, useState } from 'react';
import {
  CATALOG, CATEGORIES, countOf, countsFromList, checkBuild, priceOf, type BuildCtx, type BuildingDef, type Category, type CoverKey,
} from '../shared';
import { fmt, fmtSigned, useCountUp } from '../lib/format';
import { Icon, type IconName } from '../components/Icon';
import { PageHeader } from '../components/ui';
import { BuildingThumb } from '../scene/Thumbs';
import { useGame } from '../state/GameContext';

const CAT_ICON: Record<Category, IconName> = { housing: 'home', infra: 'road', public: 'columns', leisure: 'tree' };
const CAT_LABEL: Record<Category, string> = { housing: 'Дома', infra: 'Инфраструктура', public: 'Услуги', leisure: 'Досуг' };
const COVER_LABEL: Record<CoverKey, string> = {
  roads: 'Дороги', lighting: 'Освещение', safety: 'Безопасность', health: 'Здоровье', education: 'Образование', leisure: 'Досуг', commerce: 'Торговля',
};

export function Treasury() {
  const { state, openModal, focusBuilding, clearFocus } = useGame();
  const c = state!.city;
  const [cat, setCat] = useState<Category>('housing');
  const [flash, setFlash] = useState<string | null>(null);
  const coins = useCountUp(c.coins);

  const counts = useMemo(() => countsFromList(state!.buildings), [state]);
  const ctx: BuildCtx = { level: c.level, coins: c.coins, counts, roadRepairs: c.roadRepairs, happinessBonus: c.happinessBonus };
  const items = CATALOG.filter((b) => b.category === cat);

  // Переход из задания жителей: открыть нужную категорию и подсветить здание
  useEffect(() => {
    if (!focusBuilding) return;
    const d = CATALOG.find((b) => b.id === focusBuilding);
    if (d) {
      setCat(d.category);
      setFlash(d.id);
      const t1 = setTimeout(() => document.getElementById(`b-${d.id}`)?.scrollIntoView({ block: 'center', behavior: 'smooth' }), 80);
      const t2 = setTimeout(() => setFlash(null), 2600);
      clearFocus();
      return () => { clearTimeout(t1); clearTimeout(t2); };
    }
    clearFocus();
  }, [focusBuilding, clearFocus]);

  const coverKeys: CoverKey[] = ['roads', 'lighting', 'safety', 'health', 'education', 'leisure', 'commerce'];

  return (
    <div className="page treasury">
      <PageHeader title="Казна" />

      <section className="budget">
        <div className="budget-card main">
          <Icon name="coin" size={34} />
          <div>
            <b className="big-num">{fmt(coins)}</b>
            <span className="sub-num pos">{fmtSigned(c.net)} в час</span>
          </div>
        </div>
        <div className="budget-card">
          <Icon name="wallet" size={26} className="red" />
          <div>
            <span className="stat-lab">Расходы</span>
            <b className={`mid-num ${c.upkeep > 0 ? 'neg' : ''}`}>{c.upkeep > 0 ? '−' : ''}{fmt(c.upkeep)}<small>/ч</small></b>
          </div>
        </div>
      </section>

      <section className="card budget-sum" aria-label="Общий бюджет">
        <div><span className="stat-lab">Доход в сутки</span><b className="pos">+{fmt(c.grossIncome * 24)}</b></div>
        <div><span className="stat-lab">Расходы в сутки</span><b className={c.upkeep > 0 ? 'neg' : ''}>{c.upkeep > 0 ? '−' : ''}{fmt(c.upkeep * 24)}</b></div>
        <div><span className="stat-lab">Общий бюджет</span><b className={c.net >= 0 ? 'pos' : 'neg'}>{fmtSigned(c.net * 24)}</b></div>
      </section>

      <section className="cover" aria-label="Обеспеченность жителей">
        {coverKeys.map((k) => {
          const v = Math.round(c.coverage[k] * 100);
          return (
            <div key={k} className="cover-item">
              <span>{COVER_LABEL[k]}</span>
              <div className="bar thin"><i className={v >= 70 ? 'ok' : v >= 35 ? 'mid' : 'low'} style={{ width: `${v}%` }} /></div>
              <b>{v}%</b>
            </div>
          );
        })}
      </section>

      <div className="chips" role="tablist" aria-label="Каталог строительства">
        {CATEGORIES.map((k) => (
          <button key={k.id} role="tab" aria-selected={cat === k.id} className={`chip ${cat === k.id ? 'active' : ''}`} onClick={() => setCat(k.id)}>
            <Icon name={CAT_ICON[k.id]} size={22} />
            <span>{CAT_LABEL[k.id]}</span>
          </button>
        ))}
      </div>

      <div className="blist">
        {items.map((d) => (
          <BuildCard key={d.id} d={d} ctx={ctx} flash={flash === d.id} onBuild={() => openModal({ type: 'confirm', id: d.id })} />
        ))}
      </div>
    </div>
  );
}

function BuildCard({ d, ctx, flash, onBuild }: { d: BuildingDef; ctx: BuildCtx; flash: boolean; onBuild: () => void }) {
  const owned = countOf(ctx.counts, d.id);
  const price = priceOf(d, owned);
  const chk = checkBuild(ctx, d);
  const covers = Object.keys(d.cover) as CoverKey[];
  return (
    <article id={`b-${d.id}`} className={`card bcard ${chk.ok ? '' : 'locked'} ${flash ? 'flash' : ''}`}>
      <div className="bthumb"><BuildingThumb id={d.id} /></div>
      <div className="binfo">
        <h3 className="bname">{d.name}{owned > 0 && <span className="owned">×{owned}</span>}</h3>
        <div className="bstats">
          {d.capacity > 0 && <span className="st"><Icon name="people" size={14} />{d.capacity} жителей</span>}
          {d.income > 0 && <span className="st pos"><Icon name="trend" size={14} />+{d.income}/ч</span>}
          {d.upkeep > 0 && <span className="st neg">−{d.upkeep}/ч содержание</span>}
          {covers.length > 0 && <span className="st">{covers.map((k) => COVER_LABEL[k]).join(', ')}</span>}
        </div>
        <p className="bblurb">{d.blurb}</p>
      </div>
      <div className="bbuy">
        <div className="price"><Icon name="coin" size={18} />{fmt(price)}</div>
        <button className="btn btn-gold btn-sm" disabled={!chk.ok} onClick={onBuild}>Построить</button>
      </div>
      {!chk.ok && <div className="reason"><Icon name="lock" size={14} />{chk.message}</div>}
    </article>
  );
}
