import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// В разработке запросы /api проксируются на игровой сервер (npm run dev:server, порт 3001).
// Общий код игры лежит в ../shared — поэтому разрешаем Vite читать файлы уровнем выше.
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    fs: { allow: ['..'] },
    proxy: { '/api': 'http://localhost:3001' },
    // Туннели (ngrok, cloudflared) приходят с чужим Host — без этого Vite их блокирует
    allowedHosts: true,
  },
  build: { outDir: 'dist', target: 'es2020', sourcemap: false },
});
